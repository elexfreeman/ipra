<?php
/**
 * File for class MyMPIStructSickLeaveDocument
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructSickLeaveDocument originally named SickLeaveDocument
 * Documentation : Документ временной нетрудоспособности
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructSickLeaveDocument extends MyMPIWsdlClass
{
    /**
     * The extId
     * Meta informations extracted from the WSDL
     * - documentation : Идентификатор в МИС
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $extId;
    /**
     * The encounterCode
     * Meta informations extracted from the WSDL
     * - documentation : Код эпизода
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $encounterCode;
    /**
     * The enteredBy
     * Meta informations extracted from the WSDL
     * - documentation : Автор записи (врач) ТФОМС: IDDOKT (региональный справочник), PRVS (V004) - специальность
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $enteredBy;
    /**
     * The enteredOn
     * Meta informations extracted from the WSDL
     * - documentation : Дата/время ввода записи в МИС
     * - minOccurs : 0
     * @var dateTime
     */
    public $enteredOn;
    /**
     * The docSer
     * Meta informations extracted from the WSDL
     * - documentation : Серия документа
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $docSer;
    /**
     * The docNum
     * Meta informations extracted from the WSDL
     * - documentation : Номер документа
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $docNum;
    /**
     * The reason
     * Meta informations extracted from the WSDL
     * - documentation : Причина выдачи (заболевание; по уходу; карантин; прерывание беременности; отпуск по беременности и родам; санаторно-курортное лечение)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $reason;
    /**
     * The diagnosis
     * Meta informations extracted from the WSDL
     * - documentation : Диагноз (код МКБ-10 и расшифровка)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $diagnosis;
    /**
     * The attendantGender
     * @var MyMPIEnumAttendantGender
     */
    public $attendantGender;
    /**
     * The attendantAge
     * Meta informations extracted from the WSDL
     * - documentation : Возраст ухаживающего ф 025-12/у
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $attendantAge;
    /**
     * The fromTime
     * Meta informations extracted from the WSDL
     * - documentation : Дата/время начала
     * - minOccurs : 0
     * @var dateTime
     */
    public $fromTime;
    /**
     * The toTime
     * Meta informations extracted from the WSDL
     * - documentation : Дата/время окончания
     * - minOccurs : 0
     * @var dateTime
     */
    public $toTime;
    /**
     * Constructor method for SickLeaveDocument
     * @see parent::__construct()
     * @param string $_extId
     * @param string $_encounterCode
     * @param MyMPIStructEmployee $_enteredBy
     * @param dateTime $_enteredOn
     * @param string $_docSer
     * @param string $_docNum
     * @param MyMPIStructCodeAndName $_reason
     * @param MyMPIStructCodeAndName $_diagnosis
     * @param MyMPIEnumAttendantGender $_attendantGender
     * @param string $_attendantAge
     * @param dateTime $_fromTime
     * @param dateTime $_toTime
     * @return MyMPIStructSickLeaveDocument
     */
    public function __construct($_extId = NULL,$_encounterCode = NULL,$_enteredBy = NULL,$_enteredOn = NULL,$_docSer = NULL,$_docNum = NULL,$_reason = NULL,$_diagnosis = NULL,$_attendantGender = NULL,$_attendantAge = NULL,$_fromTime = NULL,$_toTime = NULL)
    {
        parent::__construct(array('extId'=>$_extId,'encounterCode'=>$_encounterCode,'enteredBy'=>$_enteredBy,'enteredOn'=>$_enteredOn,'docSer'=>$_docSer,'docNum'=>$_docNum,'reason'=>$_reason,'diagnosis'=>$_diagnosis,'attendantGender'=>$_attendantGender,'attendantAge'=>$_attendantAge,'fromTime'=>$_fromTime,'toTime'=>$_toTime),false);
    }
    /**
     * Get extId value
     * @return string|null
     */
    public function getExtId()
    {
        return $this->extId;
    }
    /**
     * Set extId value
     * @param string $_extId the extId
     * @return string
     */
    public function setExtId($_extId)
    {
        return ($this->extId = $_extId);
    }
    /**
     * Get encounterCode value
     * @return string|null
     */
    public function getEncounterCode()
    {
        return $this->encounterCode;
    }
    /**
     * Set encounterCode value
     * @param string $_encounterCode the encounterCode
     * @return string
     */
    public function setEncounterCode($_encounterCode)
    {
        return ($this->encounterCode = $_encounterCode);
    }
    /**
     * Get enteredBy value
     * @return MyMPIStructEmployee|null
     */
    public function getEnteredBy()
    {
        return $this->enteredBy;
    }
    /**
     * Set enteredBy value
     * @param MyMPIStructEmployee $_enteredBy the enteredBy
     * @return MyMPIStructEmployee
     */
    public function setEnteredBy($_enteredBy)
    {
        return ($this->enteredBy = $_enteredBy);
    }
    /**
     * Get enteredOn value
     * @return dateTime|null
     */
    public function getEnteredOn()
    {
        return $this->enteredOn;
    }
    /**
     * Set enteredOn value
     * @param dateTime $_enteredOn the enteredOn
     * @return dateTime
     */
    public function setEnteredOn($_enteredOn)
    {
        return ($this->enteredOn = $_enteredOn);
    }
    /**
     * Get docSer value
     * @return string|null
     */
    public function getDocSer()
    {
        return $this->docSer;
    }
    /**
     * Set docSer value
     * @param string $_docSer the docSer
     * @return string
     */
    public function setDocSer($_docSer)
    {
        return ($this->docSer = $_docSer);
    }
    /**
     * Get docNum value
     * @return string|null
     */
    public function getDocNum()
    {
        return $this->docNum;
    }
    /**
     * Set docNum value
     * @param string $_docNum the docNum
     * @return string
     */
    public function setDocNum($_docNum)
    {
        return ($this->docNum = $_docNum);
    }
    /**
     * Get reason value
     * @return MyMPIStructCodeAndName|null
     */
    public function getReason()
    {
        return $this->reason;
    }
    /**
     * Set reason value
     * @param MyMPIStructCodeAndName $_reason the reason
     * @return MyMPIStructCodeAndName
     */
    public function setReason($_reason)
    {
        return ($this->reason = $_reason);
    }
    /**
     * Get diagnosis value
     * @return MyMPIStructCodeAndName|null
     */
    public function getDiagnosis()
    {
        return $this->diagnosis;
    }
    /**
     * Set diagnosis value
     * @param MyMPIStructCodeAndName $_diagnosis the diagnosis
     * @return MyMPIStructCodeAndName
     */
    public function setDiagnosis($_diagnosis)
    {
        return ($this->diagnosis = $_diagnosis);
    }
    /**
     * Get attendantGender value
     * @return MyMPIEnumAttendantGender|null
     */
    public function getAttendantGender()
    {
        return $this->attendantGender;
    }
    /**
     * Set attendantGender value
     * @uses MyMPIEnumAttendantGender::valueIsValid()
     * @param MyMPIEnumAttendantGender $_attendantGender the attendantGender
     * @return MyMPIEnumAttendantGender
     */
    public function setAttendantGender($_attendantGender)
    {
        if(!MyMPIEnumAttendantGender::valueIsValid($_attendantGender))
        {
            return false;
        }
        return ($this->attendantGender = $_attendantGender);
    }
    /**
     * Get attendantAge value
     * @return string|null
     */
    public function getAttendantAge()
    {
        return $this->attendantAge;
    }
    /**
     * Set attendantAge value
     * @param string $_attendantAge the attendantAge
     * @return string
     */
    public function setAttendantAge($_attendantAge)
    {
        return ($this->attendantAge = $_attendantAge);
    }
    /**
     * Get fromTime value
     * @return dateTime|null
     */
    public function getFromTime()
    {
        return $this->fromTime;
    }
    /**
     * Set fromTime value
     * @param dateTime $_fromTime the fromTime
     * @return dateTime
     */
    public function setFromTime($_fromTime)
    {
        return ($this->fromTime = $_fromTime);
    }
    /**
     * Get toTime value
     * @return dateTime|null
     */
    public function getToTime()
    {
        return $this->toTime;
    }
    /**
     * Set toTime value
     * @param dateTime $_toTime the toTime
     * @return dateTime
     */
    public function setToTime($_toTime)
    {
        return ($this->toTime = $_toTime);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructSickLeaveDocument
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
