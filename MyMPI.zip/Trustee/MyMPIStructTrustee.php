<?php
/**
 * File for class MyMPIStructTrustee
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructTrustee originally named Trustee
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructTrustee extends MyMPIStructBaseSerial
{
    /**
     * The trusteeType
     * Meta informations extracted from the WSDL
     * - documentation : Тип представителя ЕГИСЗ "Представитель пациента" поле №1
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $trusteeType;
    /**
     * The familyName
     * Meta informations extracted from the WSDL
     * - documentation : Фамилия ЕГИСЗ "Представитель пациента" поле №2 СЭМД participant/associatedEntity/associatedPerson/name/family
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $familyName;
    /**
     * The givenName
     * Meta informations extracted from the WSDL
     * - documentation : Имя ЕГИСЗ "Представитель пациента" поле №2 СЭМД participant/associatedEntity/associatedPerson/name/given
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $givenName;
    /**
     * The middleName
     * Meta informations extracted from the WSDL
     * - documentation : Отчество ЕГИСЗ "Представитель пациента" поле №2 СЭМД participant/associatedEntity/associatedPerson/name/given
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $middleName;
    /**
     * The kinship
     * Meta informations extracted from the WSDL
     * - documentation : Степень родства ЕГИСЗ "Представитель пациента" поля №№3-4 СЭМД participant/associatedEntity/code[@codeSystem='1.2.643.5.1.13.2.7.1.15']/@code - содержимое справочника 1.2.643.5.1.13.2.7.1.15 имеется в документе "Описание структуры документов v1.1.odt"
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $kinship;
    /**
     * The trusteeDocType
     * Meta informations extracted from the WSDL
     * - documentation : Тип документа, удостоверяющего права представителя ЕГИСЗ "Представитель пациента" поле №9
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $trusteeDocType;
    /**
     * The identityDocument
     * Meta informations extracted from the WSDL
     * - documentation : Документ, удостоверяющий личность ЕГИСЗ "Представитель пациента" поля №№5-8
     * - minOccurs : 0
     * @var MyMPIStructIdentityDocument
     */
    public $identityDocument;
    /**
     * The legalAddress
     * Meta informations extracted from the WSDL
     * - documentation : Адрес прописки (постоянного места жительства) ЕГИСЗ "Представитель пациента" поля №№10-18 (тип адреса = 1)
     * - minOccurs : 0
     * @var MyMPIStructAddress
     */
    public $legalAddress;
    /**
     * The actualAddress
     * Meta informations extracted from the WSDL
     * - documentation : Адрес пребывания ЕГИСЗ "Представитель пациента" поля №№10-18 (тип адреса = 2)
     * - minOccurs : 0
     * @var MyMPIStructAddress
     */
    public $actualAddress;
    /**
     * The contactInfo
     * Meta informations extracted from the WSDL
     * - documentation : Контактная информация ЕГИСЗ "Представитель пациента" поле №19 СЭМД participant/associatedEntity/telecom
     * - minOccurs : 0
     * @var MyMPIStructContactInfo
     */
    public $contactInfo;
    /**
     * The isGuardian
     * Meta informations extracted from the WSDL
     * - documentation : Признак опекуна/родителя СЭМД recordTarget/patientRole/patient/guardian
     * - minOccurs : 0
     * @var boolean
     */
    public $isGuardian;
    /**
     * Constructor method for Trustee
     * @see parent::__construct()
     * @param MyMPIStructCodeAndName $_trusteeType
     * @param string $_familyName
     * @param string $_givenName
     * @param string $_middleName
     * @param MyMPIStructCodeAndName $_kinship
     * @param MyMPIStructCodeAndName $_trusteeDocType
     * @param MyMPIStructIdentityDocument $_identityDocument
     * @param MyMPIStructAddress $_legalAddress
     * @param MyMPIStructAddress $_actualAddress
     * @param MyMPIStructContactInfo $_contactInfo
     * @param boolean $_isGuardian
     * @return MyMPIStructTrustee
     */
    public function __construct($_trusteeType = NULL,$_familyName = NULL,$_givenName = NULL,$_middleName = NULL,$_kinship = NULL,$_trusteeDocType = NULL,$_identityDocument = NULL,$_legalAddress = NULL,$_actualAddress = NULL,$_contactInfo = NULL,$_isGuardian = NULL)
    {
        MyMPIWsdlClass::__construct(array('trusteeType'=>$_trusteeType,'familyName'=>$_familyName,'givenName'=>$_givenName,'middleName'=>$_middleName,'kinship'=>$_kinship,'trusteeDocType'=>$_trusteeDocType,'identityDocument'=>$_identityDocument,'legalAddress'=>$_legalAddress,'actualAddress'=>$_actualAddress,'contactInfo'=>$_contactInfo,'isGuardian'=>$_isGuardian),false);
    }
    /**
     * Get trusteeType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getTrusteeType()
    {
        return $this->trusteeType;
    }
    /**
     * Set trusteeType value
     * @param MyMPIStructCodeAndName $_trusteeType the trusteeType
     * @return MyMPIStructCodeAndName
     */
    public function setTrusteeType($_trusteeType)
    {
        return ($this->trusteeType = $_trusteeType);
    }
    /**
     * Get familyName value
     * @return string|null
     */
    public function getFamilyName()
    {
        return $this->familyName;
    }
    /**
     * Set familyName value
     * @param string $_familyName the familyName
     * @return string
     */
    public function setFamilyName($_familyName)
    {
        return ($this->familyName = $_familyName);
    }
    /**
     * Get givenName value
     * @return string|null
     */
    public function getGivenName()
    {
        return $this->givenName;
    }
    /**
     * Set givenName value
     * @param string $_givenName the givenName
     * @return string
     */
    public function setGivenName($_givenName)
    {
        return ($this->givenName = $_givenName);
    }
    /**
     * Get middleName value
     * @return string|null
     */
    public function getMiddleName()
    {
        return $this->middleName;
    }
    /**
     * Set middleName value
     * @param string $_middleName the middleName
     * @return string
     */
    public function setMiddleName($_middleName)
    {
        return ($this->middleName = $_middleName);
    }
    /**
     * Get kinship value
     * @return MyMPIStructCodeAndName|null
     */
    public function getKinship()
    {
        return $this->kinship;
    }
    /**
     * Set kinship value
     * @param MyMPIStructCodeAndName $_kinship the kinship
     * @return MyMPIStructCodeAndName
     */
    public function setKinship($_kinship)
    {
        return ($this->kinship = $_kinship);
    }
    /**
     * Get trusteeDocType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getTrusteeDocType()
    {
        return $this->trusteeDocType;
    }
    /**
     * Set trusteeDocType value
     * @param MyMPIStructCodeAndName $_trusteeDocType the trusteeDocType
     * @return MyMPIStructCodeAndName
     */
    public function setTrusteeDocType($_trusteeDocType)
    {
        return ($this->trusteeDocType = $_trusteeDocType);
    }
    /**
     * Get identityDocument value
     * @return MyMPIStructIdentityDocument|null
     */
    public function getIdentityDocument()
    {
        return $this->identityDocument;
    }
    /**
     * Set identityDocument value
     * @param MyMPIStructIdentityDocument $_identityDocument the identityDocument
     * @return MyMPIStructIdentityDocument
     */
    public function setIdentityDocument($_identityDocument)
    {
        return ($this->identityDocument = $_identityDocument);
    }
    /**
     * Get legalAddress value
     * @return MyMPIStructAddress|null
     */
    public function getLegalAddress()
    {
        return $this->legalAddress;
    }
    /**
     * Set legalAddress value
     * @param MyMPIStructAddress $_legalAddress the legalAddress
     * @return MyMPIStructAddress
     */
    public function setLegalAddress($_legalAddress)
    {
        return ($this->legalAddress = $_legalAddress);
    }
    /**
     * Get actualAddress value
     * @return MyMPIStructAddress|null
     */
    public function getActualAddress()
    {
        return $this->actualAddress;
    }
    /**
     * Set actualAddress value
     * @param MyMPIStructAddress $_actualAddress the actualAddress
     * @return MyMPIStructAddress
     */
    public function setActualAddress($_actualAddress)
    {
        return ($this->actualAddress = $_actualAddress);
    }
    /**
     * Get contactInfo value
     * @return MyMPIStructContactInfo|null
     */
    public function getContactInfo()
    {
        return $this->contactInfo;
    }
    /**
     * Set contactInfo value
     * @param MyMPIStructContactInfo $_contactInfo the contactInfo
     * @return MyMPIStructContactInfo
     */
    public function setContactInfo($_contactInfo)
    {
        return ($this->contactInfo = $_contactInfo);
    }
    /**
     * Get isGuardian value
     * @return boolean|null
     */
    public function getIsGuardian()
    {
        return $this->isGuardian;
    }
    /**
     * Set isGuardian value
     * @param boolean $_isGuardian the isGuardian
     * @return boolean
     */
    public function setIsGuardian($_isGuardian)
    {
        return ($this->isGuardian = $_isGuardian);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructTrustee
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
