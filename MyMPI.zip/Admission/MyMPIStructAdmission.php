<?php
/**
 * File for class MyMPIStructAdmission
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructAdmission originally named Admission
 * Documentation : Данные о госпитализации
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructAdmission extends MyMPIStructBaseSerial
{
    /**
     * The isUrgentAdmission
     * Meta informations extracted from the WSDL
     * - documentation : Доставлен в стационар по экстренным показаниям ф 003/у ТФОМС: EXTR (1 –плановая; 2 – экстренная госпитализация)
     * - minOccurs : 0
     * @var boolean
     */
    public $isUrgentAdmission;
    /**
     * The timeAfterFallingIll
     * Meta informations extracted from the WSDL
     * - documentation : Время, прошедшее c начала заболевания (получения травмы) до госпитализации ф 003/у СЭМД ext:encounter/ext:timeAfterBegining - 1.2.643.5.1.13.2.1.1.537 /PRK371 (1=в первые 6 часов, 2=в течение 7-24 часов, 3=позднее 24-х часов)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $timeAfterFallingIll;
    /**
     * The transportType
     * Meta informations extracted from the WSDL
     * - documentation : Виды транспортировки (на каталке, на кресле, может идти) ф 003/у
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $transportType;
    /**
     * The department
     * Meta informations extracted from the WSDL
     * - documentation : Отделение ф 003/у
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $department;
    /**
     * The finalDepartment
     * Meta informations extracted from the WSDL
     * - documentation : Переведен в отделение ф 003/у
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $finalDepartment;
    /**
     * The ward
     * Meta informations extracted from the WSDL
     * - documentation : Палата ф 003/у
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $ward;
    /**
     * The bedDayCount
     * Meta informations extracted from the WSDL
     * - documentation : Проведено койко-дней в стационаре ф 003/у СЭМД componentOf/encompassingEncounter/ext:encounter/ext:lengthOfStayQuantity
     * - minOccurs : 0
     * @var long
     */
    public $bedDayCount;
    /**
     * The admittingDoctor
     * Meta informations extracted from the WSDL
     * - documentation : Врач приемного отделения ф 003/у
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $admittingDoctor;
    /**
     * The attendingDoctor
     * Meta informations extracted from the WSDL
     * - documentation : Лечащий врач ф 003/у
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $attendingDoctor;
    /**
     * The admissionReferral
     * Meta informations extracted from the WSDL
     * - documentation : Кем доставлен СЭМД componentOf/encompassingEncounter/ext:encounter/ext:admissionReferralSourceCode - codeSystem="1.2.643.5.1.13.2.1.1.281" - Классификатор каналов госпитализации
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $admissionReferral;
    /**
     * The priorityCode
     * Meta informations extracted from the WSDL
     * - documentation : Срочность госпитализации СЭМД inFulfillmentOf/order/priorityCode - codeSystem="1.2.643.5.1.13.2.1.1.568"
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $priorityCode;
    /**
     * The admissionsThisYear
     * Meta informations extracted from the WSDL
     * - documentation : Кол-во госпитализации в текущем году СЭМД componentOf/encompassingEncounter/ext:encounter/ext:priorityCode - codeSystem="1.2.643.5.1.13.2.1.1.109" (1=Госпитализирован впервые в данном году по диагнозу)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $admissionsThisYear;
    /**
     * Constructor method for Admission
     * @see parent::__construct()
     * @param boolean $_isUrgentAdmission
     * @param MyMPIStructCodeAndName $_timeAfterFallingIll
     * @param MyMPIStructCodeAndName $_transportType
     * @param MyMPIStructCodeAndName $_department
     * @param MyMPIStructCodeAndName $_finalDepartment
     * @param string $_ward
     * @param long $_bedDayCount
     * @param MyMPIStructEmployee $_admittingDoctor
     * @param MyMPIStructEmployee $_attendingDoctor
     * @param MyMPIStructCodeAndName $_admissionReferral
     * @param MyMPIStructCodeAndName $_priorityCode
     * @param MyMPIStructCodeAndName $_admissionsThisYear
     * @return MyMPIStructAdmission
     */
    public function __construct($_isUrgentAdmission = NULL,$_timeAfterFallingIll = NULL,$_transportType = NULL,$_department = NULL,$_finalDepartment = NULL,$_ward = NULL,$_bedDayCount = NULL,$_admittingDoctor = NULL,$_attendingDoctor = NULL,$_admissionReferral = NULL,$_priorityCode = NULL,$_admissionsThisYear = NULL)
    {
        MyMPIWsdlClass::__construct(array('isUrgentAdmission'=>$_isUrgentAdmission,'timeAfterFallingIll'=>$_timeAfterFallingIll,'transportType'=>$_transportType,'department'=>$_department,'finalDepartment'=>$_finalDepartment,'ward'=>$_ward,'bedDayCount'=>$_bedDayCount,'admittingDoctor'=>$_admittingDoctor,'attendingDoctor'=>$_attendingDoctor,'admissionReferral'=>$_admissionReferral,'priorityCode'=>$_priorityCode,'admissionsThisYear'=>$_admissionsThisYear),false);
    }
    /**
     * Get isUrgentAdmission value
     * @return boolean|null
     */
    public function getIsUrgentAdmission()
    {
        return $this->isUrgentAdmission;
    }
    /**
     * Set isUrgentAdmission value
     * @param boolean $_isUrgentAdmission the isUrgentAdmission
     * @return boolean
     */
    public function setIsUrgentAdmission($_isUrgentAdmission)
    {
        return ($this->isUrgentAdmission = $_isUrgentAdmission);
    }
    /**
     * Get timeAfterFallingIll value
     * @return MyMPIStructCodeAndName|null
     */
    public function getTimeAfterFallingIll()
    {
        return $this->timeAfterFallingIll;
    }
    /**
     * Set timeAfterFallingIll value
     * @param MyMPIStructCodeAndName $_timeAfterFallingIll the timeAfterFallingIll
     * @return MyMPIStructCodeAndName
     */
    public function setTimeAfterFallingIll($_timeAfterFallingIll)
    {
        return ($this->timeAfterFallingIll = $_timeAfterFallingIll);
    }
    /**
     * Get transportType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getTransportType()
    {
        return $this->transportType;
    }
    /**
     * Set transportType value
     * @param MyMPIStructCodeAndName $_transportType the transportType
     * @return MyMPIStructCodeAndName
     */
    public function setTransportType($_transportType)
    {
        return ($this->transportType = $_transportType);
    }
    /**
     * Get department value
     * @return MyMPIStructCodeAndName|null
     */
    public function getDepartment()
    {
        return $this->department;
    }
    /**
     * Set department value
     * @param MyMPIStructCodeAndName $_department the department
     * @return MyMPIStructCodeAndName
     */
    public function setDepartment($_department)
    {
        return ($this->department = $_department);
    }
    /**
     * Get finalDepartment value
     * @return MyMPIStructCodeAndName|null
     */
    public function getFinalDepartment()
    {
        return $this->finalDepartment;
    }
    /**
     * Set finalDepartment value
     * @param MyMPIStructCodeAndName $_finalDepartment the finalDepartment
     * @return MyMPIStructCodeAndName
     */
    public function setFinalDepartment($_finalDepartment)
    {
        return ($this->finalDepartment = $_finalDepartment);
    }
    /**
     * Get ward value
     * @return string|null
     */
    public function getWard()
    {
        return $this->ward;
    }
    /**
     * Set ward value
     * @param string $_ward the ward
     * @return string
     */
    public function setWard($_ward)
    {
        return ($this->ward = $_ward);
    }
    /**
     * Get bedDayCount value
     * @return long|null
     */
    public function getBedDayCount()
    {
        return $this->bedDayCount;
    }
    /**
     * Set bedDayCount value
     * @param long $_bedDayCount the bedDayCount
     * @return long
     */
    public function setBedDayCount($_bedDayCount)
    {
        return ($this->bedDayCount = $_bedDayCount);
    }
    /**
     * Get admittingDoctor value
     * @return MyMPIStructEmployee|null
     */
    public function getAdmittingDoctor()
    {
        return $this->admittingDoctor;
    }
    /**
     * Set admittingDoctor value
     * @param MyMPIStructEmployee $_admittingDoctor the admittingDoctor
     * @return MyMPIStructEmployee
     */
    public function setAdmittingDoctor($_admittingDoctor)
    {
        return ($this->admittingDoctor = $_admittingDoctor);
    }
    /**
     * Get attendingDoctor value
     * @return MyMPIStructEmployee|null
     */
    public function getAttendingDoctor()
    {
        return $this->attendingDoctor;
    }
    /**
     * Set attendingDoctor value
     * @param MyMPIStructEmployee $_attendingDoctor the attendingDoctor
     * @return MyMPIStructEmployee
     */
    public function setAttendingDoctor($_attendingDoctor)
    {
        return ($this->attendingDoctor = $_attendingDoctor);
    }
    /**
     * Get admissionReferral value
     * @return MyMPIStructCodeAndName|null
     */
    public function getAdmissionReferral()
    {
        return $this->admissionReferral;
    }
    /**
     * Set admissionReferral value
     * @param MyMPIStructCodeAndName $_admissionReferral the admissionReferral
     * @return MyMPIStructCodeAndName
     */
    public function setAdmissionReferral($_admissionReferral)
    {
        return ($this->admissionReferral = $_admissionReferral);
    }
    /**
     * Get priorityCode value
     * @return MyMPIStructCodeAndName|null
     */
    public function getPriorityCode()
    {
        return $this->priorityCode;
    }
    /**
     * Set priorityCode value
     * @param MyMPIStructCodeAndName $_priorityCode the priorityCode
     * @return MyMPIStructCodeAndName
     */
    public function setPriorityCode($_priorityCode)
    {
        return ($this->priorityCode = $_priorityCode);
    }
    /**
     * Get admissionsThisYear value
     * @return MyMPIStructCodeAndName|null
     */
    public function getAdmissionsThisYear()
    {
        return $this->admissionsThisYear;
    }
    /**
     * Set admissionsThisYear value
     * @param MyMPIStructCodeAndName $_admissionsThisYear the admissionsThisYear
     * @return MyMPIStructCodeAndName
     */
    public function setAdmissionsThisYear($_admissionsThisYear)
    {
        return ($this->admissionsThisYear = $_admissionsThisYear);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructAdmission
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
