<?php
/**
 * File for the class which returns the class map definition
 * @package MyMPI
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * Class which returns the class map definition by the static method MyMPIClassMap::classMap()
 * @package MyMPI
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIClassMap
{
    /**
     * This method returns the array containing the mapping between WSDL structs and generated classes
     * This array is sent to the SoapClient when calling the WS
     * @return array
     */
    final public static function classMap()
    {
        return array (
  'Address' => 'MyMPIStructAddress',
  'Admission' => 'MyMPIStructAdmission',
  'Allergy' => 'MyMPIStructAllergy',
  'ArrayOfCodeAndNameCodeAndName' => 'MyMPIStructArrayOfCodeAndNameCodeAndName',
  'ArrayOfInsuranceInsurance' => 'MyMPIStructArrayOfInsuranceInsurance',
  'ArrayOfNameName' => 'MyMPIStructArrayOfNameName',
  'ArrayOfOccupationOccupation' => 'MyMPIStructArrayOfOccupationOccupation',
  'ArrayOfPrivilegePrivilege' => 'MyMPIStructArrayOfPrivilegePrivilege',
  'ArrayOfaddressAddress' => 'MyMPIStructArrayOfaddressAddress',
  'ArrayOfallergyAllergy' => 'MyMPIStructArrayOfallergyAllergy',
  'ArrayOfdeceaseDecease' => 'MyMPIStructArrayOfdeceaseDecease',
  'ArrayOfdiagnosisDiagnosis' => 'MyMPIStructArrayOfdiagnosisDiagnosis',
  'ArrayOfdisabilityDisability' => 'MyMPIStructArrayOfdisabilityDisability',
  'ArrayOfdocumentDocument' => 'MyMPIStructArrayOfdocumentDocument',
  'ArrayOfencounterEncounter' => 'MyMPIStructArrayOfencounterEncounter',
  'ArrayOfidentifierIdentifier' => 'MyMPIStructArrayOfidentifierIdentifier',
  'ArrayOfidentityDocumentIdentityDocument' => 'MyMPIStructArrayOfidentityDocumentIdentityDocument',
  'ArrayOfmesCodeString' => 'MyMPIStructArrayOfmesCodeString',
  'ArrayOfoccupationHistoryEntry' => 'MyMPIStructArrayOfoccupationHistoryEntry',
  'ArrayOfserviceMedService' => 'MyMPIStructArrayOfserviceMedService',
  'ArrayOfsickLeaveDocumentSickLeaveDocument' => 'MyMPIStructArrayOfsickLeaveDocumentSickLeaveDocument',
  'ArrayOftrusteeTrustee' => 'MyMPIStructArrayOftrusteeTrustee',
  'BaseSerial' => 'MyMPIStructBaseSerial',
  'CDAFacility' => 'MyMPIStructCDAFacility',
  'CabEmployee' => 'MyMPIStructCabEmployee',
  'Clinic' => 'MyMPIStructClinic',
  'CodeAndName' => 'MyMPIStructCodeAndName',
  'ContactInfo' => 'MyMPIStructContactInfo',
  'Container' => 'MyMPIStructContainer',
  'ContainerDocument' => 'MyMPIStructContainerDocument',
  'Decease' => 'MyMPIStructDecease',
  'Diagnosis' => 'MyMPIStructDiagnosis',
  'Disability' => 'MyMPIStructDisability',
  'DispensarySupervision' => 'MyMPIStructDispensarySupervision',
  'Document' => 'MyMPIStructDocument',
  'EmergencyInfo' => 'MyMPIStructEmergencyInfo',
  'EmergencyUnit' => 'MyMPIStructEmergencyUnit',
  'Employee' => 'MyMPIStructEmployee',
  'Encounter' => 'MyMPIStructEncounter',
  'HistoryEntry' => 'MyMPIStructHistoryEntry',
  'Identifier' => 'MyMPIStructIdentifier',
  'IdentityDocument' => 'MyMPIStructIdentityDocument',
  'Insurance' => 'MyMPIStructInsurance',
  'MedService' => 'MyMPIStructMedService',
  'Name' => 'MyMPIStructName',
  'Occupation' => 'MyMPIStructOccupation',
  'Patient' => 'MyMPIStructPatient',
  'Privilege' => 'MyMPIStructPrivilege',
  'PrivilegeDocument' => 'MyMPIStructPrivilegeDocument',
  'SickLeaveDocument' => 'MyMPIStructSickLeaveDocument',
  'Trustee' => 'MyMPIStructTrustee',
  'attendantGender' => 'MyMPIEnumAttendantGender',
  'bloodGroup' => 'MyMPIEnumBloodGroup',
  'disabilityGroup' => 'MyMPIEnumDisabilityGroup',
  'dwellingType' => 'MyMPIEnumDwellingType',
  'encType' => 'MyMPIEnumEncType',
  'gender' => 'MyMPIEnumGender',
);
    }
}
