<?php
/**
 * File for class MyMPIStructContactInfo
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructContactInfo originally named ContactInfo
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructContactInfo extends MyMPIStructBaseSerial
{
    /**
     * The homePhone
     * Meta informations extracted from the WSDL
     * - documentation : Домашний телефон ЕГИСЗ "Пациент" таблица данных адреса и контактов, поле №12
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $homePhone;
    /**
     * The cellPhone
     * Meta informations extracted from the WSDL
     * - documentation : Мобильный телефон
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $cellPhone;
    /**
     * The workPhone
     * Meta informations extracted from the WSDL
     * - documentation : Служебный телефон
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $workPhone;
    /**
     * The email
     * Meta informations extracted from the WSDL
     * - documentation : Адрес e-mail ЕГИСЗ "Пациент" таблица данных адреса и контактов, поле №13
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $email;
    /**
     * The contactInfoString
     * Meta informations extracted from the WSDL
     * - documentation : Контактная информация одной строкой
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $contactInfoString;
    /**
     * The fax
     * Meta informations extracted from the WSDL
     * - documentation : Факс СЭМД
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $fax;
    /**
     * Constructor method for ContactInfo
     * @see parent::__construct()
     * @param string $_homePhone
     * @param string $_cellPhone
     * @param string $_workPhone
     * @param string $_email
     * @param string $_contactInfoString
     * @param string $_fax
     * @return MyMPIStructContactInfo
     */
    public function __construct($_homePhone = NULL,$_cellPhone = NULL,$_workPhone = NULL,$_email = NULL,$_contactInfoString = NULL,$_fax = NULL)
    {
        MyMPIWsdlClass::__construct(array('homePhone'=>$_homePhone,'cellPhone'=>$_cellPhone,'workPhone'=>$_workPhone,'email'=>$_email,'contactInfoString'=>$_contactInfoString,'fax'=>$_fax),false);
    }
    /**
     * Get homePhone value
     * @return string|null
     */
    public function getHomePhone()
    {
        return $this->homePhone;
    }
    /**
     * Set homePhone value
     * @param string $_homePhone the homePhone
     * @return string
     */
    public function setHomePhone($_homePhone)
    {
        return ($this->homePhone = $_homePhone);
    }
    /**
     * Get cellPhone value
     * @return string|null
     */
    public function getCellPhone()
    {
        return $this->cellPhone;
    }
    /**
     * Set cellPhone value
     * @param string $_cellPhone the cellPhone
     * @return string
     */
    public function setCellPhone($_cellPhone)
    {
        return ($this->cellPhone = $_cellPhone);
    }
    /**
     * Get workPhone value
     * @return string|null
     */
    public function getWorkPhone()
    {
        return $this->workPhone;
    }
    /**
     * Set workPhone value
     * @param string $_workPhone the workPhone
     * @return string
     */
    public function setWorkPhone($_workPhone)
    {
        return ($this->workPhone = $_workPhone);
    }
    /**
     * Get email value
     * @return string|null
     */
    public function getEmail()
    {
        return $this->email;
    }
    /**
     * Set email value
     * @param string $_email the email
     * @return string
     */
    public function setEmail($_email)
    {
        return ($this->email = $_email);
    }
    /**
     * Get contactInfoString value
     * @return string|null
     */
    public function getContactInfoString()
    {
        return $this->contactInfoString;
    }
    /**
     * Set contactInfoString value
     * @param string $_contactInfoString the contactInfoString
     * @return string
     */
    public function setContactInfoString($_contactInfoString)
    {
        return ($this->contactInfoString = $_contactInfoString);
    }
    /**
     * Get fax value
     * @return string|null
     */
    public function getFax()
    {
        return $this->fax;
    }
    /**
     * Set fax value
     * @param string $_fax the fax
     * @return string
     */
    public function setFax($_fax)
    {
        return ($this->fax = $_fax);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructContactInfo
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
