<?php
/**
 * File for class MyMPIStructIdentifier
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructIdentifier originally named Identifier
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructIdentifier extends MyMPIStructBaseSerial
{
    /**
     * The ident
     * Meta informations extracted from the WSDL
     * - documentation : Идентификатор пациента
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $ident;
    /**
     * The identType
     * Meta informations extracted from the WSDL
     * - documentation : Тип идентификатора
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $identType;
    /**
     * The effectiveDate
     * Meta informations extracted from the WSDL
     * - documentation : Дата начала действия идентификатора
     * - minOccurs : 0
     * @var date
     */
    public $effectiveDate;
    /**
     * The expirationDate
     * Meta informations extracted from the WSDL
     * - documentation : Дата окончания действия идентификатора
     * - minOccurs : 0
     * @var date
     */
    public $expirationDate;
    /**
     * Constructor method for Identifier
     * @see parent::__construct()
     * @param string $_ident
     * @param MyMPIStructCodeAndName $_identType
     * @param date $_effectiveDate
     * @param date $_expirationDate
     * @return MyMPIStructIdentifier
     */
    public function __construct($_ident = NULL,$_identType = NULL,$_effectiveDate = NULL,$_expirationDate = NULL)
    {
        MyMPIWsdlClass::__construct(array('ident'=>$_ident,'identType'=>$_identType,'effectiveDate'=>$_effectiveDate,'expirationDate'=>$_expirationDate),false);
    }
    /**
     * Get ident value
     * @return string|null
     */
    public function getIdent()
    {
        return $this->ident;
    }
    /**
     * Set ident value
     * @param string $_ident the ident
     * @return string
     */
    public function setIdent($_ident)
    {
        return ($this->ident = $_ident);
    }
    /**
     * Get identType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getIdentType()
    {
        return $this->identType;
    }
    /**
     * Set identType value
     * @param MyMPIStructCodeAndName $_identType the identType
     * @return MyMPIStructCodeAndName
     */
    public function setIdentType($_identType)
    {
        return ($this->identType = $_identType);
    }
    /**
     * Get effectiveDate value
     * @return date|null
     */
    public function getEffectiveDate()
    {
        return $this->effectiveDate;
    }
    /**
     * Set effectiveDate value
     * @param date $_effectiveDate the effectiveDate
     * @return date
     */
    public function setEffectiveDate($_effectiveDate)
    {
        return ($this->effectiveDate = $_effectiveDate);
    }
    /**
     * Get expirationDate value
     * @return date|null
     */
    public function getExpirationDate()
    {
        return $this->expirationDate;
    }
    /**
     * Set expirationDate value
     * @param date $_expirationDate the expirationDate
     * @return date
     */
    public function setExpirationDate($_expirationDate)
    {
        return ($this->expirationDate = $_expirationDate);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructIdentifier
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
