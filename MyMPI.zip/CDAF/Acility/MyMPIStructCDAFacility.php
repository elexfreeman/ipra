<?php
/**
 * File for class MyMPIStructCDAFacility
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructCDAFacility originally named CDAFacility
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructCDAFacility extends MyMPIStructCodeAndName
{
    /**
     * The facilityAddress
     * Meta informations extracted from the WSDL
     * - documentation : Адрес ЛПУ
     * - minOccurs : 0
     * @var MyMPIStructAddress
     */
    public $facilityAddress;
    /**
     * The contactInfo
     * Meta informations extracted from the WSDL
     * - documentation : Контактные данные ЛПУ
     * - minOccurs : 0
     * @var MyMPIStructContactInfo
     */
    public $contactInfo;
    /**
     * Constructor method for CDAFacility
     * @see parent::__construct()
     * @param MyMPIStructAddress $_facilityAddress
     * @param MyMPIStructContactInfo $_contactInfo
     * @return MyMPIStructCDAFacility
     */
    public function __construct($_facilityAddress = NULL,$_contactInfo = NULL)
    {
        MyMPIWsdlClass::__construct(array('facilityAddress'=>$_facilityAddress,'contactInfo'=>$_contactInfo),false);
    }
    /**
     * Get facilityAddress value
     * @return MyMPIStructAddress|null
     */
    public function getFacilityAddress()
    {
        return $this->facilityAddress;
    }
    /**
     * Set facilityAddress value
     * @param MyMPIStructAddress $_facilityAddress the facilityAddress
     * @return MyMPIStructAddress
     */
    public function setFacilityAddress($_facilityAddress)
    {
        return ($this->facilityAddress = $_facilityAddress);
    }
    /**
     * Get contactInfo value
     * @return MyMPIStructContactInfo|null
     */
    public function getContactInfo()
    {
        return $this->contactInfo;
    }
    /**
     * Set contactInfo value
     * @param MyMPIStructContactInfo $_contactInfo the contactInfo
     * @return MyMPIStructContactInfo
     */
    public function setContactInfo($_contactInfo)
    {
        return ($this->contactInfo = $_contactInfo);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructCDAFacility
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
