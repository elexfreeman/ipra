<?php
/**
 * File for class MyMPIStructDocument
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructDocument originally named Document
 * Documentation : Документы
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructDocument extends MyMPIWsdlClass
{
    /**
     * The extId
     * Meta informations extracted from the WSDL
     * - documentation : Идентификатор документа, уникальный в рамках МИС
     * - minLength : 1
     * @var string
     */
    public $extId;
    /**
     * The encounterCode
     * Meta informations extracted from the WSDL
     * - documentation : Код эпизода (привязка к эпизоду обязательна в связи с необходимостью отправки СЭМД в фед ИЭМК) (26.08.2015 привязка к эпизоду НЕ обязательна в связи с необходимостью отправки в РИЭМК свидетельств о смерти)
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $encounterCode;
    /**
     * The enteredBy
     * Meta informations extracted from the WSDL
     * - documentation : Автор документа (указание автора обязательно в связи с необходимостью отправки СЭМД в фед ИЭМК)
     * @var MyMPIStructEmployee
     */
    public $enteredBy;
    /**
     * The enteredOn
     * Meta informations extracted from the WSDL
     * - documentation : Дата/время добавления документа в МИС
     * - minOccurs : 0
     * @var dateTime
     */
    public $enteredOn;
    /**
     * The noteText
     * Meta informations extracted from the WSDL
     * - documentation : Текст документа
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $noteText;
    /**
     * The docType
     * Meta informations extracted from the WSDL
     * - documentation : Тип документа PnR - "Отображаемое значение типа СЭМД ко классификатору 1.2.643.5.1.13.2.1.1.646" (SLM365) СЭМД - "Тип медицинского документа" - code/codeSystem=1.2.643.5.1.13.2.1.1.646 (1=Эпикриз стационара, 2=Амбулаторный эпикриз, 3=Направление)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $docType;
    /**
     * The docNum
     * Meta informations extracted from the WSDL
     * - documentation : Номер документа
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $docNum;
    /**
     * The docDate
     * Meta informations extracted from the WSDL
     * - documentation : Дата документа
     * - minOccurs : 0
     * @var date
     */
    public $docDate;
    /**
     * The docName
     * Meta informations extracted from the WSDL
     * - documentation : Название документа PnR - Name (Заголовок документа) СЭМД - title
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $docName;
    /**
     * The fileType
     * Meta informations extracted from the WSDL
     * - documentation : Тип файла
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $fileType;
    /**
     * The stream
     * Meta informations extracted from the WSDL
     * - documentation : Содержимое файла
     * - minOccurs : 0
     * @var base64Binary
     */
    public $stream;
    /**
     * Constructor method for Document
     * @see parent::__construct()
     * @param string $_extId
     * @param string $_encounterCode
     * @param MyMPIStructEmployee $_enteredBy
     * @param dateTime $_enteredOn
     * @param string $_noteText
     * @param MyMPIStructCodeAndName $_docType
     * @param string $_docNum
     * @param date $_docDate
     * @param string $_docName
     * @param string $_fileType
     * @param base64Binary $_stream
     * @return MyMPIStructDocument
     */
    public function __construct($_extId = NULL,$_encounterCode = NULL,$_enteredBy = NULL,$_enteredOn = NULL,$_noteText = NULL,$_docType = NULL,$_docNum = NULL,$_docDate = NULL,$_docName = NULL,$_fileType = NULL,$_stream = NULL)
    {
        parent::__construct(array('extId'=>$_extId,'encounterCode'=>$_encounterCode,'enteredBy'=>$_enteredBy,'enteredOn'=>$_enteredOn,'noteText'=>$_noteText,'docType'=>$_docType,'docNum'=>$_docNum,'docDate'=>$_docDate,'docName'=>$_docName,'fileType'=>$_fileType,'stream'=>$_stream),false);
    }
    /**
     * Get extId value
     * @return string|null
     */
    public function getExtId()
    {
        return $this->extId;
    }
    /**
     * Set extId value
     * @param string $_extId the extId
     * @return string
     */
    public function setExtId($_extId)
    {
        return ($this->extId = $_extId);
    }
    /**
     * Get encounterCode value
     * @return string|null
     */
    public function getEncounterCode()
    {
        return $this->encounterCode;
    }
    /**
     * Set encounterCode value
     * @param string $_encounterCode the encounterCode
     * @return string
     */
    public function setEncounterCode($_encounterCode)
    {
        return ($this->encounterCode = $_encounterCode);
    }
    /**
     * Get enteredBy value
     * @return MyMPIStructEmployee|null
     */
    public function getEnteredBy()
    {
        return $this->enteredBy;
    }
    /**
     * Set enteredBy value
     * @param MyMPIStructEmployee $_enteredBy the enteredBy
     * @return MyMPIStructEmployee
     */
    public function setEnteredBy($_enteredBy)
    {
        return ($this->enteredBy = $_enteredBy);
    }
    /**
     * Get enteredOn value
     * @return dateTime|null
     */
    public function getEnteredOn()
    {
        return $this->enteredOn;
    }
    /**
     * Set enteredOn value
     * @param dateTime $_enteredOn the enteredOn
     * @return dateTime
     */
    public function setEnteredOn($_enteredOn)
    {
        return ($this->enteredOn = $_enteredOn);
    }
    /**
     * Get noteText value
     * @return string|null
     */
    public function getNoteText()
    {
        return $this->noteText;
    }
    /**
     * Set noteText value
     * @param string $_noteText the noteText
     * @return string
     */
    public function setNoteText($_noteText)
    {
        return ($this->noteText = $_noteText);
    }
    /**
     * Get docType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getDocType()
    {
        return $this->docType;
    }
    /**
     * Set docType value
     * @param MyMPIStructCodeAndName $_docType the docType
     * @return MyMPIStructCodeAndName
     */
    public function setDocType($_docType)
    {
        return ($this->docType = $_docType);
    }
    /**
     * Get docNum value
     * @return string|null
     */
    public function getDocNum()
    {
        return $this->docNum;
    }
    /**
     * Set docNum value
     * @param string $_docNum the docNum
     * @return string
     */
    public function setDocNum($_docNum)
    {
        return ($this->docNum = $_docNum);
    }
    /**
     * Get docDate value
     * @return date|null
     */
    public function getDocDate()
    {
        return $this->docDate;
    }
    /**
     * Set docDate value
     * @param date $_docDate the docDate
     * @return date
     */
    public function setDocDate($_docDate)
    {
        return ($this->docDate = $_docDate);
    }
    /**
     * Get docName value
     * @return string|null
     */
    public function getDocName()
    {
        return $this->docName;
    }
    /**
     * Set docName value
     * @param string $_docName the docName
     * @return string
     */
    public function setDocName($_docName)
    {
        return ($this->docName = $_docName);
    }
    /**
     * Get fileType value
     * @return string|null
     */
    public function getFileType()
    {
        return $this->fileType;
    }
    /**
     * Set fileType value
     * @param string $_fileType the fileType
     * @return string
     */
    public function setFileType($_fileType)
    {
        return ($this->fileType = $_fileType);
    }
    /**
     * Get stream value
     * @return base64Binary|null
     */
    public function getStream()
    {
        return $this->stream;
    }
    /**
     * Set stream value
     * @param base64Binary $_stream the stream
     * @return base64Binary
     */
    public function setStream($_stream)
    {
        return ($this->stream = $_stream);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructDocument
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
