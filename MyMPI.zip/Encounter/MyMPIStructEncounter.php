<?php
/**
 * File for class MyMPIStructEncounter
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructEncounter originally named Encounter
 * Documentation : Эпизод (амбулаторное обращение или госпитализация)
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructEncounter extends MyMPIWsdlClass
{
    /**
     * The extId
     * Meta informations extracted from the WSDL
     * - documentation : Идентификатор эпизода, уникальный в рамках МИС
     * - minLength : 1
     * @var string
     */
    public $extId;
    /**
     * The enteredBy
     * Meta informations extracted from the WSDL
     * - documentation : Автор записи (врач) ТФОМС: IDDOKT (региональный справочник) - код врача, закрывшего талон/историю болезни ТФОМС: PRVS (V004) - специальность врача
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $enteredBy;
    /**
     * The enteredOn
     * Meta informations extracted from the WSDL
     * - documentation : Дата/время ввода записи в МИС
     * - minOccurs : 0
     * @var dateTime
     */
    public $enteredOn;
    /**
     * The encType
     * @var MyMPIEnumEncType
     */
    public $encType;
    /**
     * The paymentType
     * Meta informations extracted from the WSDL
     * - documentation : Вид оплаты (ОМС, бюджет, платные услуги, ДМС, ...) ф 025-12/у
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $paymentType;
    /**
     * The isAtHome
     * Meta informations extracted from the WSDL
     * - documentation : Признак "на дому" ф 025-12/у
     * - minOccurs : 0
     * @var boolean
     */
    public $isAtHome;
    /**
     * The encounterReason
     * Meta informations extracted from the WSDL
     * - documentation : Причина посещения/госпитализации (заболевание, профосмотр, патронаж, ..., плановая госпитализация, травма, ...) ф 025-12/у, 003/у
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $encounterReason;
    /**
     * The facilityDept
     * Meta informations extracted from the WSDL
     * - documentation : Отделение МО ТФОМС: LPUCODE - Подразделение МО лечения из регионального справочника
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $facilityDept;
    /**
     * The referralFacility
     * Meta informations extracted from the WSDL
     * - documentation : ЛПУ, направившее пациента ф 003/у ТФОМС: NPR_MO (F003)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $referralFacility;
    /**
     * The admissionInfo
     * Meta informations extracted from the WSDL
     * - documentation : Данные о госпитализации ф 003/у ТФОМС: EXTR (1 –плановая; 2 – экстренная госпитализация)
     * - minOccurs : 0
     * @var MyMPIStructAdmission
     */
    public $admissionInfo;
    /**
     * The emergencyInfo
     * Meta informations extracted from the WSDL
     * - documentation : Данные о вызове скорой помощи ф 109/у
     * - minOccurs : 0
     * @var MyMPIStructEmergencyInfo
     */
    public $emergencyInfo;
    /**
     * The encounterResult
     * Meta informations extracted from the WSDL
     * - documentation : Результат обращения/госпитализации ф 003/у, ф 025-12/у ТФОМС: RSLT (V009 - Классификатор результатов обращения за медицинской помощью) СЭМД стац: encompassingEncounter/dischargeDispositionCode - Классификатор исходов госпитализации (1.2.643.5.1.13.2.1.1.123 или 1.2.643.5.1.13.2.1.1.542?) ??? Для амб - 1.2.643.5.1.13.2.1.1.551 [Классификатор результатов обращения за медицинской помощью]
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $encounterResult;
    /**
     * The encounterOutcome
     * Meta informations extracted from the WSDL
     * - documentation : Исход заболевания ТФОМС: ISHOD (V012 - Классификатор исходов заболевания) СЭМД амб: encompassingEncounter/dischargeDispositionCode - 1.2.643.5.1.13.2.1.1.357 - Классификатор результатов госпитализации (исхода заболевания, причин выписки)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $encounterOutcome;
    /**
     * The finalAbilityToWork
     * Meta informations extracted from the WSDL
     * - documentation : Трудоспособность восстановлена полностью, снижена, временно утрачена, стойко утрачена в связи с данным заболеванием, с другими причинами ф 003/у
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $finalAbilityToWork;
    /**
     * The careType
     * Meta informations extracted from the WSDL
     * - documentation : Вид помощи (V008) ТФОМС: VIDPOM
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $careType;
    /**
     * The mes
     * Meta informations extracted from the WSDL
     * - documentation : Коды МЭС ТФОМС: CODE_MES1, CODE_MES2
     * - minOccurs : 0
     * @var MyMPIStructArrayOfmesCodeString
     */
    public $mes;
    /**
     * The recordNumber
     * Meta informations extracted from the WSDL
     * - documentation : Номер истории болезни (номер медицинской карты) СЭМД
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $recordNumber;
    /**
     * The fromTime
     * Meta informations extracted from the WSDL
     * - documentation : Дата/время начала лечения ТФОМС: BEGDATE - Дата начала лечения
     * @var dateTime
     */
    public $fromTime;
    /**
     * The toTime
     * Meta informations extracted from the WSDL
     * - documentation : Дата/время окончания лечения ТФОМС: ENDDATE - Дата окончания лечения
     * - minOccurs : 0
     * @var dateTime
     */
    public $toTime;
    /**
     * Constructor method for Encounter
     * @see parent::__construct()
     * @param string $_extId
     * @param MyMPIStructEmployee $_enteredBy
     * @param dateTime $_enteredOn
     * @param MyMPIEnumEncType $_encType
     * @param MyMPIStructCodeAndName $_paymentType
     * @param boolean $_isAtHome
     * @param MyMPIStructCodeAndName $_encounterReason
     * @param MyMPIStructCodeAndName $_facilityDept
     * @param MyMPIStructCodeAndName $_referralFacility
     * @param MyMPIStructAdmission $_admissionInfo
     * @param MyMPIStructEmergencyInfo $_emergencyInfo
     * @param MyMPIStructCodeAndName $_encounterResult
     * @param MyMPIStructCodeAndName $_encounterOutcome
     * @param MyMPIStructCodeAndName $_finalAbilityToWork
     * @param MyMPIStructCodeAndName $_careType
     * @param MyMPIStructArrayOfmesCodeString $_mes
     * @param string $_recordNumber
     * @param dateTime $_fromTime
     * @param dateTime $_toTime
     * @return MyMPIStructEncounter
     */
    public function __construct($_extId = NULL,$_enteredBy = NULL,$_enteredOn = NULL,$_encType = NULL,$_paymentType = NULL,$_isAtHome = NULL,$_encounterReason = NULL,$_facilityDept = NULL,$_referralFacility = NULL,$_admissionInfo = NULL,$_emergencyInfo = NULL,$_encounterResult = NULL,$_encounterOutcome = NULL,$_finalAbilityToWork = NULL,$_careType = NULL,$_mes = NULL,$_recordNumber = NULL,$_fromTime = NULL,$_toTime = NULL)
    {
        parent::__construct(array('extId'=>$_extId,'enteredBy'=>$_enteredBy,'enteredOn'=>$_enteredOn,'encType'=>$_encType,'paymentType'=>$_paymentType,'isAtHome'=>$_isAtHome,'encounterReason'=>$_encounterReason,'facilityDept'=>$_facilityDept,'referralFacility'=>$_referralFacility,'admissionInfo'=>$_admissionInfo,'emergencyInfo'=>$_emergencyInfo,'encounterResult'=>$_encounterResult,'encounterOutcome'=>$_encounterOutcome,'finalAbilityToWork'=>$_finalAbilityToWork,'careType'=>$_careType,'mes'=>($_mes instanceof MyMPIStructArrayOfmesCodeString)?$_mes:new MyMPIStructArrayOfmesCodeString($_mes),'recordNumber'=>$_recordNumber,'fromTime'=>$_fromTime,'toTime'=>$_toTime),false);
    }
    /**
     * Get extId value
     * @return string|null
     */
    public function getExtId()
    {
        return $this->extId;
    }
    /**
     * Set extId value
     * @param string $_extId the extId
     * @return string
     */
    public function setExtId($_extId)
    {
        return ($this->extId = $_extId);
    }
    /**
     * Get enteredBy value
     * @return MyMPIStructEmployee|null
     */
    public function getEnteredBy()
    {
        return $this->enteredBy;
    }
    /**
     * Set enteredBy value
     * @param MyMPIStructEmployee $_enteredBy the enteredBy
     * @return MyMPIStructEmployee
     */
    public function setEnteredBy($_enteredBy)
    {
        return ($this->enteredBy = $_enteredBy);
    }
    /**
     * Get enteredOn value
     * @return dateTime|null
     */
    public function getEnteredOn()
    {
        return $this->enteredOn;
    }
    /**
     * Set enteredOn value
     * @param dateTime $_enteredOn the enteredOn
     * @return dateTime
     */
    public function setEnteredOn($_enteredOn)
    {
        return ($this->enteredOn = $_enteredOn);
    }
    /**
     * Get encType value
     * @return MyMPIEnumEncType|null
     */
    public function getEncType()
    {
        return $this->encType;
    }
    /**
     * Set encType value
     * @uses MyMPIEnumEncType::valueIsValid()
     * @param MyMPIEnumEncType $_encType the encType
     * @return MyMPIEnumEncType
     */
    public function setEncType($_encType)
    {
        if(!MyMPIEnumEncType::valueIsValid($_encType))
        {
            return false;
        }
        return ($this->encType = $_encType);
    }
    /**
     * Get paymentType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getPaymentType()
    {
        return $this->paymentType;
    }
    /**
     * Set paymentType value
     * @param MyMPIStructCodeAndName $_paymentType the paymentType
     * @return MyMPIStructCodeAndName
     */
    public function setPaymentType($_paymentType)
    {
        return ($this->paymentType = $_paymentType);
    }
    /**
     * Get isAtHome value
     * @return boolean|null
     */
    public function getIsAtHome()
    {
        return $this->isAtHome;
    }
    /**
     * Set isAtHome value
     * @param boolean $_isAtHome the isAtHome
     * @return boolean
     */
    public function setIsAtHome($_isAtHome)
    {
        return ($this->isAtHome = $_isAtHome);
    }
    /**
     * Get encounterReason value
     * @return MyMPIStructCodeAndName|null
     */
    public function getEncounterReason()
    {
        return $this->encounterReason;
    }
    /**
     * Set encounterReason value
     * @param MyMPIStructCodeAndName $_encounterReason the encounterReason
     * @return MyMPIStructCodeAndName
     */
    public function setEncounterReason($_encounterReason)
    {
        return ($this->encounterReason = $_encounterReason);
    }
    /**
     * Get facilityDept value
     * @return MyMPIStructCodeAndName|null
     */
    public function getFacilityDept()
    {
        return $this->facilityDept;
    }
    /**
     * Set facilityDept value
     * @param MyMPIStructCodeAndName $_facilityDept the facilityDept
     * @return MyMPIStructCodeAndName
     */
    public function setFacilityDept($_facilityDept)
    {
        return ($this->facilityDept = $_facilityDept);
    }
    /**
     * Get referralFacility value
     * @return MyMPIStructCodeAndName|null
     */
    public function getReferralFacility()
    {
        return $this->referralFacility;
    }
    /**
     * Set referralFacility value
     * @param MyMPIStructCodeAndName $_referralFacility the referralFacility
     * @return MyMPIStructCodeAndName
     */
    public function setReferralFacility($_referralFacility)
    {
        return ($this->referralFacility = $_referralFacility);
    }
    /**
     * Get admissionInfo value
     * @return MyMPIStructAdmission|null
     */
    public function getAdmissionInfo()
    {
        return $this->admissionInfo;
    }
    /**
     * Set admissionInfo value
     * @param MyMPIStructAdmission $_admissionInfo the admissionInfo
     * @return MyMPIStructAdmission
     */
    public function setAdmissionInfo($_admissionInfo)
    {
        return ($this->admissionInfo = $_admissionInfo);
    }
    /**
     * Get emergencyInfo value
     * @return MyMPIStructEmergencyInfo|null
     */
    public function getEmergencyInfo()
    {
        return $this->emergencyInfo;
    }
    /**
     * Set emergencyInfo value
     * @param MyMPIStructEmergencyInfo $_emergencyInfo the emergencyInfo
     * @return MyMPIStructEmergencyInfo
     */
    public function setEmergencyInfo($_emergencyInfo)
    {
        return ($this->emergencyInfo = $_emergencyInfo);
    }
    /**
     * Get encounterResult value
     * @return MyMPIStructCodeAndName|null
     */
    public function getEncounterResult()
    {
        return $this->encounterResult;
    }
    /**
     * Set encounterResult value
     * @param MyMPIStructCodeAndName $_encounterResult the encounterResult
     * @return MyMPIStructCodeAndName
     */
    public function setEncounterResult($_encounterResult)
    {
        return ($this->encounterResult = $_encounterResult);
    }
    /**
     * Get encounterOutcome value
     * @return MyMPIStructCodeAndName|null
     */
    public function getEncounterOutcome()
    {
        return $this->encounterOutcome;
    }
    /**
     * Set encounterOutcome value
     * @param MyMPIStructCodeAndName $_encounterOutcome the encounterOutcome
     * @return MyMPIStructCodeAndName
     */
    public function setEncounterOutcome($_encounterOutcome)
    {
        return ($this->encounterOutcome = $_encounterOutcome);
    }
    /**
     * Get finalAbilityToWork value
     * @return MyMPIStructCodeAndName|null
     */
    public function getFinalAbilityToWork()
    {
        return $this->finalAbilityToWork;
    }
    /**
     * Set finalAbilityToWork value
     * @param MyMPIStructCodeAndName $_finalAbilityToWork the finalAbilityToWork
     * @return MyMPIStructCodeAndName
     */
    public function setFinalAbilityToWork($_finalAbilityToWork)
    {
        return ($this->finalAbilityToWork = $_finalAbilityToWork);
    }
    /**
     * Get careType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getCareType()
    {
        return $this->careType;
    }
    /**
     * Set careType value
     * @param MyMPIStructCodeAndName $_careType the careType
     * @return MyMPIStructCodeAndName
     */
    public function setCareType($_careType)
    {
        return ($this->careType = $_careType);
    }
    /**
     * Get mes value
     * @return MyMPIStructArrayOfmesCodeString|null
     */
    public function getMes()
    {
        return $this->mes;
    }
    /**
     * Set mes value
     * @param MyMPIStructArrayOfmesCodeString $_mes the mes
     * @return MyMPIStructArrayOfmesCodeString
     */
    public function setMes($_mes)
    {
        return ($this->mes = $_mes);
    }
    /**
     * Get recordNumber value
     * @return string|null
     */
    public function getRecordNumber()
    {
        return $this->recordNumber;
    }
    /**
     * Set recordNumber value
     * @param string $_recordNumber the recordNumber
     * @return string
     */
    public function setRecordNumber($_recordNumber)
    {
        return ($this->recordNumber = $_recordNumber);
    }
    /**
     * Get fromTime value
     * @return dateTime|null
     */
    public function getFromTime()
    {
        return $this->fromTime;
    }
    /**
     * Set fromTime value
     * @param dateTime $_fromTime the fromTime
     * @return dateTime
     */
    public function setFromTime($_fromTime)
    {
        return ($this->fromTime = $_fromTime);
    }
    /**
     * Get toTime value
     * @return dateTime|null
     */
    public function getToTime()
    {
        return $this->toTime;
    }
    /**
     * Set toTime value
     * @param dateTime $_toTime the toTime
     * @return dateTime
     */
    public function setToTime($_toTime)
    {
        return ($this->toTime = $_toTime);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructEncounter
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
