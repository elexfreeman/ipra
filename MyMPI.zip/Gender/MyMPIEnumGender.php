<?php
/**
 * File for class MyMPIEnumGender
 * @package MyMPI
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIEnumGender originally named gender
 * Documentation : Пол ТФОМС: W (V005: 1=M, 2=F) deprecated: ЕГИСЗ codeSystem: 2.16.643.1.113883.5.1 ЕГИСЗ "Пациент" поле №11 СЭМД codeSystem: 1.2.643.5.1.13.2.1.1.156 /C51007 (1=M, 2=F, 3=Не определенный)
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIEnumGender extends MyMPIWsdlClass
{
    /**
     * Constant for value 'M'
     * @return string 'M'
     */
    const VALUE_M = 'M';
    /**
     * Constant for value 'F'
     * @return string 'F'
     */
    const VALUE_F = 'F';
    /**
     * Return true if value is allowed
     * @uses MyMPIEnumGender::VALUE_M
     * @uses MyMPIEnumGender::VALUE_F
     * @param mixed $_value value
     * @return bool true|false
     */
    public static function valueIsValid($_value)
    {
        return in_array($_value,array(MyMPIEnumGender::VALUE_M,MyMPIEnumGender::VALUE_F));
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
