<?php
/**
 * File for class MyMPIStructDisability
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructDisability originally named Disability
 * Documentation : Инвалидность
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructDisability extends MyMPIWsdlClass
{
    /**
     * The extId
     * Meta informations extracted from the WSDL
     * - documentation : Идентификатор в МИС
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $extId;
    /**
     * The encounterCode
     * Meta informations extracted from the WSDL
     * - documentation : Код эпизода
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $encounterCode;
    /**
     * The enteredBy
     * Meta informations extracted from the WSDL
     * - documentation : Автор записи (врач) ТФОМС: IDDOKT (региональный справочник), PRVS (V004) - специальность
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $enteredBy;
    /**
     * The enteredOn
     * Meta informations extracted from the WSDL
     * - documentation : Дата/время ввода записи в МИС
     * - minOccurs : 0
     * @var dateTime
     */
    public $enteredOn;
    /**
     * The disabilityGroup
     * @var MyMPIEnumDisabilityGroup
     */
    public $disabilityGroup;
    /**
     * The isDisabledChild
     * Meta informations extracted from the WSDL
     * - documentation : Признак ребенок-инвалид ф 025-12/у
     * - minOccurs : 0
     * @var boolean
     */
    public $isDisabledChild;
    /**
     * The disabilityCause
     * Meta informations extracted from the WSDL
     * - documentation : Причина инвалидности (инвалид с детства, заболевание, трудовое увечье, военная травма, инвалидность, связанная с катастрофой на Чернобыльской АЭС, ...)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $disabilityCause;
    /**
     * The diagnosis
     * Meta informations extracted from the WSDL
     * - documentation : Диагноз (код МКБ-10 и расшифровка)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $diagnosis;
    /**
     * The disabilityLevel
     * Meta informations extracted from the WSDL
     * - documentation : Степень инвалидности ф 025-12/у
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $disabilityLevel;
    /**
     * The isFirstTime
     * Meta informations extracted from the WSDL
     * - documentation : Установлена впервые в жизни ф 025-12/у
     * - minOccurs : 0
     * @var boolean
     */
    public $isFirstTime;
    /**
     * The cancelReason
     * Meta informations extracted from the WSDL
     * - documentation : Причина снятия инвалидности
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $cancelReason;
    /**
     * The fromTime
     * Meta informations extracted from the WSDL
     * - documentation : Действует с
     * - minOccurs : 0
     * @var dateTime
     */
    public $fromTime;
    /**
     * The toTime
     * Meta informations extracted from the WSDL
     * - documentation : Действует по
     * - minOccurs : 0
     * @var dateTime
     */
    public $toTime;
    /**
     * Constructor method for Disability
     * @see parent::__construct()
     * @param string $_extId
     * @param string $_encounterCode
     * @param MyMPIStructEmployee $_enteredBy
     * @param dateTime $_enteredOn
     * @param MyMPIEnumDisabilityGroup $_disabilityGroup
     * @param boolean $_isDisabledChild
     * @param MyMPIStructCodeAndName $_disabilityCause
     * @param MyMPIStructCodeAndName $_diagnosis
     * @param MyMPIStructCodeAndName $_disabilityLevel
     * @param boolean $_isFirstTime
     * @param MyMPIStructCodeAndName $_cancelReason
     * @param dateTime $_fromTime
     * @param dateTime $_toTime
     * @return MyMPIStructDisability
     */
    public function __construct($_extId = NULL,$_encounterCode = NULL,$_enteredBy = NULL,$_enteredOn = NULL,$_disabilityGroup = NULL,$_isDisabledChild = NULL,$_disabilityCause = NULL,$_diagnosis = NULL,$_disabilityLevel = NULL,$_isFirstTime = NULL,$_cancelReason = NULL,$_fromTime = NULL,$_toTime = NULL)
    {
        parent::__construct(array('extId'=>$_extId,'encounterCode'=>$_encounterCode,'enteredBy'=>$_enteredBy,'enteredOn'=>$_enteredOn,'disabilityGroup'=>$_disabilityGroup,'isDisabledChild'=>$_isDisabledChild,'disabilityCause'=>$_disabilityCause,'diagnosis'=>$_diagnosis,'disabilityLevel'=>$_disabilityLevel,'isFirstTime'=>$_isFirstTime,'cancelReason'=>$_cancelReason,'fromTime'=>$_fromTime,'toTime'=>$_toTime),false);
    }
    /**
     * Get extId value
     * @return string|null
     */
    public function getExtId()
    {
        return $this->extId;
    }
    /**
     * Set extId value
     * @param string $_extId the extId
     * @return string
     */
    public function setExtId($_extId)
    {
        return ($this->extId = $_extId);
    }
    /**
     * Get encounterCode value
     * @return string|null
     */
    public function getEncounterCode()
    {
        return $this->encounterCode;
    }
    /**
     * Set encounterCode value
     * @param string $_encounterCode the encounterCode
     * @return string
     */
    public function setEncounterCode($_encounterCode)
    {
        return ($this->encounterCode = $_encounterCode);
    }
    /**
     * Get enteredBy value
     * @return MyMPIStructEmployee|null
     */
    public function getEnteredBy()
    {
        return $this->enteredBy;
    }
    /**
     * Set enteredBy value
     * @param MyMPIStructEmployee $_enteredBy the enteredBy
     * @return MyMPIStructEmployee
     */
    public function setEnteredBy($_enteredBy)
    {
        return ($this->enteredBy = $_enteredBy);
    }
    /**
     * Get enteredOn value
     * @return dateTime|null
     */
    public function getEnteredOn()
    {
        return $this->enteredOn;
    }
    /**
     * Set enteredOn value
     * @param dateTime $_enteredOn the enteredOn
     * @return dateTime
     */
    public function setEnteredOn($_enteredOn)
    {
        return ($this->enteredOn = $_enteredOn);
    }
    /**
     * Get disabilityGroup value
     * @return MyMPIEnumDisabilityGroup|null
     */
    public function getDisabilityGroup()
    {
        return $this->disabilityGroup;
    }
    /**
     * Set disabilityGroup value
     * @uses MyMPIEnumDisabilityGroup::valueIsValid()
     * @param MyMPIEnumDisabilityGroup $_disabilityGroup the disabilityGroup
     * @return MyMPIEnumDisabilityGroup
     */
    public function setDisabilityGroup($_disabilityGroup)
    {
        if(!MyMPIEnumDisabilityGroup::valueIsValid($_disabilityGroup))
        {
            return false;
        }
        return ($this->disabilityGroup = $_disabilityGroup);
    }
    /**
     * Get isDisabledChild value
     * @return boolean|null
     */
    public function getIsDisabledChild()
    {
        return $this->isDisabledChild;
    }
    /**
     * Set isDisabledChild value
     * @param boolean $_isDisabledChild the isDisabledChild
     * @return boolean
     */
    public function setIsDisabledChild($_isDisabledChild)
    {
        return ($this->isDisabledChild = $_isDisabledChild);
    }
    /**
     * Get disabilityCause value
     * @return MyMPIStructCodeAndName|null
     */
    public function getDisabilityCause()
    {
        return $this->disabilityCause;
    }
    /**
     * Set disabilityCause value
     * @param MyMPIStructCodeAndName $_disabilityCause the disabilityCause
     * @return MyMPIStructCodeAndName
     */
    public function setDisabilityCause($_disabilityCause)
    {
        return ($this->disabilityCause = $_disabilityCause);
    }
    /**
     * Get diagnosis value
     * @return MyMPIStructCodeAndName|null
     */
    public function getDiagnosis()
    {
        return $this->diagnosis;
    }
    /**
     * Set diagnosis value
     * @param MyMPIStructCodeAndName $_diagnosis the diagnosis
     * @return MyMPIStructCodeAndName
     */
    public function setDiagnosis($_diagnosis)
    {
        return ($this->diagnosis = $_diagnosis);
    }
    /**
     * Get disabilityLevel value
     * @return MyMPIStructCodeAndName|null
     */
    public function getDisabilityLevel()
    {
        return $this->disabilityLevel;
    }
    /**
     * Set disabilityLevel value
     * @param MyMPIStructCodeAndName $_disabilityLevel the disabilityLevel
     * @return MyMPIStructCodeAndName
     */
    public function setDisabilityLevel($_disabilityLevel)
    {
        return ($this->disabilityLevel = $_disabilityLevel);
    }
    /**
     * Get isFirstTime value
     * @return boolean|null
     */
    public function getIsFirstTime()
    {
        return $this->isFirstTime;
    }
    /**
     * Set isFirstTime value
     * @param boolean $_isFirstTime the isFirstTime
     * @return boolean
     */
    public function setIsFirstTime($_isFirstTime)
    {
        return ($this->isFirstTime = $_isFirstTime);
    }
    /**
     * Get cancelReason value
     * @return MyMPIStructCodeAndName|null
     */
    public function getCancelReason()
    {
        return $this->cancelReason;
    }
    /**
     * Set cancelReason value
     * @param MyMPIStructCodeAndName $_cancelReason the cancelReason
     * @return MyMPIStructCodeAndName
     */
    public function setCancelReason($_cancelReason)
    {
        return ($this->cancelReason = $_cancelReason);
    }
    /**
     * Get fromTime value
     * @return dateTime|null
     */
    public function getFromTime()
    {
        return $this->fromTime;
    }
    /**
     * Set fromTime value
     * @param dateTime $_fromTime the fromTime
     * @return dateTime
     */
    public function setFromTime($_fromTime)
    {
        return ($this->fromTime = $_fromTime);
    }
    /**
     * Get toTime value
     * @return dateTime|null
     */
    public function getToTime()
    {
        return $this->toTime;
    }
    /**
     * Set toTime value
     * @param dateTime $_toTime the toTime
     * @return dateTime
     */
    public function setToTime($_toTime)
    {
        return ($this->toTime = $_toTime);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructDisability
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
