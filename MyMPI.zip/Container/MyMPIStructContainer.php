<?php
/**
 * File for class MyMPIStructContainer
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructContainer originally named Container
 * Documentation : Пакет данных, поступивший от МИС
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructContainer extends MyMPIWsdlClass
{
    /**
     * The facilityCode
     * Meta informations extracted from the WSDL
     * - documentation : Код ЛПУ ЕГИСЗ справочник 1.2.643.5.1.13.2.1.1.178 (MDR308)
     * - use : required
     * - minLength : 1
     * @var string
     */
    public $facilityCode;
    /**
     * The patientMRN
     * Meta informations extracted from the WSDL
     * - documentation : Идентификатор пациента в МИС ЛПУ
     * - use : required
     * - minLength : 1
     * @var string
     */
    public $patientMRN;
    /**
     * The patient
     * Meta informations extracted from the WSDL
     * - documentation : Пациент
     * - minOccurs : 0
     * @var MyMPIStructPatient
     */
    public $patient;
    /**
     * The sourceDocument
     * Meta informations extracted from the WSDL
     * - documentation : Документ, в рамках которого поступили данные
     * - minOccurs : 0
     * @var MyMPIStructContainerDocument
     */
    public $sourceDocument;
    /**
     * The encounters
     * Meta informations extracted from the WSDL
     * - documentation : Эпизоды
     * - minOccurs : 0
     * @var MyMPIStructArrayOfencounterEncounter
     */
    public $encounters;
    /**
     * The diagnoses
     * Meta informations extracted from the WSDL
     * - documentation : Диагнозы
     * - minOccurs : 0
     * @var MyMPIStructArrayOfdiagnosisDiagnosis
     */
    public $diagnoses;
    /**
     * The disabilities
     * Meta informations extracted from the WSDL
     * - documentation : Инвалидность
     * - minOccurs : 0
     * @var MyMPIStructArrayOfdisabilityDisability
     */
    public $disabilities;
    /**
     * The sickLeaveDocuments
     * Meta informations extracted from the WSDL
     * - documentation : Документы временной нетрудоспособности
     * - minOccurs : 0
     * @var MyMPIStructArrayOfsickLeaveDocumentSickLeaveDocument
     */
    public $sickLeaveDocuments;
    /**
     * The allergies
     * Meta informations extracted from the WSDL
     * - documentation : Аллергические реакции и лекарственная непереносимость
     * - minOccurs : 0
     * @var MyMPIStructArrayOfallergyAllergy
     */
    public $allergies;
    /**
     * The documents
     * Meta informations extracted from the WSDL
     * - documentation : Документы (в том числе эпикризы, дневниковые записи, ...)
     * - minOccurs : 0
     * @var MyMPIStructArrayOfdocumentDocument
     */
    public $documents;
    /**
     * The services
     * Meta informations extracted from the WSDL
     * - documentation : Мед. услуги
     * - minOccurs : 0
     * @var MyMPIStructArrayOfserviceMedService
     */
    public $services;
    /**
     * The deceaseInfo
     * Meta informations extracted from the WSDL
     * - documentation : Информация о смерти
     * - minOccurs : 0
     * @var MyMPIStructArrayOfdeceaseDecease
     */
    public $deceaseInfo;
    /**
     * Constructor method for Container
     * @see parent::__construct()
     * @param string $_facilityCode
     * @param string $_patientMRN
     * @param MyMPIStructPatient $_patient
     * @param MyMPIStructContainerDocument $_sourceDocument
     * @param MyMPIStructArrayOfencounterEncounter $_encounters
     * @param MyMPIStructArrayOfdiagnosisDiagnosis $_diagnoses
     * @param MyMPIStructArrayOfdisabilityDisability $_disabilities
     * @param MyMPIStructArrayOfsickLeaveDocumentSickLeaveDocument $_sickLeaveDocuments
     * @param MyMPIStructArrayOfallergyAllergy $_allergies
     * @param MyMPIStructArrayOfdocumentDocument $_documents
     * @param MyMPIStructArrayOfserviceMedService $_services
     * @param MyMPIStructArrayOfdeceaseDecease $_deceaseInfo
     * @return MyMPIStructContainer
     */
    public function __construct($_facilityCode,$_patientMRN,$_patient = NULL,$_sourceDocument = NULL,$_encounters = NULL,$_diagnoses = NULL,$_disabilities = NULL,$_sickLeaveDocuments = NULL,$_allergies = NULL,$_documents = NULL,$_services = NULL,$_deceaseInfo = NULL)
    {
        parent::__construct(array('facilityCode'=>$_facilityCode,'patientMRN'=>$_patientMRN,'patient'=>$_patient,'sourceDocument'=>$_sourceDocument,'encounters'=>($_encounters instanceof MyMPIStructArrayOfencounterEncounter)?$_encounters:new MyMPIStructArrayOfencounterEncounter($_encounters),'diagnoses'=>($_diagnoses instanceof MyMPIStructArrayOfdiagnosisDiagnosis)?$_diagnoses:new MyMPIStructArrayOfdiagnosisDiagnosis($_diagnoses),'disabilities'=>($_disabilities instanceof MyMPIStructArrayOfdisabilityDisability)?$_disabilities:new MyMPIStructArrayOfdisabilityDisability($_disabilities),'sickLeaveDocuments'=>($_sickLeaveDocuments instanceof MyMPIStructArrayOfsickLeaveDocumentSickLeaveDocument)?$_sickLeaveDocuments:new MyMPIStructArrayOfsickLeaveDocumentSickLeaveDocument($_sickLeaveDocuments),'allergies'=>($_allergies instanceof MyMPIStructArrayOfallergyAllergy)?$_allergies:new MyMPIStructArrayOfallergyAllergy($_allergies),'documents'=>($_documents instanceof MyMPIStructArrayOfdocumentDocument)?$_documents:new MyMPIStructArrayOfdocumentDocument($_documents),'services'=>($_services instanceof MyMPIStructArrayOfserviceMedService)?$_services:new MyMPIStructArrayOfserviceMedService($_services),'deceaseInfo'=>($_deceaseInfo instanceof MyMPIStructArrayOfdeceaseDecease)?$_deceaseInfo:new MyMPIStructArrayOfdeceaseDecease($_deceaseInfo)),false);
    }
    /**
     * Get facilityCode value
     * @return string
     */
    public function getFacilityCode()
    {
        return $this->facilityCode;
    }
    /**
     * Set facilityCode value
     * @param string $_facilityCode the facilityCode
     * @return string
     */
    public function setFacilityCode($_facilityCode)
    {
        return ($this->facilityCode = $_facilityCode);
    }
    /**
     * Get patientMRN value
     * @return string
     */
    public function getPatientMRN()
    {
        return $this->patientMRN;
    }
    /**
     * Set patientMRN value
     * @param string $_patientMRN the patientMRN
     * @return string
     */
    public function setPatientMRN($_patientMRN)
    {
        return ($this->patientMRN = $_patientMRN);
    }
    /**
     * Get patient value
     * @return MyMPIStructPatient|null
     */
    public function getPatient()
    {
        return $this->patient;
    }
    /**
     * Set patient value
     * @param MyMPIStructPatient $_patient the patient
     * @return MyMPIStructPatient
     */
    public function setPatient($_patient)
    {
        return ($this->patient = $_patient);
    }
    /**
     * Get sourceDocument value
     * @return MyMPIStructContainerDocument|null
     */
    public function getSourceDocument()
    {
        return $this->sourceDocument;
    }
    /**
     * Set sourceDocument value
     * @param MyMPIStructContainerDocument $_sourceDocument the sourceDocument
     * @return MyMPIStructContainerDocument
     */
    public function setSourceDocument($_sourceDocument)
    {
        return ($this->sourceDocument = $_sourceDocument);
    }
    /**
     * Get encounters value
     * @return MyMPIStructArrayOfencounterEncounter|null
     */
    public function getEncounters()
    {
        return $this->encounters;
    }
    /**
     * Set encounters value
     * @param MyMPIStructArrayOfencounterEncounter $_encounters the encounters
     * @return MyMPIStructArrayOfencounterEncounter
     */
    public function setEncounters($_encounters)
    {
        return ($this->encounters = $_encounters);
    }
    /**
     * Get diagnoses value
     * @return MyMPIStructArrayOfdiagnosisDiagnosis|null
     */
    public function getDiagnoses()
    {
        return $this->diagnoses;
    }
    /**
     * Set diagnoses value
     * @param MyMPIStructArrayOfdiagnosisDiagnosis $_diagnoses the diagnoses
     * @return MyMPIStructArrayOfdiagnosisDiagnosis
     */
    public function setDiagnoses($_diagnoses)
    {
        return ($this->diagnoses = $_diagnoses);
    }
    /**
     * Get disabilities value
     * @return MyMPIStructArrayOfdisabilityDisability|null
     */
    public function getDisabilities()
    {
        return $this->disabilities;
    }
    /**
     * Set disabilities value
     * @param MyMPIStructArrayOfdisabilityDisability $_disabilities the disabilities
     * @return MyMPIStructArrayOfdisabilityDisability
     */
    public function setDisabilities($_disabilities)
    {
        return ($this->disabilities = $_disabilities);
    }
    /**
     * Get sickLeaveDocuments value
     * @return MyMPIStructArrayOfsickLeaveDocumentSickLeaveDocument|null
     */
    public function getSickLeaveDocuments()
    {
        return $this->sickLeaveDocuments;
    }
    /**
     * Set sickLeaveDocuments value
     * @param MyMPIStructArrayOfsickLeaveDocumentSickLeaveDocument $_sickLeaveDocuments the sickLeaveDocuments
     * @return MyMPIStructArrayOfsickLeaveDocumentSickLeaveDocument
     */
    public function setSickLeaveDocuments($_sickLeaveDocuments)
    {
        return ($this->sickLeaveDocuments = $_sickLeaveDocuments);
    }
    /**
     * Get allergies value
     * @return MyMPIStructArrayOfallergyAllergy|null
     */
    public function getAllergies()
    {
        return $this->allergies;
    }
    /**
     * Set allergies value
     * @param MyMPIStructArrayOfallergyAllergy $_allergies the allergies
     * @return MyMPIStructArrayOfallergyAllergy
     */
    public function setAllergies($_allergies)
    {
        return ($this->allergies = $_allergies);
    }
    /**
     * Get documents value
     * @return MyMPIStructArrayOfdocumentDocument|null
     */
    public function getDocuments()
    {
        return $this->documents;
    }
    /**
     * Set documents value
     * @param MyMPIStructArrayOfdocumentDocument $_documents the documents
     * @return MyMPIStructArrayOfdocumentDocument
     */
    public function setDocuments($_documents)
    {
        return ($this->documents = $_documents);
    }
    /**
     * Get services value
     * @return MyMPIStructArrayOfserviceMedService|null
     */
    public function getServices()
    {
        return $this->services;
    }
    /**
     * Set services value
     * @param MyMPIStructArrayOfserviceMedService $_services the services
     * @return MyMPIStructArrayOfserviceMedService
     */
    public function setServices($_services)
    {
        return ($this->services = $_services);
    }
    /**
     * Get deceaseInfo value
     * @return MyMPIStructArrayOfdeceaseDecease|null
     */
    public function getDeceaseInfo()
    {
        return $this->deceaseInfo;
    }
    /**
     * Set deceaseInfo value
     * @param MyMPIStructArrayOfdeceaseDecease $_deceaseInfo the deceaseInfo
     * @return MyMPIStructArrayOfdeceaseDecease
     */
    public function setDeceaseInfo($_deceaseInfo)
    {
        return ($this->deceaseInfo = $_deceaseInfo);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructContainer
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
