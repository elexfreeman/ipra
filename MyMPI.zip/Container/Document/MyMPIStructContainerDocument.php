<?php
/**
 * File for class MyMPIStructContainerDocument
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructContainerDocument originally named ContainerDocument
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructContainerDocument extends MyMPIStructBaseSerial
{
    /**
     * The docType
     * Meta informations extracted from the WSDL
     * - documentation : Тип документа
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $docType;
    /**
     * The docNum
     * Meta informations extracted from the WSDL
     * - documentation : Номер документа
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $docNum;
    /**
     * The docDate
     * Meta informations extracted from the WSDL
     * - documentation : Дата документа
     * - minOccurs : 0
     * @var date
     */
    public $docDate;
    /**
     * The docAuthor
     * Meta informations extracted from the WSDL
     * - documentation : Создатель документа
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $docAuthor;
    /**
     * The docTarget
     * Meta informations extracted from the WSDL
     * - documentation : Для кого предназначен (куда направляется) документ ф 027/у
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $docTarget;
    /**
     * Constructor method for ContainerDocument
     * @see parent::__construct()
     * @param MyMPIStructCodeAndName $_docType
     * @param string $_docNum
     * @param date $_docDate
     * @param MyMPIStructEmployee $_docAuthor
     * @param MyMPIStructCodeAndName $_docTarget
     * @return MyMPIStructContainerDocument
     */
    public function __construct($_docType = NULL,$_docNum = NULL,$_docDate = NULL,$_docAuthor = NULL,$_docTarget = NULL)
    {
        MyMPIWsdlClass::__construct(array('docType'=>$_docType,'docNum'=>$_docNum,'docDate'=>$_docDate,'docAuthor'=>$_docAuthor,'docTarget'=>$_docTarget),false);
    }
    /**
     * Get docType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getDocType()
    {
        return $this->docType;
    }
    /**
     * Set docType value
     * @param MyMPIStructCodeAndName $_docType the docType
     * @return MyMPIStructCodeAndName
     */
    public function setDocType($_docType)
    {
        return ($this->docType = $_docType);
    }
    /**
     * Get docNum value
     * @return string|null
     */
    public function getDocNum()
    {
        return $this->docNum;
    }
    /**
     * Set docNum value
     * @param string $_docNum the docNum
     * @return string
     */
    public function setDocNum($_docNum)
    {
        return ($this->docNum = $_docNum);
    }
    /**
     * Get docDate value
     * @return date|null
     */
    public function getDocDate()
    {
        return $this->docDate;
    }
    /**
     * Set docDate value
     * @param date $_docDate the docDate
     * @return date
     */
    public function setDocDate($_docDate)
    {
        return ($this->docDate = $_docDate);
    }
    /**
     * Get docAuthor value
     * @return MyMPIStructEmployee|null
     */
    public function getDocAuthor()
    {
        return $this->docAuthor;
    }
    /**
     * Set docAuthor value
     * @param MyMPIStructEmployee $_docAuthor the docAuthor
     * @return MyMPIStructEmployee
     */
    public function setDocAuthor($_docAuthor)
    {
        return ($this->docAuthor = $_docAuthor);
    }
    /**
     * Get docTarget value
     * @return MyMPIStructCodeAndName|null
     */
    public function getDocTarget()
    {
        return $this->docTarget;
    }
    /**
     * Set docTarget value
     * @param MyMPIStructCodeAndName $_docTarget the docTarget
     * @return MyMPIStructCodeAndName
     */
    public function setDocTarget($_docTarget)
    {
        return ($this->docTarget = $_docTarget);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructContainerDocument
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
