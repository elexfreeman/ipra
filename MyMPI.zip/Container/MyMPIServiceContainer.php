<?php
/**
 * File for class MyMPIServiceContainer
 * @package MyMPI
 * @subpackage Services
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIServiceContainer originally named Container
 * @package MyMPI
 * @subpackage Services
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIServiceContainer extends MyMPIWsdlClass
{
    /**
     * Method to call the operation originally named container
     * @uses MyMPIWsdlClass::getSoapClient()
     * @uses MyMPIWsdlClass::setResult()
     * @uses MyMPIWsdlClass::saveLastError()
     * @param MyMPIStructContainer $_myMPIStructContainer
     * @return void
     */
    public function container(MyMPIStructContainer $_myMPIStructContainer)
    {
        try
        {
            return $this->setResult(self::getSoapClient()->container($_myMPIStructContainer));
        }
        catch(SoapFault $soapFault)
        {
            return !$this->saveLastError(__METHOD__,$soapFault);
        }
    }
    /**
     * Returns the result
     * @see MyMPIWsdlClass::getResult()
     * @return void
     */
    public function getResult()
    {
        return parent::getResult();
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
