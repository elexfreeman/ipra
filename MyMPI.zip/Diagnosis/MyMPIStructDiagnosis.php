<?php
/**
 * File for class MyMPIStructDiagnosis
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructDiagnosis originally named Diagnosis
 * Documentation : Диагноз
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructDiagnosis extends MyMPIWsdlClass
{
    /**
     * The extId
     * Meta informations extracted from the WSDL
     * - documentation : Идентификатор в МИС
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $extId;
    /**
     * The encounterCode
     * Meta informations extracted from the WSDL
     * - documentation : Код эпизода
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $encounterCode;
    /**
     * The enteredBy
     * Meta informations extracted from the WSDL
     * - documentation : Автор записи (врач) ТФОМС: IDDOKT (региональный справочник), PRVS (V004) - специальность
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $enteredBy;
    /**
     * The enteredOn
     * Meta informations extracted from the WSDL
     * - documentation : Дата/время ввода записи в МИС
     * - minOccurs : 0
     * @var dateTime
     */
    public $enteredOn;
    /**
     * The diagnosis
     * Meta informations extracted from the WSDL
     * - documentation : Диагноз (код МКБ-10 и расшифровка) ЕГИСЗ - 1.2.643.5.1.13.2.1.1.641 (MKB308) - Международная классификация болезней и состояний, связанных со здоровьем, Десятого пересмотра. Версия 2
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $diagnosis;
    /**
     * The diagnosisType
     * Meta informations extracted from the WSDL
     * - documentation : Тип диагноза: FINAL(заключительный), WAY(направившего учреждения), IN(при поступлении), DEAD(Непосредственная причина смерти), IL(Заболевание, вызвавшее смерть), DPA(Патологоанатомический диагноз)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $diagnosisType;
    /**
     * The diagnosisKind
     * Meta informations extracted from the WSDL
     * - documentation : Вид диагноза: DIFF(осложнение основного), SEC(сопутствующий); для основного - не указывается
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $diagnosisKind;
    /**
     * The replacedExtId
     * Meta informations extracted from the WSDL
     * - documentation : Идентификатор заменяемого диагноза
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $replacedExtId;
    /**
     * The acuteOrChronic
     * Meta informations extracted from the WSDL
     * - documentation : Острое или хроническое заболевание ЕГИСЗ - 1.2.643.5.1.13.2.1.1.586 - Классификатор характера заболевания (1 - Впервые в жизни установленное хроническое, 2 - Диагноз установлен в предыдущем году или ранее, 3 - Острое) (AKPC_DIAG_CHARACTER_TYPES)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $acuteOrChronic;
    /**
     * The onsetTime
     * Meta informations extracted from the WSDL
     * - documentation : Дата/время постановки диагноза
     * - minOccurs : 0
     * @var dateTime
     */
    public $onsetTime;
    /**
     * The isFirstTime
     * Meta informations extracted from the WSDL
     * - documentation : Признак впервые установленного заболевания
     * - minOccurs : 0
     * @var boolean
     */
    public $isFirstTime;
    /**
     * The dispensarySupervision
     * Meta informations extracted from the WSDL
     * - documentation : Диспансерное наблюдение
     * - minOccurs : 0
     * @var MyMPIStructDispensarySupervision
     */
    public $dispensarySupervision;
    /**
     * The traumaType
     * Meta informations extracted from the WSDL
     * - documentation : Вид травмы ??? - ЕГИСЗ - 1.2.643.5.1.13.2.1.1.105 - Классификатор травм по способу получения (амбулаторное лечение)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $traumaType;
    /**
     * The admissionsThisYear
     * Meta informations extracted from the WSDL
     * - documentation : Кол-во госпитализаций в текущем году с данным диагнозом ф 003/у
     * - minOccurs : 0
     * @var long
     */
    public $admissionsThisYear;
    /**
     * Constructor method for Diagnosis
     * @see parent::__construct()
     * @param string $_extId
     * @param string $_encounterCode
     * @param MyMPIStructEmployee $_enteredBy
     * @param dateTime $_enteredOn
     * @param MyMPIStructCodeAndName $_diagnosis
     * @param MyMPIStructCodeAndName $_diagnosisType
     * @param MyMPIStructCodeAndName $_diagnosisKind
     * @param string $_replacedExtId
     * @param MyMPIStructCodeAndName $_acuteOrChronic
     * @param dateTime $_onsetTime
     * @param boolean $_isFirstTime
     * @param MyMPIStructDispensarySupervision $_dispensarySupervision
     * @param MyMPIStructCodeAndName $_traumaType
     * @param long $_admissionsThisYear
     * @return MyMPIStructDiagnosis
     */
    public function __construct($_extId = NULL,$_encounterCode = NULL,$_enteredBy = NULL,$_enteredOn = NULL,$_diagnosis = NULL,$_diagnosisType = NULL,$_diagnosisKind = NULL,$_replacedExtId = NULL,$_acuteOrChronic = NULL,$_onsetTime = NULL,$_isFirstTime = NULL,$_dispensarySupervision = NULL,$_traumaType = NULL,$_admissionsThisYear = NULL)
    {
        parent::__construct(array('extId'=>$_extId,'encounterCode'=>$_encounterCode,'enteredBy'=>$_enteredBy,'enteredOn'=>$_enteredOn,'diagnosis'=>$_diagnosis,'diagnosisType'=>$_diagnosisType,'diagnosisKind'=>$_diagnosisKind,'replacedExtId'=>$_replacedExtId,'acuteOrChronic'=>$_acuteOrChronic,'onsetTime'=>$_onsetTime,'isFirstTime'=>$_isFirstTime,'dispensarySupervision'=>$_dispensarySupervision,'traumaType'=>$_traumaType,'admissionsThisYear'=>$_admissionsThisYear),false);
    }
    /**
     * Get extId value
     * @return string|null
     */
    public function getExtId()
    {
        return $this->extId;
    }
    /**
     * Set extId value
     * @param string $_extId the extId
     * @return string
     */
    public function setExtId($_extId)
    {
        return ($this->extId = $_extId);
    }
    /**
     * Get encounterCode value
     * @return string|null
     */
    public function getEncounterCode()
    {
        return $this->encounterCode;
    }
    /**
     * Set encounterCode value
     * @param string $_encounterCode the encounterCode
     * @return string
     */
    public function setEncounterCode($_encounterCode)
    {
        return ($this->encounterCode = $_encounterCode);
    }
    /**
     * Get enteredBy value
     * @return MyMPIStructEmployee|null
     */
    public function getEnteredBy()
    {
        return $this->enteredBy;
    }
    /**
     * Set enteredBy value
     * @param MyMPIStructEmployee $_enteredBy the enteredBy
     * @return MyMPIStructEmployee
     */
    public function setEnteredBy($_enteredBy)
    {
        return ($this->enteredBy = $_enteredBy);
    }
    /**
     * Get enteredOn value
     * @return dateTime|null
     */
    public function getEnteredOn()
    {
        return $this->enteredOn;
    }
    /**
     * Set enteredOn value
     * @param dateTime $_enteredOn the enteredOn
     * @return dateTime
     */
    public function setEnteredOn($_enteredOn)
    {
        return ($this->enteredOn = $_enteredOn);
    }
    /**
     * Get diagnosis value
     * @return MyMPIStructCodeAndName|null
     */
    public function getDiagnosis()
    {
        return $this->diagnosis;
    }
    /**
     * Set diagnosis value
     * @param MyMPIStructCodeAndName $_diagnosis the diagnosis
     * @return MyMPIStructCodeAndName
     */
    public function setDiagnosis($_diagnosis)
    {
        return ($this->diagnosis = $_diagnosis);
    }
    /**
     * Get diagnosisType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getDiagnosisType()
    {
        return $this->diagnosisType;
    }
    /**
     * Set diagnosisType value
     * @param MyMPIStructCodeAndName $_diagnosisType the diagnosisType
     * @return MyMPIStructCodeAndName
     */
    public function setDiagnosisType($_diagnosisType)
    {
        return ($this->diagnosisType = $_diagnosisType);
    }
    /**
     * Get diagnosisKind value
     * @return MyMPIStructCodeAndName|null
     */
    public function getDiagnosisKind()
    {
        return $this->diagnosisKind;
    }
    /**
     * Set diagnosisKind value
     * @param MyMPIStructCodeAndName $_diagnosisKind the diagnosisKind
     * @return MyMPIStructCodeAndName
     */
    public function setDiagnosisKind($_diagnosisKind)
    {
        return ($this->diagnosisKind = $_diagnosisKind);
    }
    /**
     * Get replacedExtId value
     * @return string|null
     */
    public function getReplacedExtId()
    {
        return $this->replacedExtId;
    }
    /**
     * Set replacedExtId value
     * @param string $_replacedExtId the replacedExtId
     * @return string
     */
    public function setReplacedExtId($_replacedExtId)
    {
        return ($this->replacedExtId = $_replacedExtId);
    }
    /**
     * Get acuteOrChronic value
     * @return MyMPIStructCodeAndName|null
     */
    public function getAcuteOrChronic()
    {
        return $this->acuteOrChronic;
    }
    /**
     * Set acuteOrChronic value
     * @param MyMPIStructCodeAndName $_acuteOrChronic the acuteOrChronic
     * @return MyMPIStructCodeAndName
     */
    public function setAcuteOrChronic($_acuteOrChronic)
    {
        return ($this->acuteOrChronic = $_acuteOrChronic);
    }
    /**
     * Get onsetTime value
     * @return dateTime|null
     */
    public function getOnsetTime()
    {
        return $this->onsetTime;
    }
    /**
     * Set onsetTime value
     * @param dateTime $_onsetTime the onsetTime
     * @return dateTime
     */
    public function setOnsetTime($_onsetTime)
    {
        return ($this->onsetTime = $_onsetTime);
    }
    /**
     * Get isFirstTime value
     * @return boolean|null
     */
    public function getIsFirstTime()
    {
        return $this->isFirstTime;
    }
    /**
     * Set isFirstTime value
     * @param boolean $_isFirstTime the isFirstTime
     * @return boolean
     */
    public function setIsFirstTime($_isFirstTime)
    {
        return ($this->isFirstTime = $_isFirstTime);
    }
    /**
     * Get dispensarySupervision value
     * @return MyMPIStructDispensarySupervision|null
     */
    public function getDispensarySupervision()
    {
        return $this->dispensarySupervision;
    }
    /**
     * Set dispensarySupervision value
     * @param MyMPIStructDispensarySupervision $_dispensarySupervision the dispensarySupervision
     * @return MyMPIStructDispensarySupervision
     */
    public function setDispensarySupervision($_dispensarySupervision)
    {
        return ($this->dispensarySupervision = $_dispensarySupervision);
    }
    /**
     * Get traumaType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getTraumaType()
    {
        return $this->traumaType;
    }
    /**
     * Set traumaType value
     * @param MyMPIStructCodeAndName $_traumaType the traumaType
     * @return MyMPIStructCodeAndName
     */
    public function setTraumaType($_traumaType)
    {
        return ($this->traumaType = $_traumaType);
    }
    /**
     * Get admissionsThisYear value
     * @return long|null
     */
    public function getAdmissionsThisYear()
    {
        return $this->admissionsThisYear;
    }
    /**
     * Set admissionsThisYear value
     * @param long $_admissionsThisYear the admissionsThisYear
     * @return long
     */
    public function setAdmissionsThisYear($_admissionsThisYear)
    {
        return ($this->admissionsThisYear = $_admissionsThisYear);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructDiagnosis
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
