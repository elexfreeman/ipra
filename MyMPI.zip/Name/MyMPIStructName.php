<?php
/**
 * File for class MyMPIStructName
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructName originally named Name
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructName extends MyMPIStructBaseSerial
{
    /**
     * The familyName
     * Meta informations extracted from the WSDL
     * - documentation : Фамилия
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $familyName;
    /**
     * The givenName
     * Meta informations extracted from the WSDL
     * - documentation : Имя
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $givenName;
    /**
     * The middleName
     * Meta informations extracted from the WSDL
     * - documentation : Отчество
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $middleName;
    /**
     * The beginDate
     * Meta informations extracted from the WSDL
     * - documentation : Дата начала периода актуальности ФИО
     * - minOccurs : 0
     * @var date
     */
    public $beginDate;
    /**
     * The endDate
     * Meta informations extracted from the WSDL
     * - documentation : Дата окончания периода актуальности ФИО
     * - minOccurs : 0
     * @var date
     */
    public $endDate;
    /**
     * Constructor method for Name
     * @see parent::__construct()
     * @param string $_familyName
     * @param string $_givenName
     * @param string $_middleName
     * @param date $_beginDate
     * @param date $_endDate
     * @return MyMPIStructName
     */
    public function __construct($_familyName = NULL,$_givenName = NULL,$_middleName = NULL,$_beginDate = NULL,$_endDate = NULL)
    {
        MyMPIWsdlClass::__construct(array('familyName'=>$_familyName,'givenName'=>$_givenName,'middleName'=>$_middleName,'beginDate'=>$_beginDate,'endDate'=>$_endDate),false);
    }
    /**
     * Get familyName value
     * @return string|null
     */
    public function getFamilyName()
    {
        return $this->familyName;
    }
    /**
     * Set familyName value
     * @param string $_familyName the familyName
     * @return string
     */
    public function setFamilyName($_familyName)
    {
        return ($this->familyName = $_familyName);
    }
    /**
     * Get givenName value
     * @return string|null
     */
    public function getGivenName()
    {
        return $this->givenName;
    }
    /**
     * Set givenName value
     * @param string $_givenName the givenName
     * @return string
     */
    public function setGivenName($_givenName)
    {
        return ($this->givenName = $_givenName);
    }
    /**
     * Get middleName value
     * @return string|null
     */
    public function getMiddleName()
    {
        return $this->middleName;
    }
    /**
     * Set middleName value
     * @param string $_middleName the middleName
     * @return string
     */
    public function setMiddleName($_middleName)
    {
        return ($this->middleName = $_middleName);
    }
    /**
     * Get beginDate value
     * @return date|null
     */
    public function getBeginDate()
    {
        return $this->beginDate;
    }
    /**
     * Set beginDate value
     * @param date $_beginDate the beginDate
     * @return date
     */
    public function setBeginDate($_beginDate)
    {
        return ($this->beginDate = $_beginDate);
    }
    /**
     * Get endDate value
     * @return date|null
     */
    public function getEndDate()
    {
        return $this->endDate;
    }
    /**
     * Set endDate value
     * @param date $_endDate the endDate
     * @return date
     */
    public function setEndDate($_endDate)
    {
        return ($this->endDate = $_endDate);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructName
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
