<?php
/**
 * File for class MyMPIStructCodeAndName
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructCodeAndName originally named CodeAndName
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructCodeAndName extends MyMPIStructBaseSerial
{
    /**
     * The code
     * Meta informations extracted from the WSDL
     * - documentation : Код
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $code;
    /**
     * The name
     * Meta informations extracted from the WSDL
     * - documentation : Расшифровка
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $name;
    /**
     * The codingSystem
     * Meta informations extracted from the WSDL
     * - documentation : Система кодификации (используемый справочник)
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $codingSystem;
    /**
     * Constructor method for CodeAndName
     * @see parent::__construct()
     * @param string $_code
     * @param string $_name
     * @param string $_codingSystem
     * @return MyMPIStructCodeAndName
     */
    public function __construct($_code = NULL,$_name = NULL,$_codingSystem = NULL)
    {
        MyMPIWsdlClass::__construct(array('code'=>$_code,'name'=>$_name,'codingSystem'=>$_codingSystem),false);
    }
    /**
     * Get code value
     * @return string|null
     */
    public function getCode()
    {
        return $this->code;
    }
    /**
     * Set code value
     * @param string $_code the code
     * @return string
     */
    public function setCode($_code)
    {
        return ($this->code = $_code);
    }
    /**
     * Get name value
     * @return string|null
     */
    public function getName()
    {
        return $this->name;
    }
    /**
     * Set name value
     * @param string $_name the name
     * @return string
     */
    public function setName($_name)
    {
        return ($this->name = $_name);
    }
    /**
     * Get codingSystem value
     * @return string|null
     */
    public function getCodingSystem()
    {
        return $this->codingSystem;
    }
    /**
     * Set codingSystem value
     * @param string $_codingSystem the codingSystem
     * @return string
     */
    public function setCodingSystem($_codingSystem)
    {
        return ($this->codingSystem = $_codingSystem);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructCodeAndName
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
