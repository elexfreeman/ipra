<?php
/**
 * File for class MyMPIStructInsurance
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructInsurance originally named Insurance
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructInsurance extends MyMPIStructBaseSerial
{
    /**
     * The insuranceCompany
     * Meta informations extracted from the WSDL
     * - documentation : Страховая компания ЕГИСЗ: справочник 1.2.643.5.1.13.2.1.1.635 (MDN366) ТФОМС: SMO (код - по справочнику F002) ЕГИСЗ "Пациент" поле №26 СЭМД ext:asOtherIDs/ext:scopingOrganization
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $insuranceCompany;
    /**
     * The insuranceCompanyOkato
     * Meta informations extracted from the WSDL
     * - documentation : ОКАТО территории страхования (F001) ТФОМС: SMO_OK
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $insuranceCompanyOkato;
    /**
     * The policyType
     * Meta informations extracted from the WSDL
     * - documentation : Тип полиса (F008) ТФОМС: VPOLIS - Тип документа, подтверждающего факт страхования по ОМС ЕГИСЗ "Пациент" поле №27
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $policyType;
    /**
     * The policySer
     * Meta informations extracted from the WSDL
     * - documentation : Серия страхового полиса ТФОМС: SPOLIS - Серия документа, подтверждающего факт страхования по ОМС ЕГИСЗ "Пациент" поле №28 СЭМД ext:asOtherIDs/ext:documentNumber/@series
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $policySer;
    /**
     * The policyNum
     * Meta informations extracted from the WSDL
     * - documentation : Номер страхового полиса ТФОМС: NPOLIS - Номер документа, подтверждающего факт страхования по ОМС ЕГИСЗ "Пациент" поле №29 СЭМД ext:asOtherIDs/ext:documentNumber/@number
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $policyNum;
    /**
     * The effectiveDate
     * Meta informations extracted from the WSDL
     * - documentation : Дата начала действия страхового полиса ЕГИСЗ "Пациент" поле №30 СЭМД ext:asOtherIDs/ext:effectiveTime/ext:low
     * - minOccurs : 0
     * @var date
     */
    public $effectiveDate;
    /**
     * The expirationDate
     * Meta informations extracted from the WSDL
     * - documentation : Дата окончания действия страхового полиса СЭМД ext:asOtherIDs/ext:effectiveTime/ext:high
     * - minOccurs : 0
     * @var date
     */
    public $expirationDate;
    /**
     * The insuranceCompanyKladr
     * Meta informations extracted from the WSDL
     * - documentation : КЛАДР территории страхования СЭМД ext:InsuredTerritory codeSystem="1.2.643.5.1.13.2.1.1.196" Судя по всему, новый OID КЛАДР = 1.2.643.5.1.13.2.1.1.661
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $insuranceCompanyKladr;
    /**
     * Constructor method for Insurance
     * @see parent::__construct()
     * @param MyMPIStructCodeAndName $_insuranceCompany
     * @param string $_insuranceCompanyOkato
     * @param MyMPIStructCodeAndName $_policyType
     * @param string $_policySer
     * @param string $_policyNum
     * @param date $_effectiveDate
     * @param date $_expirationDate
     * @param MyMPIStructCodeAndName $_insuranceCompanyKladr
     * @return MyMPIStructInsurance
     */
    public function __construct($_insuranceCompany = NULL,$_insuranceCompanyOkato = NULL,$_policyType = NULL,$_policySer = NULL,$_policyNum = NULL,$_effectiveDate = NULL,$_expirationDate = NULL,$_insuranceCompanyKladr = NULL)
    {
        MyMPIWsdlClass::__construct(array('insuranceCompany'=>$_insuranceCompany,'insuranceCompanyOkato'=>$_insuranceCompanyOkato,'policyType'=>$_policyType,'policySer'=>$_policySer,'policyNum'=>$_policyNum,'effectiveDate'=>$_effectiveDate,'expirationDate'=>$_expirationDate,'insuranceCompanyKladr'=>$_insuranceCompanyKladr),false);
    }
    /**
     * Get insuranceCompany value
     * @return MyMPIStructCodeAndName|null
     */
    public function getInsuranceCompany()
    {
        return $this->insuranceCompany;
    }
    /**
     * Set insuranceCompany value
     * @param MyMPIStructCodeAndName $_insuranceCompany the insuranceCompany
     * @return MyMPIStructCodeAndName
     */
    public function setInsuranceCompany($_insuranceCompany)
    {
        return ($this->insuranceCompany = $_insuranceCompany);
    }
    /**
     * Get insuranceCompanyOkato value
     * @return string|null
     */
    public function getInsuranceCompanyOkato()
    {
        return $this->insuranceCompanyOkato;
    }
    /**
     * Set insuranceCompanyOkato value
     * @param string $_insuranceCompanyOkato the insuranceCompanyOkato
     * @return string
     */
    public function setInsuranceCompanyOkato($_insuranceCompanyOkato)
    {
        return ($this->insuranceCompanyOkato = $_insuranceCompanyOkato);
    }
    /**
     * Get policyType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getPolicyType()
    {
        return $this->policyType;
    }
    /**
     * Set policyType value
     * @param MyMPIStructCodeAndName $_policyType the policyType
     * @return MyMPIStructCodeAndName
     */
    public function setPolicyType($_policyType)
    {
        return ($this->policyType = $_policyType);
    }
    /**
     * Get policySer value
     * @return string|null
     */
    public function getPolicySer()
    {
        return $this->policySer;
    }
    /**
     * Set policySer value
     * @param string $_policySer the policySer
     * @return string
     */
    public function setPolicySer($_policySer)
    {
        return ($this->policySer = $_policySer);
    }
    /**
     * Get policyNum value
     * @return string|null
     */
    public function getPolicyNum()
    {
        return $this->policyNum;
    }
    /**
     * Set policyNum value
     * @param string $_policyNum the policyNum
     * @return string
     */
    public function setPolicyNum($_policyNum)
    {
        return ($this->policyNum = $_policyNum);
    }
    /**
     * Get effectiveDate value
     * @return date|null
     */
    public function getEffectiveDate()
    {
        return $this->effectiveDate;
    }
    /**
     * Set effectiveDate value
     * @param date $_effectiveDate the effectiveDate
     * @return date
     */
    public function setEffectiveDate($_effectiveDate)
    {
        return ($this->effectiveDate = $_effectiveDate);
    }
    /**
     * Get expirationDate value
     * @return date|null
     */
    public function getExpirationDate()
    {
        return $this->expirationDate;
    }
    /**
     * Set expirationDate value
     * @param date $_expirationDate the expirationDate
     * @return date
     */
    public function setExpirationDate($_expirationDate)
    {
        return ($this->expirationDate = $_expirationDate);
    }
    /**
     * Get insuranceCompanyKladr value
     * @return MyMPIStructCodeAndName|null
     */
    public function getInsuranceCompanyKladr()
    {
        return $this->insuranceCompanyKladr;
    }
    /**
     * Set insuranceCompanyKladr value
     * @param MyMPIStructCodeAndName $_insuranceCompanyKladr the insuranceCompanyKladr
     * @return MyMPIStructCodeAndName
     */
    public function setInsuranceCompanyKladr($_insuranceCompanyKladr)
    {
        return ($this->insuranceCompanyKladr = $_insuranceCompanyKladr);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructInsurance
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
