<?php
/**
 * File for class MyMPIStructOccupation
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructOccupation originally named Occupation
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructOccupation extends MyMPIStructBaseSerial
{
    /**
     * The organizationName
     * Meta informations extracted from the WSDL
     * - documentation : Наименование места работы/учебы/службы ЕГИСЗ "Пациент" поле №20 СЭМД ext:employerOrganization/ext:name
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $organizationName;
    /**
     * The organizationType
     * Meta informations extracted from the WSDL
     * - documentation : Тип места работы/учебы/службы (дошкольное учреждение, школа, ВУЗ, военная часть, производство, ...)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $organizationType;
    /**
     * The position
     * Meta informations extracted from the WSDL
     * - documentation : Должность/звание ЕГИСЗ "Пациент" поле №21 СЭМД ext:jobTitleName
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $position;
    /**
     * The profession
     * Meta informations extracted from the WSDL
     * - documentation : Профессия
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $profession;
    /**
     * The laborType
     * Meta informations extracted from the WSDL
     * - documentation : Характер труда ЕГИСЗ "Пациент" поле №22
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $laborType;
    /**
     * The socialProfessionalGroup
     * Meta informations extracted from the WSDL
     * - documentation : Социально-профессиональная группа ЕГИСЗ "Пациент" поле №24
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $socialProfessionalGroup;
    /**
     * The okved
     * Meta informations extracted from the WSDL
     * - documentation : Код ОКВЭД (отрасль) СЭМД ext:jobCode - НСИ: 1.2.643.5.1.13.2.1.1.62 (O00020)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $okved;
    /**
     * The startedOn
     * Meta informations extracted from the WSDL
     * - documentation : Дата поступления на работу/учебу
     * - minOccurs : 0
     * @var date
     */
    public $startedOn;
    /**
     * The harmfulConditions
     * Meta informations extracted from the WSDL
     * - documentation : Профессиональная вредность (наличие вредных и/или опасных производственных факторов) ЕГИСЗ "Пациент" поле №23
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $harmfulConditions;
    /**
     * The dayDuration
     * Meta informations extracted from the WSDL
     * - documentation : Продолжительность рабочего дня/учебы (час)
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $dayDuration;
    /**
     * The shiftDuration
     * Meta informations extracted from the WSDL
     * - documentation : Продолжительность рабочей смены (час)
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $shiftDuration;
    /**
     * The ogrn
     * Meta informations extracted from the WSDL
     * - documentation : Код ОГРН работодателя СЭМД ext:employerOrganization/ext:id/@extension [root='1.2.643.100.1']
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $ogrn;
    /**
     * Constructor method for Occupation
     * @see parent::__construct()
     * @param string $_organizationName
     * @param MyMPIStructCodeAndName $_organizationType
     * @param string $_position
     * @param string $_profession
     * @param MyMPIStructCodeAndName $_laborType
     * @param MyMPIStructCodeAndName $_socialProfessionalGroup
     * @param MyMPIStructCodeAndName $_okved
     * @param date $_startedOn
     * @param string $_harmfulConditions
     * @param string $_dayDuration
     * @param string $_shiftDuration
     * @param string $_ogrn
     * @return MyMPIStructOccupation
     */
    public function __construct($_organizationName = NULL,$_organizationType = NULL,$_position = NULL,$_profession = NULL,$_laborType = NULL,$_socialProfessionalGroup = NULL,$_okved = NULL,$_startedOn = NULL,$_harmfulConditions = NULL,$_dayDuration = NULL,$_shiftDuration = NULL,$_ogrn = NULL)
    {
        MyMPIWsdlClass::__construct(array('organizationName'=>$_organizationName,'organizationType'=>$_organizationType,'position'=>$_position,'profession'=>$_profession,'laborType'=>$_laborType,'socialProfessionalGroup'=>$_socialProfessionalGroup,'okved'=>$_okved,'startedOn'=>$_startedOn,'harmfulConditions'=>$_harmfulConditions,'dayDuration'=>$_dayDuration,'shiftDuration'=>$_shiftDuration,'ogrn'=>$_ogrn),false);
    }
    /**
     * Get organizationName value
     * @return string|null
     */
    public function getOrganizationName()
    {
        return $this->organizationName;
    }
    /**
     * Set organizationName value
     * @param string $_organizationName the organizationName
     * @return string
     */
    public function setOrganizationName($_organizationName)
    {
        return ($this->organizationName = $_organizationName);
    }
    /**
     * Get organizationType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getOrganizationType()
    {
        return $this->organizationType;
    }
    /**
     * Set organizationType value
     * @param MyMPIStructCodeAndName $_organizationType the organizationType
     * @return MyMPIStructCodeAndName
     */
    public function setOrganizationType($_organizationType)
    {
        return ($this->organizationType = $_organizationType);
    }
    /**
     * Get position value
     * @return string|null
     */
    public function getPosition()
    {
        return $this->position;
    }
    /**
     * Set position value
     * @param string $_position the position
     * @return string
     */
    public function setPosition($_position)
    {
        return ($this->position = $_position);
    }
    /**
     * Get profession value
     * @return string|null
     */
    public function getProfession()
    {
        return $this->profession;
    }
    /**
     * Set profession value
     * @param string $_profession the profession
     * @return string
     */
    public function setProfession($_profession)
    {
        return ($this->profession = $_profession);
    }
    /**
     * Get laborType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getLaborType()
    {
        return $this->laborType;
    }
    /**
     * Set laborType value
     * @param MyMPIStructCodeAndName $_laborType the laborType
     * @return MyMPIStructCodeAndName
     */
    public function setLaborType($_laborType)
    {
        return ($this->laborType = $_laborType);
    }
    /**
     * Get socialProfessionalGroup value
     * @return MyMPIStructCodeAndName|null
     */
    public function getSocialProfessionalGroup()
    {
        return $this->socialProfessionalGroup;
    }
    /**
     * Set socialProfessionalGroup value
     * @param MyMPIStructCodeAndName $_socialProfessionalGroup the socialProfessionalGroup
     * @return MyMPIStructCodeAndName
     */
    public function setSocialProfessionalGroup($_socialProfessionalGroup)
    {
        return ($this->socialProfessionalGroup = $_socialProfessionalGroup);
    }
    /**
     * Get okved value
     * @return MyMPIStructCodeAndName|null
     */
    public function getOkved()
    {
        return $this->okved;
    }
    /**
     * Set okved value
     * @param MyMPIStructCodeAndName $_okved the okved
     * @return MyMPIStructCodeAndName
     */
    public function setOkved($_okved)
    {
        return ($this->okved = $_okved);
    }
    /**
     * Get startedOn value
     * @return date|null
     */
    public function getStartedOn()
    {
        return $this->startedOn;
    }
    /**
     * Set startedOn value
     * @param date $_startedOn the startedOn
     * @return date
     */
    public function setStartedOn($_startedOn)
    {
        return ($this->startedOn = $_startedOn);
    }
    /**
     * Get harmfulConditions value
     * @return string|null
     */
    public function getHarmfulConditions()
    {
        return $this->harmfulConditions;
    }
    /**
     * Set harmfulConditions value
     * @param string $_harmfulConditions the harmfulConditions
     * @return string
     */
    public function setHarmfulConditions($_harmfulConditions)
    {
        return ($this->harmfulConditions = $_harmfulConditions);
    }
    /**
     * Get dayDuration value
     * @return string|null
     */
    public function getDayDuration()
    {
        return $this->dayDuration;
    }
    /**
     * Set dayDuration value
     * @param string $_dayDuration the dayDuration
     * @return string
     */
    public function setDayDuration($_dayDuration)
    {
        return ($this->dayDuration = $_dayDuration);
    }
    /**
     * Get shiftDuration value
     * @return string|null
     */
    public function getShiftDuration()
    {
        return $this->shiftDuration;
    }
    /**
     * Set shiftDuration value
     * @param string $_shiftDuration the shiftDuration
     * @return string
     */
    public function setShiftDuration($_shiftDuration)
    {
        return ($this->shiftDuration = $_shiftDuration);
    }
    /**
     * Get ogrn value
     * @return string|null
     */
    public function getOgrn()
    {
        return $this->ogrn;
    }
    /**
     * Set ogrn value
     * @param string $_ogrn the ogrn
     * @return string
     */
    public function setOgrn($_ogrn)
    {
        return ($this->ogrn = $_ogrn);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructOccupation
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
