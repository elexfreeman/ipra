<?php
/**
 * File for class MyMPIStructEmployee
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructEmployee originally named Employee
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructEmployee extends MyMPIWsdlClass
{
    /**
     * The code
     * Meta informations extracted from the WSDL
     * - documentation : Код ТФОМС: IDDOKT -- CODE_MD - региональный справочник DOCTORS СЭМД author/assignedAuthor/id/@extension, legalAuthenticator/assignedEntity/id/@extension, authenticator/assignedEntity/id/@extension
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $code;
    /**
     * The name
     * Meta informations extracted from the WSDL
     * - documentation : Расшифровка (если известны ФИО сотрудника, то поле name не следует заполнять)
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $name;
    /**
     * The codingSystem
     * Meta informations extracted from the WSDL
     * - documentation : Система кодификации
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $codingSystem;
    /**
     * The specialty
     * Meta informations extracted from the WSDL
     * - documentation : Специальность ТФОМС: PRVS (V004 - Классификатор медицинских специальностей) PnR (Секция описания автора документа) - authorSpecialty СЭМД author/assignedAuthor/ext:asLicencedEntity/ext:code codeSystem="1.2.643.5.1.13.2.1.1.181"
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $specialty;
    /**
     * The role
     * Meta informations extracted from the WSDL
     * - documentation : Должность PnR (Секция описания автора документа) - authorRole СЭМД: author/assignedAuthor/code Справочник MDP365, OID: 1.2.643.5.1.13.2.1.1.607
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $role;
    /**
     * The snils
     * Meta informations extracted from the WSDL
     * - documentation : СНИЛС PnR (Секция описания автора документа) - authorPerson, legalAuthenticator (пример: 00000000003^Привалов^Александр^Иванович)
     * - minOccurs : 0
     * - maxLength : 14
     * - minLength : 14
     * - pattern : (\d){3}-(\d){3}-(\d){3} (\d){2}
     * @var string
     */
    public $snils;
    /**
     * The familyName
     * Meta informations extracted from the WSDL
     * - documentation : Фамилия СЭМД author/assignedAuthor/assignedPerson/name/family, legalAuthenticator/assignedEntity/assignedPerson/name/family, authenticator/assignedEntity/assignedPerson/name/family
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $familyName;
    /**
     * The givenName
     * Meta informations extracted from the WSDL
     * - documentation : Имя СЭМД author/assignedAuthor/assignedPerson/name/given, legalAuthenticator/assignedEntity/assignedPerson/name/given, authenticator/assignedEntity/assignedPerson/name/given
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $givenName;
    /**
     * The middleName
     * Meta informations extracted from the WSDL
     * - documentation : Отчество СЭМД author/assignedAuthor/assignedPerson/name/given, legalAuthenticator/assignedEntity/assignedPerson/name/given, authenticator/assignedEntity/assignedPerson/name/given
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $middleName;
    /**
     * The contactInfo
     * Meta informations extracted from the WSDL
     * - documentation : Контактная информация СЭМД author/assignedAuthor/telecom/@value, legalAuthenticator/assignedEntity/telecom/@value, authenticator/assignedEntity/telecom/@value
     * - minOccurs : 0
     * @var MyMPIStructContactInfo
     */
    public $contactInfo;
    /**
     * The fromTime
     * Meta informations extracted from the WSDL
     * - documentation : Дата начала деятельности СЭМД author/time/@value, legalAuthenticator/time/@value, authenticator/time/@value
     * - minOccurs : 0
     * @var dateTime
     */
    public $fromTime;
    /**
     * Constructor method for Employee
     * @see parent::__construct()
     * @param string $_code
     * @param string $_name
     * @param string $_codingSystem
     * @param MyMPIStructCodeAndName $_specialty
     * @param MyMPIStructCodeAndName $_role
     * @param string $_snils
     * @param string $_familyName
     * @param string $_givenName
     * @param string $_middleName
     * @param MyMPIStructContactInfo $_contactInfo
     * @param dateTime $_fromTime
     * @return MyMPIStructEmployee
     */
    public function __construct($_code = NULL,$_name = NULL,$_codingSystem = NULL,$_specialty = NULL,$_role = NULL,$_snils = NULL,$_familyName = NULL,$_givenName = NULL,$_middleName = NULL,$_contactInfo = NULL,$_fromTime = NULL)
    {
        parent::__construct(array('code'=>$_code,'name'=>$_name,'codingSystem'=>$_codingSystem,'specialty'=>$_specialty,'role'=>$_role,'snils'=>$_snils,'familyName'=>$_familyName,'givenName'=>$_givenName,'middleName'=>$_middleName,'contactInfo'=>$_contactInfo,'fromTime'=>$_fromTime),false);
    }
    /**
     * Get code value
     * @return string|null
     */
    public function getCode()
    {
        return $this->code;
    }
    /**
     * Set code value
     * @param string $_code the code
     * @return string
     */
    public function setCode($_code)
    {
        return ($this->code = $_code);
    }
    /**
     * Get name value
     * @return string|null
     */
    public function getName()
    {
        return $this->name;
    }
    /**
     * Set name value
     * @param string $_name the name
     * @return string
     */
    public function setName($_name)
    {
        return ($this->name = $_name);
    }
    /**
     * Get codingSystem value
     * @return string|null
     */
    public function getCodingSystem()
    {
        return $this->codingSystem;
    }
    /**
     * Set codingSystem value
     * @param string $_codingSystem the codingSystem
     * @return string
     */
    public function setCodingSystem($_codingSystem)
    {
        return ($this->codingSystem = $_codingSystem);
    }
    /**
     * Get specialty value
     * @return MyMPIStructCodeAndName|null
     */
    public function getSpecialty()
    {
        return $this->specialty;
    }
    /**
     * Set specialty value
     * @param MyMPIStructCodeAndName $_specialty the specialty
     * @return MyMPIStructCodeAndName
     */
    public function setSpecialty($_specialty)
    {
        return ($this->specialty = $_specialty);
    }
    /**
     * Get role value
     * @return MyMPIStructCodeAndName|null
     */
    public function getRole()
    {
        return $this->role;
    }
    /**
     * Set role value
     * @param MyMPIStructCodeAndName $_role the role
     * @return MyMPIStructCodeAndName
     */
    public function setRole($_role)
    {
        return ($this->role = $_role);
    }
    /**
     * Get snils value
     * @return string|null
     */
    public function getSnils()
    {
        return $this->snils;
    }
    /**
     * Set snils value
     * @param string $_snils the snils
     * @return string
     */
    public function setSnils($_snils)
    {
        return ($this->snils = $_snils);
    }
    /**
     * Get familyName value
     * @return string|null
     */
    public function getFamilyName()
    {
        return $this->familyName;
    }
    /**
     * Set familyName value
     * @param string $_familyName the familyName
     * @return string
     */
    public function setFamilyName($_familyName)
    {
        return ($this->familyName = $_familyName);
    }
    /**
     * Get givenName value
     * @return string|null
     */
    public function getGivenName()
    {
        return $this->givenName;
    }
    /**
     * Set givenName value
     * @param string $_givenName the givenName
     * @return string
     */
    public function setGivenName($_givenName)
    {
        return ($this->givenName = $_givenName);
    }
    /**
     * Get middleName value
     * @return string|null
     */
    public function getMiddleName()
    {
        return $this->middleName;
    }
    /**
     * Set middleName value
     * @param string $_middleName the middleName
     * @return string
     */
    public function setMiddleName($_middleName)
    {
        return ($this->middleName = $_middleName);
    }
    /**
     * Get contactInfo value
     * @return MyMPIStructContactInfo|null
     */
    public function getContactInfo()
    {
        return $this->contactInfo;
    }
    /**
     * Set contactInfo value
     * @param MyMPIStructContactInfo $_contactInfo the contactInfo
     * @return MyMPIStructContactInfo
     */
    public function setContactInfo($_contactInfo)
    {
        return ($this->contactInfo = $_contactInfo);
    }
    /**
     * Get fromTime value
     * @return dateTime|null
     */
    public function getFromTime()
    {
        return $this->fromTime;
    }
    /**
     * Set fromTime value
     * @param dateTime $_fromTime the fromTime
     * @return dateTime
     */
    public function setFromTime($_fromTime)
    {
        return ($this->fromTime = $_fromTime);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructEmployee
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
