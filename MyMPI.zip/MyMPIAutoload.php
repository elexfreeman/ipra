<?php
/**
 * File to load generated classes once at once time
 * @package MyMPI
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * Includes for all generated classes files
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
require_once dirname(__FILE__) . '/MyMPIWsdlClass.php';
require_once dirname(__FILE__) . '/Base/Serial/MyMPIStructBaseSerial.php';
require_once dirname(__FILE__) . '/Code/Name/MyMPIStructCodeAndName.php';
require_once dirname(__FILE__) . '/Employee/MyMPIStructEmployee.php';
require_once dirname(__FILE__) . '/Emergency/Info/MyMPIStructEmergencyInfo.php';
require_once dirname(__FILE__) . '/Admission/MyMPIStructAdmission.php';
require_once dirname(__FILE__) . '/Emergency/Unit/MyMPIStructEmergencyUnit.php';
require_once dirname(__FILE__) . '/Array/String/MyMPIStructArrayOfmesCodeString.php';
require_once dirname(__FILE__) . '/Diagnosis/MyMPIStructDiagnosis.php';
require_once dirname(__FILE__) . '/Array/Diagnosis/MyMPIStructArrayOfdiagnosisDiagnosis.php';
require_once dirname(__FILE__) . '/Enc/Type/MyMPIEnumEncType.php';
require_once dirname(__FILE__) . '/Encounter/MyMPIStructEncounter.php';
require_once dirname(__FILE__) . '/Array/Encounter/MyMPIStructArrayOfencounterEncounter.php';
require_once dirname(__FILE__) . '/Container/Document/MyMPIStructContainerDocument.php';
require_once dirname(__FILE__) . '/Array/Identifier/MyMPIStructArrayOfidentifierIdentifier.php';
require_once dirname(__FILE__) . '/Dispensary/Supervision/MyMPIStructDispensarySupervision.php';
require_once dirname(__FILE__) . '/Identifier/MyMPIStructIdentifier.php';
require_once dirname(__FILE__) . '/Disability/Group/MyMPIEnumDisabilityGroup.php';
require_once dirname(__FILE__) . '/Document/MyMPIStructDocument.php';
require_once dirname(__FILE__) . '/Array/Document/MyMPIStructArrayOfdocumentDocument.php';
require_once dirname(__FILE__) . '/Array/Service/MyMPIStructArrayOfserviceMedService.php';
require_once dirname(__FILE__) . '/Med/Service/MyMPIStructMedService.php';
require_once dirname(__FILE__) . '/Decease/MyMPIStructDecease.php';
require_once dirname(__FILE__) . '/Array/Decease/MyMPIStructArrayOfdeceaseDecease.php';
require_once dirname(__FILE__) . '/Allergy/MyMPIStructAllergy.php';
require_once dirname(__FILE__) . '/Array/Allergy/MyMPIStructArrayOfallergyAllergy.php';
require_once dirname(__FILE__) . '/Trustee/MyMPIStructTrustee.php';
require_once dirname(__FILE__) . '/Disability/MyMPIStructDisability.php';
require_once dirname(__FILE__) . '/Array/Document/MyMPIStructArrayOfsickLeaveDocumentSickLeaveDocument.php';
require_once dirname(__FILE__) . '/Sick/Document/MyMPIStructSickLeaveDocument.php';
require_once dirname(__FILE__) . '/Attendant/Gender/MyMPIEnumAttendantGender.php';
require_once dirname(__FILE__) . '/Array/Disability/MyMPIStructArrayOfdisabilityDisability.php';
require_once dirname(__FILE__) . '/Insurance/MyMPIStructInsurance.php';
require_once dirname(__FILE__) . '/CDAF/Acility/MyMPIStructCDAFacility.php';
require_once dirname(__FILE__) . '/Address/MyMPIStructAddress.php';
require_once dirname(__FILE__) . '/Contact/Info/MyMPIStructContactInfo.php';
require_once dirname(__FILE__) . '/Clinic/MyMPIStructClinic.php';
require_once dirname(__FILE__) . '/Cab/Employee/MyMPIStructCabEmployee.php';
require_once dirname(__FILE__) . '/Patient/MyMPIStructPatient.php';
require_once dirname(__FILE__) . '/Gender/MyMPIEnumGender.php';
require_once dirname(__FILE__) . '/Dwelling/Type/MyMPIEnumDwellingType.php';
require_once dirname(__FILE__) . '/Blood/Group/MyMPIEnumBloodGroup.php';
require_once dirname(__FILE__) . '/Array/Name/MyMPIStructArrayOfNameName.php';
require_once dirname(__FILE__) . '/Name/MyMPIStructName.php';
require_once dirname(__FILE__) . '/History/Entry/MyMPIStructHistoryEntry.php';
require_once dirname(__FILE__) . '/Array/Entry/MyMPIStructArrayOfoccupationHistoryEntry.php';
require_once dirname(__FILE__) . '/Identity/Document/MyMPIStructIdentityDocument.php';
require_once dirname(__FILE__) . '/Array/Document/MyMPIStructArrayOfidentityDocumentIdentityDocument.php';
require_once dirname(__FILE__) . '/Array/Insurance/MyMPIStructArrayOfInsuranceInsurance.php';
require_once dirname(__FILE__) . '/Container/MyMPIStructContainer.php';
require_once dirname(__FILE__) . '/Occupation/MyMPIStructOccupation.php';
require_once dirname(__FILE__) . '/Array/Occupation/MyMPIStructArrayOfOccupationOccupation.php';
require_once dirname(__FILE__) . '/Array/Privilege/MyMPIStructArrayOfPrivilegePrivilege.php';
require_once dirname(__FILE__) . '/Array/Address/MyMPIStructArrayOfaddressAddress.php';
require_once dirname(__FILE__) . '/Privilege/Document/MyMPIStructPrivilegeDocument.php';
require_once dirname(__FILE__) . '/Privilege/MyMPIStructPrivilege.php';
require_once dirname(__FILE__) . '/Array/Name/MyMPIStructArrayOfCodeAndNameCodeAndName.php';
require_once dirname(__FILE__) . '/Array/Trustee/MyMPIStructArrayOftrusteeTrustee.php';
require_once dirname(__FILE__) . '/Container/MyMPIServiceContainer.php';
require_once dirname(__FILE__) . '/MyMPIClassMap.php';
