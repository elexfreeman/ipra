<?php
/**
 * File for class MyMPIStructAddress
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructAddress originally named Address
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructAddress extends MyMPIStructBaseSerial
{
    /**
     * The country
     * Meta informations extracted from the WSDL
     * - documentation : Страна
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $country;
    /**
     * The region
     * Meta informations extracted from the WSDL
     * - documentation : Область/край/республика/... (субъект РФ)
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $region;
    /**
     * The regionKladr
     * Meta informations extracted from the WSDL
     * - documentation : Код субъекта РФ согласно КЛАДР ЕГИСЗ "Пациент" таблица данных адреса и контактов, поле №2
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $regionKladr;
    /**
     * The district
     * Meta informations extracted from the WSDL
     * - documentation : Район
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $district;
    /**
     * The districtKladr
     * Meta informations extracted from the WSDL
     * - documentation : Код района (или города субъектного подчинения) согласно КЛАДР ЕГИСЗ "Пациент" таблица данных адреса и контактов, поле №3
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $districtKladr;
    /**
     * The city
     * Meta informations extracted from the WSDL
     * - documentation : Населенный пункт
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $city;
    /**
     * The cityKladr
     * Meta informations extracted from the WSDL
     * - documentation : Код населенного пункта согласно КЛАДР ЕГИСЗ "Пациент" таблица данных адреса и контактов, поле №4
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $cityKladr;
    /**
     * The street
     * Meta informations extracted from the WSDL
     * - documentation : Название улицы
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $street;
    /**
     * The streetKladr
     * Meta informations extracted from the WSDL
     * - documentation : Код улицы согласно КЛАДР ЕГИСЗ "Пациент" таблица данных адреса и контактов, поле №8
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $streetKladr;
    /**
     * The house
     * Meta informations extracted from the WSDL
     * - documentation : Номер дома ЕГИСЗ "Пациент" таблица данных адреса и контактов, поле №9
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $house;
    /**
     * The block
     * Meta informations extracted from the WSDL
     * - documentation : Номер корпуса ЕГИСЗ "Пациент" таблица данных адреса и контактов, поле №10
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $block;
    /**
     * The building
     * Meta informations extracted from the WSDL
     * - documentation : Номер строения
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $building;
    /**
     * The apartment
     * Meta informations extracted from the WSDL
     * - documentation : Номер квартиры ЕГИСЗ "Пациент" таблица данных адреса и контактов, поле №11
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $apartment;
    /**
     * The postalCode
     * Meta informations extracted from the WSDL
     * - documentation : Почтовый индекс ЕГИСЗ "Пациент" таблица данных адреса и контактов, поле №7
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $postalCode;
    /**
     * The okato
     * Meta informations extracted from the WSDL
     * - documentation : ОКАТО ТФОМС: OKATOG/OKATOP - Заполняется стыковкой полей TER+ORGN1+ORGN2+ORGN3+RAZDEL справочника OKATO ЕГИСЗ "Пациент" таблица данных адреса и контактов, поле №5
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $okato;
    /**
     * The effectiveDate
     * Meta informations extracted from the WSDL
     * - documentation : Дата регистрации по месту жительства (для адреса регистрации)
     * - minOccurs : 0
     * @var date
     */
    public $effectiveDate;
    /**
     * The locality
     * Meta informations extracted from the WSDL
     * - documentation : Населенный пункт в рамках города
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $locality;
    /**
     * The addressLine
     * Meta informations extracted from the WSDL
     * - documentation : Адрес одной строкой, если нет данных по отдельным полям адреса
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $addressLine;
    /**
     * Constructor method for Address
     * @see parent::__construct()
     * @param string $_country
     * @param string $_region
     * @param string $_regionKladr
     * @param string $_district
     * @param string $_districtKladr
     * @param string $_city
     * @param string $_cityKladr
     * @param string $_street
     * @param string $_streetKladr
     * @param string $_house
     * @param string $_block
     * @param string $_building
     * @param string $_apartment
     * @param string $_postalCode
     * @param string $_okato
     * @param date $_effectiveDate
     * @param string $_locality
     * @param string $_addressLine
     * @return MyMPIStructAddress
     */
    public function __construct($_country = NULL,$_region = NULL,$_regionKladr = NULL,$_district = NULL,$_districtKladr = NULL,$_city = NULL,$_cityKladr = NULL,$_street = NULL,$_streetKladr = NULL,$_house = NULL,$_block = NULL,$_building = NULL,$_apartment = NULL,$_postalCode = NULL,$_okato = NULL,$_effectiveDate = NULL,$_locality = NULL,$_addressLine = NULL)
    {
        MyMPIWsdlClass::__construct(array('country'=>$_country,'region'=>$_region,'regionKladr'=>$_regionKladr,'district'=>$_district,'districtKladr'=>$_districtKladr,'city'=>$_city,'cityKladr'=>$_cityKladr,'street'=>$_street,'streetKladr'=>$_streetKladr,'house'=>$_house,'block'=>$_block,'building'=>$_building,'apartment'=>$_apartment,'postalCode'=>$_postalCode,'okato'=>$_okato,'effectiveDate'=>$_effectiveDate,'locality'=>$_locality,'addressLine'=>$_addressLine),false);
    }
    /**
     * Get country value
     * @return string|null
     */
    public function getCountry()
    {
        return $this->country;
    }
    /**
     * Set country value
     * @param string $_country the country
     * @return string
     */
    public function setCountry($_country)
    {
        return ($this->country = $_country);
    }
    /**
     * Get region value
     * @return string|null
     */
    public function getRegion()
    {
        return $this->region;
    }
    /**
     * Set region value
     * @param string $_region the region
     * @return string
     */
    public function setRegion($_region)
    {
        return ($this->region = $_region);
    }
    /**
     * Get regionKladr value
     * @return string|null
     */
    public function getRegionKladr()
    {
        return $this->regionKladr;
    }
    /**
     * Set regionKladr value
     * @param string $_regionKladr the regionKladr
     * @return string
     */
    public function setRegionKladr($_regionKladr)
    {
        return ($this->regionKladr = $_regionKladr);
    }
    /**
     * Get district value
     * @return string|null
     */
    public function getDistrict()
    {
        return $this->district;
    }
    /**
     * Set district value
     * @param string $_district the district
     * @return string
     */
    public function setDistrict($_district)
    {
        return ($this->district = $_district);
    }
    /**
     * Get districtKladr value
     * @return string|null
     */
    public function getDistrictKladr()
    {
        return $this->districtKladr;
    }
    /**
     * Set districtKladr value
     * @param string $_districtKladr the districtKladr
     * @return string
     */
    public function setDistrictKladr($_districtKladr)
    {
        return ($this->districtKladr = $_districtKladr);
    }
    /**
     * Get city value
     * @return string|null
     */
    public function getCity()
    {
        return $this->city;
    }
    /**
     * Set city value
     * @param string $_city the city
     * @return string
     */
    public function setCity($_city)
    {
        return ($this->city = $_city);
    }
    /**
     * Get cityKladr value
     * @return string|null
     */
    public function getCityKladr()
    {
        return $this->cityKladr;
    }
    /**
     * Set cityKladr value
     * @param string $_cityKladr the cityKladr
     * @return string
     */
    public function setCityKladr($_cityKladr)
    {
        return ($this->cityKladr = $_cityKladr);
    }
    /**
     * Get street value
     * @return string|null
     */
    public function getStreet()
    {
        return $this->street;
    }
    /**
     * Set street value
     * @param string $_street the street
     * @return string
     */
    public function setStreet($_street)
    {
        return ($this->street = $_street);
    }
    /**
     * Get streetKladr value
     * @return string|null
     */
    public function getStreetKladr()
    {
        return $this->streetKladr;
    }
    /**
     * Set streetKladr value
     * @param string $_streetKladr the streetKladr
     * @return string
     */
    public function setStreetKladr($_streetKladr)
    {
        return ($this->streetKladr = $_streetKladr);
    }
    /**
     * Get house value
     * @return string|null
     */
    public function getHouse()
    {
        return $this->house;
    }
    /**
     * Set house value
     * @param string $_house the house
     * @return string
     */
    public function setHouse($_house)
    {
        return ($this->house = $_house);
    }
    /**
     * Get block value
     * @return string|null
     */
    public function getBlock()
    {
        return $this->block;
    }
    /**
     * Set block value
     * @param string $_block the block
     * @return string
     */
    public function setBlock($_block)
    {
        return ($this->block = $_block);
    }
    /**
     * Get building value
     * @return string|null
     */
    public function getBuilding()
    {
        return $this->building;
    }
    /**
     * Set building value
     * @param string $_building the building
     * @return string
     */
    public function setBuilding($_building)
    {
        return ($this->building = $_building);
    }
    /**
     * Get apartment value
     * @return string|null
     */
    public function getApartment()
    {
        return $this->apartment;
    }
    /**
     * Set apartment value
     * @param string $_apartment the apartment
     * @return string
     */
    public function setApartment($_apartment)
    {
        return ($this->apartment = $_apartment);
    }
    /**
     * Get postalCode value
     * @return string|null
     */
    public function getPostalCode()
    {
        return $this->postalCode;
    }
    /**
     * Set postalCode value
     * @param string $_postalCode the postalCode
     * @return string
     */
    public function setPostalCode($_postalCode)
    {
        return ($this->postalCode = $_postalCode);
    }
    /**
     * Get okato value
     * @return string|null
     */
    public function getOkato()
    {
        return $this->okato;
    }
    /**
     * Set okato value
     * @param string $_okato the okato
     * @return string
     */
    public function setOkato($_okato)
    {
        return ($this->okato = $_okato);
    }
    /**
     * Get effectiveDate value
     * @return date|null
     */
    public function getEffectiveDate()
    {
        return $this->effectiveDate;
    }
    /**
     * Set effectiveDate value
     * @param date $_effectiveDate the effectiveDate
     * @return date
     */
    public function setEffectiveDate($_effectiveDate)
    {
        return ($this->effectiveDate = $_effectiveDate);
    }
    /**
     * Get locality value
     * @return string|null
     */
    public function getLocality()
    {
        return $this->locality;
    }
    /**
     * Set locality value
     * @param string $_locality the locality
     * @return string
     */
    public function setLocality($_locality)
    {
        return ($this->locality = $_locality);
    }
    /**
     * Get addressLine value
     * @return string|null
     */
    public function getAddressLine()
    {
        return $this->addressLine;
    }
    /**
     * Set addressLine value
     * @param string $_addressLine the addressLine
     * @return string
     */
    public function setAddressLine($_addressLine)
    {
        return ($this->addressLine = $_addressLine);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructAddress
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
