<?php
/**
 * File for class MyMPIStructMedService
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructMedService originally named MedService
 * Documentation : Оказанные медицинские услуги
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructMedService extends MyMPIWsdlClass
{
    /**
     * The extId
     * Meta informations extracted from the WSDL
     * - documentation : Идентификатор в МИС
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $extId;
    /**
     * The encounterCode
     * Meta informations extracted from the WSDL
     * - documentation : Код эпизода
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $encounterCode;
    /**
     * The enteredBy
     * Meta informations extracted from the WSDL
     * - documentation : Автор записи (врач) ТФОМС: IDDOKT (региональный справочник), PRVS (V004) - специальность
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $enteredBy;
    /**
     * The enteredOn
     * Meta informations extracted from the WSDL
     * - documentation : Дата/время ввода записи в МИС
     * - minOccurs : 0
     * @var dateTime
     */
    public $enteredOn;
    /**
     * The service
     * Meta informations extracted from the WSDL
     * - documentation : Код и название услуги ТФОМС: CODE_USL - Территориальный классификатор услуг (поле PriceCode в справочнике AMB)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $service;
    /**
     * The standard
     * Meta informations extracted from the WSDL
     * - documentation : Код и название стандарта медицинской помощи (СМП)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $standard;
    /**
     * The diagnosis
     * Meta informations extracted from the WSDL
     * - documentation : Диагноз (код МКБ-10 и расшифровка) ТФОМС: только для стомат услуг - DS_DENT
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $diagnosis;
    /**
     * The quantity
     * Meta informations extracted from the WSDL
     * - documentation : Кол-во оказанных услуг ТФОМС: KOL_USL
     * - minOccurs : 0
     * @var decimal
     */
    public $quantity;
    /**
     * The unitOfMeasure
     * Meta informations extracted from the WSDL
     * - documentation : Единица измерения
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $unitOfMeasure;
    /**
     * The renderedOn
     * Meta informations extracted from the WSDL
     * - documentation : Дата/время оказания ТФОМС: DATEUSL
     * - minOccurs : 0
     * @var dateTime
     */
    public $renderedOn;
    /**
     * The renderedBy
     * Meta informations extracted from the WSDL
     * - documentation : Врач ТФОМС: CODE_MD, PRVS
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $renderedBy;
    /**
     * The description
     * Meta informations extracted from the WSDL
     * - documentation : Описание
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $description;
    /**
     * The anesthesia
     * Meta informations extracted from the WSDL
     * - documentation : Метод обезболивания
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $anesthesia;
    /**
     * The complications
     * Meta informations extracted from the WSDL
     * - documentation : Осложнения
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $complications;
    /**
     * The servCareType
     * Meta informations extracted from the WSDL
     * - documentation : Вид медицинской помощи ТФОМС: SKIND (региональный справочник - более детализирован, чем V008)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $servCareType;
    /**
     * The typeOper
     * Meta informations extracted from the WSDL
     * - documentation : Вид лечения - для стационарных услуг ТФОМС: TYPEOPER - Код вида лечения (Из справочника Typeoper)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $typeOper;
    /**
     * The interventionType
     * Meta informations extracted from the WSDL
     * - documentation : Вид вмешательства ТФОМС: INTOX - Код вмешательства (Заполняется кодом вмешательства из справочника INTERV)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $interventionType;
    /**
     * The facilityDept
     * Meta informations extracted from the WSDL
     * - documentation : Отделение МО ТФОМС: PODR - Отделение МО лечения из регионального справочника
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $facilityDept;
    /**
     * The careProfile
     * Meta informations extracted from the WSDL
     * - documentation : Профиль оказанной медицинской помощи ТФОМС: PROFIL (V002)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $careProfile;
    /**
     * The isChildProfile
     * Meta informations extracted from the WSDL
     * - documentation : Признак детского профиля ТФОМС: DET (0-нет, 1-да, заполняется 1 если в прейскуранте поле AGE = 2, т.е. возраст пациента меньше 18 лет)
     * - minOccurs : 0
     * @var boolean
     */
    public $isChildProfile;
    /**
     * The bedProfile
     * Meta informations extracted from the WSDL
     * - documentation : Профиль койки ТФОМС: BEDPROF (справочник LPUPL)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $bedProfile;
    /**
     * The servPaymentType
     * Meta informations extracted from the WSDL
     * - documentation : Способ оплаты медицинской помощи ТФОМС: IDSP (Классификатор способов оплаты медицинской помощи V010)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $servPaymentType;
    /**
     * Constructor method for MedService
     * @see parent::__construct()
     * @param string $_extId
     * @param string $_encounterCode
     * @param MyMPIStructEmployee $_enteredBy
     * @param dateTime $_enteredOn
     * @param MyMPIStructCodeAndName $_service
     * @param MyMPIStructCodeAndName $_standard
     * @param MyMPIStructCodeAndName $_diagnosis
     * @param decimal $_quantity
     * @param MyMPIStructCodeAndName $_unitOfMeasure
     * @param dateTime $_renderedOn
     * @param MyMPIStructEmployee $_renderedBy
     * @param string $_description
     * @param MyMPIStructCodeAndName $_anesthesia
     * @param string $_complications
     * @param MyMPIStructCodeAndName $_servCareType
     * @param MyMPIStructCodeAndName $_typeOper
     * @param MyMPIStructCodeAndName $_interventionType
     * @param MyMPIStructCodeAndName $_facilityDept
     * @param MyMPIStructCodeAndName $_careProfile
     * @param boolean $_isChildProfile
     * @param MyMPIStructCodeAndName $_bedProfile
     * @param MyMPIStructCodeAndName $_servPaymentType
     * @return MyMPIStructMedService
     */
    public function __construct($_extId = NULL,$_encounterCode = NULL,$_enteredBy = NULL,$_enteredOn = NULL,$_service = NULL,$_standard = NULL,$_diagnosis = NULL,$_quantity = NULL,$_unitOfMeasure = NULL,$_renderedOn = NULL,$_renderedBy = NULL,$_description = NULL,$_anesthesia = NULL,$_complications = NULL,$_servCareType = NULL,$_typeOper = NULL,$_interventionType = NULL,$_facilityDept = NULL,$_careProfile = NULL,$_isChildProfile = NULL,$_bedProfile = NULL,$_servPaymentType = NULL)
    {
        parent::__construct(array('extId'=>$_extId,'encounterCode'=>$_encounterCode,'enteredBy'=>$_enteredBy,'enteredOn'=>$_enteredOn,'service'=>$_service,'standard'=>$_standard,'diagnosis'=>$_diagnosis,'quantity'=>$_quantity,'unitOfMeasure'=>$_unitOfMeasure,'renderedOn'=>$_renderedOn,'renderedBy'=>$_renderedBy,'description'=>$_description,'anesthesia'=>$_anesthesia,'complications'=>$_complications,'servCareType'=>$_servCareType,'typeOper'=>$_typeOper,'interventionType'=>$_interventionType,'facilityDept'=>$_facilityDept,'careProfile'=>$_careProfile,'isChildProfile'=>$_isChildProfile,'bedProfile'=>$_bedProfile,'servPaymentType'=>$_servPaymentType),false);
    }
    /**
     * Get extId value
     * @return string|null
     */
    public function getExtId()
    {
        return $this->extId;
    }
    /**
     * Set extId value
     * @param string $_extId the extId
     * @return string
     */
    public function setExtId($_extId)
    {
        return ($this->extId = $_extId);
    }
    /**
     * Get encounterCode value
     * @return string|null
     */
    public function getEncounterCode()
    {
        return $this->encounterCode;
    }
    /**
     * Set encounterCode value
     * @param string $_encounterCode the encounterCode
     * @return string
     */
    public function setEncounterCode($_encounterCode)
    {
        return ($this->encounterCode = $_encounterCode);
    }
    /**
     * Get enteredBy value
     * @return MyMPIStructEmployee|null
     */
    public function getEnteredBy()
    {
        return $this->enteredBy;
    }
    /**
     * Set enteredBy value
     * @param MyMPIStructEmployee $_enteredBy the enteredBy
     * @return MyMPIStructEmployee
     */
    public function setEnteredBy($_enteredBy)
    {
        return ($this->enteredBy = $_enteredBy);
    }
    /**
     * Get enteredOn value
     * @return dateTime|null
     */
    public function getEnteredOn()
    {
        return $this->enteredOn;
    }
    /**
     * Set enteredOn value
     * @param dateTime $_enteredOn the enteredOn
     * @return dateTime
     */
    public function setEnteredOn($_enteredOn)
    {
        return ($this->enteredOn = $_enteredOn);
    }
    /**
     * Get service value
     * @return MyMPIStructCodeAndName|null
     */
    public function getService()
    {
        return $this->service;
    }
    /**
     * Set service value
     * @param MyMPIStructCodeAndName $_service the service
     * @return MyMPIStructCodeAndName
     */
    public function setService($_service)
    {
        return ($this->service = $_service);
    }
    /**
     * Get standard value
     * @return MyMPIStructCodeAndName|null
     */
    public function getStandard()
    {
        return $this->standard;
    }
    /**
     * Set standard value
     * @param MyMPIStructCodeAndName $_standard the standard
     * @return MyMPIStructCodeAndName
     */
    public function setStandard($_standard)
    {
        return ($this->standard = $_standard);
    }
    /**
     * Get diagnosis value
     * @return MyMPIStructCodeAndName|null
     */
    public function getDiagnosis()
    {
        return $this->diagnosis;
    }
    /**
     * Set diagnosis value
     * @param MyMPIStructCodeAndName $_diagnosis the diagnosis
     * @return MyMPIStructCodeAndName
     */
    public function setDiagnosis($_diagnosis)
    {
        return ($this->diagnosis = $_diagnosis);
    }
    /**
     * Get quantity value
     * @return decimal|null
     */
    public function getQuantity()
    {
        return $this->quantity;
    }
    /**
     * Set quantity value
     * @param decimal $_quantity the quantity
     * @return decimal
     */
    public function setQuantity($_quantity)
    {
        return ($this->quantity = $_quantity);
    }
    /**
     * Get unitOfMeasure value
     * @return MyMPIStructCodeAndName|null
     */
    public function getUnitOfMeasure()
    {
        return $this->unitOfMeasure;
    }
    /**
     * Set unitOfMeasure value
     * @param MyMPIStructCodeAndName $_unitOfMeasure the unitOfMeasure
     * @return MyMPIStructCodeAndName
     */
    public function setUnitOfMeasure($_unitOfMeasure)
    {
        return ($this->unitOfMeasure = $_unitOfMeasure);
    }
    /**
     * Get renderedOn value
     * @return dateTime|null
     */
    public function getRenderedOn()
    {
        return $this->renderedOn;
    }
    /**
     * Set renderedOn value
     * @param dateTime $_renderedOn the renderedOn
     * @return dateTime
     */
    public function setRenderedOn($_renderedOn)
    {
        return ($this->renderedOn = $_renderedOn);
    }
    /**
     * Get renderedBy value
     * @return MyMPIStructEmployee|null
     */
    public function getRenderedBy()
    {
        return $this->renderedBy;
    }
    /**
     * Set renderedBy value
     * @param MyMPIStructEmployee $_renderedBy the renderedBy
     * @return MyMPIStructEmployee
     */
    public function setRenderedBy($_renderedBy)
    {
        return ($this->renderedBy = $_renderedBy);
    }
    /**
     * Get description value
     * @return string|null
     */
    public function getDescription()
    {
        return $this->description;
    }
    /**
     * Set description value
     * @param string $_description the description
     * @return string
     */
    public function setDescription($_description)
    {
        return ($this->description = $_description);
    }
    /**
     * Get anesthesia value
     * @return MyMPIStructCodeAndName|null
     */
    public function getAnesthesia()
    {
        return $this->anesthesia;
    }
    /**
     * Set anesthesia value
     * @param MyMPIStructCodeAndName $_anesthesia the anesthesia
     * @return MyMPIStructCodeAndName
     */
    public function setAnesthesia($_anesthesia)
    {
        return ($this->anesthesia = $_anesthesia);
    }
    /**
     * Get complications value
     * @return string|null
     */
    public function getComplications()
    {
        return $this->complications;
    }
    /**
     * Set complications value
     * @param string $_complications the complications
     * @return string
     */
    public function setComplications($_complications)
    {
        return ($this->complications = $_complications);
    }
    /**
     * Get servCareType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getServCareType()
    {
        return $this->servCareType;
    }
    /**
     * Set servCareType value
     * @param MyMPIStructCodeAndName $_servCareType the servCareType
     * @return MyMPIStructCodeAndName
     */
    public function setServCareType($_servCareType)
    {
        return ($this->servCareType = $_servCareType);
    }
    /**
     * Get typeOper value
     * @return MyMPIStructCodeAndName|null
     */
    public function getTypeOper()
    {
        return $this->typeOper;
    }
    /**
     * Set typeOper value
     * @param MyMPIStructCodeAndName $_typeOper the typeOper
     * @return MyMPIStructCodeAndName
     */
    public function setTypeOper($_typeOper)
    {
        return ($this->typeOper = $_typeOper);
    }
    /**
     * Get interventionType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getInterventionType()
    {
        return $this->interventionType;
    }
    /**
     * Set interventionType value
     * @param MyMPIStructCodeAndName $_interventionType the interventionType
     * @return MyMPIStructCodeAndName
     */
    public function setInterventionType($_interventionType)
    {
        return ($this->interventionType = $_interventionType);
    }
    /**
     * Get facilityDept value
     * @return MyMPIStructCodeAndName|null
     */
    public function getFacilityDept()
    {
        return $this->facilityDept;
    }
    /**
     * Set facilityDept value
     * @param MyMPIStructCodeAndName $_facilityDept the facilityDept
     * @return MyMPIStructCodeAndName
     */
    public function setFacilityDept($_facilityDept)
    {
        return ($this->facilityDept = $_facilityDept);
    }
    /**
     * Get careProfile value
     * @return MyMPIStructCodeAndName|null
     */
    public function getCareProfile()
    {
        return $this->careProfile;
    }
    /**
     * Set careProfile value
     * @param MyMPIStructCodeAndName $_careProfile the careProfile
     * @return MyMPIStructCodeAndName
     */
    public function setCareProfile($_careProfile)
    {
        return ($this->careProfile = $_careProfile);
    }
    /**
     * Get isChildProfile value
     * @return boolean|null
     */
    public function getIsChildProfile()
    {
        return $this->isChildProfile;
    }
    /**
     * Set isChildProfile value
     * @param boolean $_isChildProfile the isChildProfile
     * @return boolean
     */
    public function setIsChildProfile($_isChildProfile)
    {
        return ($this->isChildProfile = $_isChildProfile);
    }
    /**
     * Get bedProfile value
     * @return MyMPIStructCodeAndName|null
     */
    public function getBedProfile()
    {
        return $this->bedProfile;
    }
    /**
     * Set bedProfile value
     * @param MyMPIStructCodeAndName $_bedProfile the bedProfile
     * @return MyMPIStructCodeAndName
     */
    public function setBedProfile($_bedProfile)
    {
        return ($this->bedProfile = $_bedProfile);
    }
    /**
     * Get servPaymentType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getServPaymentType()
    {
        return $this->servPaymentType;
    }
    /**
     * Set servPaymentType value
     * @param MyMPIStructCodeAndName $_servPaymentType the servPaymentType
     * @return MyMPIStructCodeAndName
     */
    public function setServPaymentType($_servPaymentType)
    {
        return ($this->servPaymentType = $_servPaymentType);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructMedService
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
