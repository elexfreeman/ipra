<?php
/**
 * File for class MyMPIStructEmergencyUnit
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructEmergencyUnit originally named EmergencyUnit
 * Documentation : Состав бригады скорой помощи
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructEmergencyUnit extends MyMPIStructBaseSerial
{
    /**
     * The unitId
     * Meta informations extracted from the WSDL
     * - documentation : Номер бригады ADIS: NUMB
     * - minOccurs : 0
     * @var long
     */
    public $unitId;
    /**
     * The unitType
     * Meta informations extracted from the WSDL
     * - documentation : Профиль бригады ADIS: PRFB
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $unitType;
    /**
     * The vehicleNumber
     * Meta informations extracted from the WSDL
     * - documentation : Номер машины ADIS: NCAR
     * - minOccurs : 0
     * @var string
     */
    public $vehicleNumber;
    /**
     * The headOfUnit
     * Meta informations extracted from the WSDL
     * - documentation : Старший в бригаде ADIS: TABN, DOKT
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $headOfUnit;
    /**
     * The firstDeputy
     * Meta informations extracted from the WSDL
     * - documentation : 1-й помощник ADIS: TAB2
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $firstDeputy;
    /**
     * The secondDeputy
     * Meta informations extracted from the WSDL
     * - documentation : 2-й помощник ADIS: TAB3
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $secondDeputy;
    /**
     * The driver
     * Meta informations extracted from the WSDL
     * - documentation : Водитель ADIS: TAB4
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $driver;
    /**
     * Constructor method for EmergencyUnit
     * @see parent::__construct()
     * @param long $_unitId
     * @param MyMPIStructCodeAndName $_unitType
     * @param string $_vehicleNumber
     * @param MyMPIStructEmployee $_headOfUnit
     * @param MyMPIStructEmployee $_firstDeputy
     * @param MyMPIStructEmployee $_secondDeputy
     * @param MyMPIStructEmployee $_driver
     * @return MyMPIStructEmergencyUnit
     */
    public function __construct($_unitId = NULL,$_unitType = NULL,$_vehicleNumber = NULL,$_headOfUnit = NULL,$_firstDeputy = NULL,$_secondDeputy = NULL,$_driver = NULL)
    {
        MyMPIWsdlClass::__construct(array('unitId'=>$_unitId,'unitType'=>$_unitType,'vehicleNumber'=>$_vehicleNumber,'headOfUnit'=>$_headOfUnit,'firstDeputy'=>$_firstDeputy,'secondDeputy'=>$_secondDeputy,'driver'=>$_driver),false);
    }
    /**
     * Get unitId value
     * @return long|null
     */
    public function getUnitId()
    {
        return $this->unitId;
    }
    /**
     * Set unitId value
     * @param long $_unitId the unitId
     * @return long
     */
    public function setUnitId($_unitId)
    {
        return ($this->unitId = $_unitId);
    }
    /**
     * Get unitType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getUnitType()
    {
        return $this->unitType;
    }
    /**
     * Set unitType value
     * @param MyMPIStructCodeAndName $_unitType the unitType
     * @return MyMPIStructCodeAndName
     */
    public function setUnitType($_unitType)
    {
        return ($this->unitType = $_unitType);
    }
    /**
     * Get vehicleNumber value
     * @return string|null
     */
    public function getVehicleNumber()
    {
        return $this->vehicleNumber;
    }
    /**
     * Set vehicleNumber value
     * @param string $_vehicleNumber the vehicleNumber
     * @return string
     */
    public function setVehicleNumber($_vehicleNumber)
    {
        return ($this->vehicleNumber = $_vehicleNumber);
    }
    /**
     * Get headOfUnit value
     * @return MyMPIStructEmployee|null
     */
    public function getHeadOfUnit()
    {
        return $this->headOfUnit;
    }
    /**
     * Set headOfUnit value
     * @param MyMPIStructEmployee $_headOfUnit the headOfUnit
     * @return MyMPIStructEmployee
     */
    public function setHeadOfUnit($_headOfUnit)
    {
        return ($this->headOfUnit = $_headOfUnit);
    }
    /**
     * Get firstDeputy value
     * @return MyMPIStructEmployee|null
     */
    public function getFirstDeputy()
    {
        return $this->firstDeputy;
    }
    /**
     * Set firstDeputy value
     * @param MyMPIStructEmployee $_firstDeputy the firstDeputy
     * @return MyMPIStructEmployee
     */
    public function setFirstDeputy($_firstDeputy)
    {
        return ($this->firstDeputy = $_firstDeputy);
    }
    /**
     * Get secondDeputy value
     * @return MyMPIStructEmployee|null
     */
    public function getSecondDeputy()
    {
        return $this->secondDeputy;
    }
    /**
     * Set secondDeputy value
     * @param MyMPIStructEmployee $_secondDeputy the secondDeputy
     * @return MyMPIStructEmployee
     */
    public function setSecondDeputy($_secondDeputy)
    {
        return ($this->secondDeputy = $_secondDeputy);
    }
    /**
     * Get driver value
     * @return MyMPIStructEmployee|null
     */
    public function getDriver()
    {
        return $this->driver;
    }
    /**
     * Set driver value
     * @param MyMPIStructEmployee $_driver the driver
     * @return MyMPIStructEmployee
     */
    public function setDriver($_driver)
    {
        return ($this->driver = $_driver);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructEmergencyUnit
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
