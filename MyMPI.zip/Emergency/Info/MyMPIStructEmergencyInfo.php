<?php
/**
 * File for class MyMPIStructEmergencyInfo
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructEmergencyInfo originally named EmergencyInfo
 * Documentation : Детали вызова скорой медицинской помощи
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructEmergencyInfo extends MyMPIStructBaseSerial
{
    /**
     * The stationId
     * Meta informations extracted from the WSDL
     * - documentation : Номер подстанции ADIS: STAN
     * - minOccurs : 0
     * @var long
     */
    public $stationId;
    /**
     * The address
     * Meta informations extracted from the WSDL
     * - documentation : Адрес вызова ф 109/у
     * - minOccurs : 0
     * @var MyMPIStructAddress
     */
    public $address;
    /**
     * The callDate
     * Meta informations extracted from the WSDL
     * - documentation : Дата поступления вызова ф 109/у ADIS: DPRM
     * - minOccurs : 0
     * @var date
     */
    public $callDate;
    /**
     * The callTime
     * Meta informations extracted from the WSDL
     * - documentation : Время поступления вызова ф 109/у ADIS: TPRM
     * - minOccurs : 0
     * @var time
     */
    public $callTime;
    /**
     * The callReason
     * Meta informations extracted from the WSDL
     * - documentation : Повод вызова ф 109/у ADIS: POVD
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $callReason;
    /**
     * The calledBy
     * Meta informations extracted from the WSDL
     * - documentation : Лицо, вызывающее бригаду скорой помощи ф 109/у ADIS: KTOV
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $calledBy;
    /**
     * The callerPhone
     * Meta informations extracted from the WSDL
     * - documentation : Телефон лица, вызывающего бригаду скорой помощи ф 109/у ADIS: TELF
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $callerPhone;
    /**
     * The destination
     * Meta informations extracted from the WSDL
     * - documentation : Куда направлен ф 109/у ADIS: KUDA
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $destination;
    /**
     * The unit
     * Meta informations extracted from the WSDL
     * - documentation : Состав бригады скорой помощи ф 109/у
     * - minOccurs : 0
     * @var MyMPIStructEmergencyUnit
     */
    public $unit;
    /**
     * The passTime
     * Meta informations extracted from the WSDL
     * - documentation : Время передачи ADIS: TPER
     * - minOccurs : 0
     * @var time
     */
    public $passTime;
    /**
     * The departureTime
     * Meta informations extracted from the WSDL
     * - documentation : Время выезда на вызов ф 109/у ADIS: VYEZ
     * - minOccurs : 0
     * @var time
     */
    public $departureTime;
    /**
     * The arrivalTime
     * Meta informations extracted from the WSDL
     * - documentation : Время прибытия ADIS: PRZD
     * - minOccurs : 0
     * @var time
     */
    public $arrivalTime;
    /**
     * The hospitalizationTime
     * Meta informations extracted from the WSDL
     * - documentation : Время отзвона о госпитализации ADIS: TGSP
     * - minOccurs : 0
     * @var time
     */
    public $hospitalizationTime;
    /**
     * The completionTime
     * Meta informations extracted from the WSDL
     * - documentation : Время исполнения ф 109/у ADIS: TISP
     * - minOccurs : 0
     * @var time
     */
    public $completionTime;
    /**
     * The returnTime
     * Meta informations extracted from the WSDL
     * - documentation : Время возвращения ADIS: TVZV
     * - minOccurs : 0
     * @var time
     */
    public $returnTime;
    /**
     * The distance
     * Meta informations extracted from the WSDL
     * - documentation : Километраж ADIS: KILO
     * - minOccurs : 0
     * @var long
     */
    public $distance;
    /**
     * The callResult
     * Meta informations extracted from the WSDL
     * - documentation : Результат вызова ADIS: REZL
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $callResult;
    /**
     * The location
     * Meta informations extracted from the WSDL
     * - documentation : Место вызова ADIS: MEST
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $location;
    /**
     * Constructor method for EmergencyInfo
     * @see parent::__construct()
     * @param long $_stationId
     * @param MyMPIStructAddress $_address
     * @param date $_callDate
     * @param time $_callTime
     * @param MyMPIStructCodeAndName $_callReason
     * @param string $_calledBy
     * @param string $_callerPhone
     * @param string $_destination
     * @param MyMPIStructEmergencyUnit $_unit
     * @param time $_passTime
     * @param time $_departureTime
     * @param time $_arrivalTime
     * @param time $_hospitalizationTime
     * @param time $_completionTime
     * @param time $_returnTime
     * @param long $_distance
     * @param MyMPIStructCodeAndName $_callResult
     * @param MyMPIStructCodeAndName $_location
     * @return MyMPIStructEmergencyInfo
     */
    public function __construct($_stationId = NULL,$_address = NULL,$_callDate = NULL,$_callTime = NULL,$_callReason = NULL,$_calledBy = NULL,$_callerPhone = NULL,$_destination = NULL,$_unit = NULL,$_passTime = NULL,$_departureTime = NULL,$_arrivalTime = NULL,$_hospitalizationTime = NULL,$_completionTime = NULL,$_returnTime = NULL,$_distance = NULL,$_callResult = NULL,$_location = NULL)
    {
        MyMPIWsdlClass::__construct(array('stationId'=>$_stationId,'address'=>$_address,'callDate'=>$_callDate,'callTime'=>$_callTime,'callReason'=>$_callReason,'calledBy'=>$_calledBy,'callerPhone'=>$_callerPhone,'destination'=>$_destination,'unit'=>$_unit,'passTime'=>$_passTime,'departureTime'=>$_departureTime,'arrivalTime'=>$_arrivalTime,'hospitalizationTime'=>$_hospitalizationTime,'completionTime'=>$_completionTime,'returnTime'=>$_returnTime,'distance'=>$_distance,'callResult'=>$_callResult,'location'=>$_location),false);
    }
    /**
     * Get stationId value
     * @return long|null
     */
    public function getStationId()
    {
        return $this->stationId;
    }
    /**
     * Set stationId value
     * @param long $_stationId the stationId
     * @return long
     */
    public function setStationId($_stationId)
    {
        return ($this->stationId = $_stationId);
    }
    /**
     * Get address value
     * @return MyMPIStructAddress|null
     */
    public function getAddress()
    {
        return $this->address;
    }
    /**
     * Set address value
     * @param MyMPIStructAddress $_address the address
     * @return MyMPIStructAddress
     */
    public function setAddress($_address)
    {
        return ($this->address = $_address);
    }
    /**
     * Get callDate value
     * @return date|null
     */
    public function getCallDate()
    {
        return $this->callDate;
    }
    /**
     * Set callDate value
     * @param date $_callDate the callDate
     * @return date
     */
    public function setCallDate($_callDate)
    {
        return ($this->callDate = $_callDate);
    }
    /**
     * Get callTime value
     * @return time|null
     */
    public function getCallTime()
    {
        return $this->callTime;
    }
    /**
     * Set callTime value
     * @param time $_callTime the callTime
     * @return time
     */
    public function setCallTime($_callTime)
    {
        return ($this->callTime = $_callTime);
    }
    /**
     * Get callReason value
     * @return MyMPIStructCodeAndName|null
     */
    public function getCallReason()
    {
        return $this->callReason;
    }
    /**
     * Set callReason value
     * @param MyMPIStructCodeAndName $_callReason the callReason
     * @return MyMPIStructCodeAndName
     */
    public function setCallReason($_callReason)
    {
        return ($this->callReason = $_callReason);
    }
    /**
     * Get calledBy value
     * @return string|null
     */
    public function getCalledBy()
    {
        return $this->calledBy;
    }
    /**
     * Set calledBy value
     * @param string $_calledBy the calledBy
     * @return string
     */
    public function setCalledBy($_calledBy)
    {
        return ($this->calledBy = $_calledBy);
    }
    /**
     * Get callerPhone value
     * @return string|null
     */
    public function getCallerPhone()
    {
        return $this->callerPhone;
    }
    /**
     * Set callerPhone value
     * @param string $_callerPhone the callerPhone
     * @return string
     */
    public function setCallerPhone($_callerPhone)
    {
        return ($this->callerPhone = $_callerPhone);
    }
    /**
     * Get destination value
     * @return string|null
     */
    public function getDestination()
    {
        return $this->destination;
    }
    /**
     * Set destination value
     * @param string $_destination the destination
     * @return string
     */
    public function setDestination($_destination)
    {
        return ($this->destination = $_destination);
    }
    /**
     * Get unit value
     * @return MyMPIStructEmergencyUnit|null
     */
    public function getUnit()
    {
        return $this->unit;
    }
    /**
     * Set unit value
     * @param MyMPIStructEmergencyUnit $_unit the unit
     * @return MyMPIStructEmergencyUnit
     */
    public function setUnit($_unit)
    {
        return ($this->unit = $_unit);
    }
    /**
     * Get passTime value
     * @return time|null
     */
    public function getPassTime()
    {
        return $this->passTime;
    }
    /**
     * Set passTime value
     * @param time $_passTime the passTime
     * @return time
     */
    public function setPassTime($_passTime)
    {
        return ($this->passTime = $_passTime);
    }
    /**
     * Get departureTime value
     * @return time|null
     */
    public function getDepartureTime()
    {
        return $this->departureTime;
    }
    /**
     * Set departureTime value
     * @param time $_departureTime the departureTime
     * @return time
     */
    public function setDepartureTime($_departureTime)
    {
        return ($this->departureTime = $_departureTime);
    }
    /**
     * Get arrivalTime value
     * @return time|null
     */
    public function getArrivalTime()
    {
        return $this->arrivalTime;
    }
    /**
     * Set arrivalTime value
     * @param time $_arrivalTime the arrivalTime
     * @return time
     */
    public function setArrivalTime($_arrivalTime)
    {
        return ($this->arrivalTime = $_arrivalTime);
    }
    /**
     * Get hospitalizationTime value
     * @return time|null
     */
    public function getHospitalizationTime()
    {
        return $this->hospitalizationTime;
    }
    /**
     * Set hospitalizationTime value
     * @param time $_hospitalizationTime the hospitalizationTime
     * @return time
     */
    public function setHospitalizationTime($_hospitalizationTime)
    {
        return ($this->hospitalizationTime = $_hospitalizationTime);
    }
    /**
     * Get completionTime value
     * @return time|null
     */
    public function getCompletionTime()
    {
        return $this->completionTime;
    }
    /**
     * Set completionTime value
     * @param time $_completionTime the completionTime
     * @return time
     */
    public function setCompletionTime($_completionTime)
    {
        return ($this->completionTime = $_completionTime);
    }
    /**
     * Get returnTime value
     * @return time|null
     */
    public function getReturnTime()
    {
        return $this->returnTime;
    }
    /**
     * Set returnTime value
     * @param time $_returnTime the returnTime
     * @return time
     */
    public function setReturnTime($_returnTime)
    {
        return ($this->returnTime = $_returnTime);
    }
    /**
     * Get distance value
     * @return long|null
     */
    public function getDistance()
    {
        return $this->distance;
    }
    /**
     * Set distance value
     * @param long $_distance the distance
     * @return long
     */
    public function setDistance($_distance)
    {
        return ($this->distance = $_distance);
    }
    /**
     * Get callResult value
     * @return MyMPIStructCodeAndName|null
     */
    public function getCallResult()
    {
        return $this->callResult;
    }
    /**
     * Set callResult value
     * @param MyMPIStructCodeAndName $_callResult the callResult
     * @return MyMPIStructCodeAndName
     */
    public function setCallResult($_callResult)
    {
        return ($this->callResult = $_callResult);
    }
    /**
     * Get location value
     * @return MyMPIStructCodeAndName|null
     */
    public function getLocation()
    {
        return $this->location;
    }
    /**
     * Set location value
     * @param MyMPIStructCodeAndName $_location the location
     * @return MyMPIStructCodeAndName
     */
    public function setLocation($_location)
    {
        return ($this->location = $_location);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructEmergencyInfo
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
