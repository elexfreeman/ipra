<?php
/**
 * File for class MyMPIStructCabEmployee
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructCabEmployee originally named CabEmployee
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructCabEmployee extends MyMPIStructEmployee
{
    /**
     * The lpu
     * Meta informations extracted from the WSDL
     * - documentation : ЛПУ
     * - minOccurs : 0
     * @var MyMPIStructClinic
     */
    public $lpu;
    /**
     * Constructor method for CabEmployee
     * @see parent::__construct()
     * @param MyMPIStructClinic $_lpu
     * @return MyMPIStructCabEmployee
     */
    public function __construct($_lpu = NULL)
    {
        MyMPIWsdlClass::__construct(array('lpu'=>$_lpu),false);
    }
    /**
     * Get lpu value
     * @return MyMPIStructClinic|null
     */
    public function getLpu()
    {
        return $this->lpu;
    }
    /**
     * Set lpu value
     * @param MyMPIStructClinic $_lpu the lpu
     * @return MyMPIStructClinic
     */
    public function setLpu($_lpu)
    {
        return ($this->lpu = $_lpu);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructCabEmployee
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
