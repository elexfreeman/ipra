<?php
/**
 * File for class MyMPIStructDispensarySupervision
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructDispensarySupervision originally named DispensarySupervision
 * Documentation : Диспансерное наблюдение
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructDispensarySupervision extends MyMPIStructBaseSerial
{
    /**
     * The startDate
     * Meta informations extracted from the WSDL
     * - documentation : Дата постановки на диспансерное наблюдение
     * - minOccurs : 0
     * @var date
     */
    public $startDate;
    /**
     * The stopDate
     * Meta informations extracted from the WSDL
     * - documentation : Дата снятия с диспансерного наблюдения
     * - minOccurs : 0
     * @var date
     */
    public $stopDate;
    /**
     * The startedBy
     * Meta informations extracted from the WSDL
     * - documentation : Кто осуществил постановку на диспансерное наблюдение
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $startedBy;
    /**
     * The stoppedBy
     * Meta informations extracted from the WSDL
     * - documentation : Кто осуществил снятие с диспансерного наблюдения
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $stoppedBy;
    /**
     * The stopReason
     * Meta informations extracted from the WSDL
     * - documentation : Причина снятия с диспансерного наблюдения
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $stopReason;
    /**
     * Constructor method for DispensarySupervision
     * @see parent::__construct()
     * @param date $_startDate
     * @param date $_stopDate
     * @param MyMPIStructEmployee $_startedBy
     * @param MyMPIStructEmployee $_stoppedBy
     * @param MyMPIStructCodeAndName $_stopReason
     * @return MyMPIStructDispensarySupervision
     */
    public function __construct($_startDate = NULL,$_stopDate = NULL,$_startedBy = NULL,$_stoppedBy = NULL,$_stopReason = NULL)
    {
        MyMPIWsdlClass::__construct(array('startDate'=>$_startDate,'stopDate'=>$_stopDate,'startedBy'=>$_startedBy,'stoppedBy'=>$_stoppedBy,'stopReason'=>$_stopReason),false);
    }
    /**
     * Get startDate value
     * @return date|null
     */
    public function getStartDate()
    {
        return $this->startDate;
    }
    /**
     * Set startDate value
     * @param date $_startDate the startDate
     * @return date
     */
    public function setStartDate($_startDate)
    {
        return ($this->startDate = $_startDate);
    }
    /**
     * Get stopDate value
     * @return date|null
     */
    public function getStopDate()
    {
        return $this->stopDate;
    }
    /**
     * Set stopDate value
     * @param date $_stopDate the stopDate
     * @return date
     */
    public function setStopDate($_stopDate)
    {
        return ($this->stopDate = $_stopDate);
    }
    /**
     * Get startedBy value
     * @return MyMPIStructEmployee|null
     */
    public function getStartedBy()
    {
        return $this->startedBy;
    }
    /**
     * Set startedBy value
     * @param MyMPIStructEmployee $_startedBy the startedBy
     * @return MyMPIStructEmployee
     */
    public function setStartedBy($_startedBy)
    {
        return ($this->startedBy = $_startedBy);
    }
    /**
     * Get stoppedBy value
     * @return MyMPIStructEmployee|null
     */
    public function getStoppedBy()
    {
        return $this->stoppedBy;
    }
    /**
     * Set stoppedBy value
     * @param MyMPIStructEmployee $_stoppedBy the stoppedBy
     * @return MyMPIStructEmployee
     */
    public function setStoppedBy($_stoppedBy)
    {
        return ($this->stoppedBy = $_stoppedBy);
    }
    /**
     * Get stopReason value
     * @return MyMPIStructCodeAndName|null
     */
    public function getStopReason()
    {
        return $this->stopReason;
    }
    /**
     * Set stopReason value
     * @param MyMPIStructCodeAndName $_stopReason the stopReason
     * @return MyMPIStructCodeAndName
     */
    public function setStopReason($_stopReason)
    {
        return ($this->stopReason = $_stopReason);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructDispensarySupervision
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
