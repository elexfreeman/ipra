<?php
/**
 * File for class MyMPIStructDecease
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructDecease originally named Decease
 * Documentation : Информация о смерти
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructDecease extends MyMPIWsdlClass
{
    /**
     * The extId
     * Meta informations extracted from the WSDL
     * - documentation : Идентификатор в МИС
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $extId;
    /**
     * The encounterCode
     * Meta informations extracted from the WSDL
     * - documentation : Код эпизода
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $encounterCode;
    /**
     * The enteredBy
     * Meta informations extracted from the WSDL
     * - documentation : Автор записи (врач) ТФОМС: IDDOKT (региональный справочник), PRVS (V004) - специальность
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $enteredBy;
    /**
     * The enteredOn
     * Meta informations extracted from the WSDL
     * - documentation : Дата/время ввода записи в МИС
     * - minOccurs : 0
     * @var dateTime
     */
    public $enteredOn;
    /**
     * The certificateSeries
     * Meta informations extracted from the WSDL
     * - documentation : Серия МСС MORTALITY: S_DOC ф 106/у-08
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $certificateSeries;
    /**
     * The certificateNumber
     * Meta informations extracted from the WSDL
     * - documentation : Номер МСС MORTALITY: N_DOC ф 106/у-08
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $certificateNumber;
    /**
     * The certificateDateOfIssue
     * Meta informations extracted from the WSDL
     * - documentation : Дата выдачи МСС MORTALITY: DDOC ф 106/у-08
     * - minOccurs : 0
     * @var date
     */
    public $certificateDateOfIssue;
    /**
     * The certificateFacility
     * Meta informations extracted from the WSDL
     * - documentation : ЛПУ, выдавшее МСС MORTALITY: LPUDOC ф 106/у-08
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $certificateFacility;
    /**
     * The certificateType
     * Meta informations extracted from the WSDL
     * - documentation : Тип МСС MORTALITY: STT ф 106/у-08
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $certificateType;
    /**
     * The certificateFilledBy
     * Meta informations extracted from the WSDL
     * - documentation : Врач,заполнивший МСС MORTALITY: FW_ZMS ф 106/у-08
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $certificateFilledBy;
    /**
     * The placeOfDeath
     * Meta informations extracted from the WSDL
     * - documentation : Смерть наступила в MORTALITY: MESTO, MESTO_NOTE ф 106/у-08
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $placeOfDeath;
    /**
     * The causedBy
     * Meta informations extracted from the WSDL
     * - documentation : Cмерть произошла от MORTALITY: PRID ф 106/у-08
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $causedBy;
    /**
     * The timeOfDeath
     * Meta informations extracted from the WSDL
     * - documentation : Время смерти MORTALITY: W_DEATH ф 106/у-08
     * - minOccurs : 0
     * @var time
     */
    public $timeOfDeath;
    /**
     * The firstPathologicDuration
     * Meta informations extracted from the WSDL
     * - documentation : Период времени между началом патологического процесса и смертью по 1-му диагнозу MORTALITY: PWR_D1_L, PWR_D1_M, PWR_D1_D, PWR_D1_H, PWR_D1_MIN ф 106/у-08
     * - minOccurs : 0
     * @var string
     */
    public $firstPathologicDuration;
    /**
     * The secondPathologicDuration
     * Meta informations extracted from the WSDL
     * - documentation : Период времени между началом патологического процесса и смертью по 2-му диагнозу MORTALITY: PWR_D2_L, PWR_D2_M, PWR_D2_D, PWR_D2_H, PWR_D2_MIN ф 106/у-08
     * - minOccurs : 0
     * @var string
     */
    public $secondPathologicDuration;
    /**
     * The thirdPathologicDuration
     * Meta informations extracted from the WSDL
     * - documentation : Период времени между началом патологического процесса и смертью по 3-му диагнозу MORTALITY: PWR_D3_L, PWR_D3_M, PWR_D3_D, PWR_D3_H, PWR_D3_MIN ф 106/у-08
     * - minOccurs : 0
     * @var string
     */
    public $thirdPathologicDuration;
    /**
     * The fourthPathologicDuration
     * Meta informations extracted from the WSDL
     * - documentation : Период времени между началом патологического процесса и смертью по 4-му диагнозу MORTALITY: PWR_D4_L, PWR_D4_M, PWR_D4_D, PWR_D4_H, PWR_D4_MIN ф 106/у-08
     * - minOccurs : 0
     * @var string
     */
    public $fourthPathologicDuration;
    /**
     * The deceaseFacility
     * Meta informations extracted from the WSDL
     * - documentation : ЛПУ по месту смерти MORTALITY: LPU
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $deceaseFacility;
    /**
     * The mainDiagnosis
     * Meta informations extracted from the WSDL
     * - documentation : Основной диагноз - причина смерти MORTALITY: DS_G
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $mainDiagnosis;
    /**
     * The deceaseAddress
     * Meta informations extracted from the WSDL
     * - documentation : Адрес места смерти
     * - minOccurs : 0
     * @var MyMPIStructAddress
     */
    public $deceaseAddress;
    /**
     * The deceaseDate
     * Meta informations extracted from the WSDL
     * - documentation : Дата смерти
     * - minOccurs : 0
     * @var date
     */
    public $deceaseDate;
    /**
     * Constructor method for Decease
     * @see parent::__construct()
     * @param string $_extId
     * @param string $_encounterCode
     * @param MyMPIStructEmployee $_enteredBy
     * @param dateTime $_enteredOn
     * @param string $_certificateSeries
     * @param string $_certificateNumber
     * @param date $_certificateDateOfIssue
     * @param MyMPIStructCodeAndName $_certificateFacility
     * @param MyMPIStructCodeAndName $_certificateType
     * @param MyMPIStructEmployee $_certificateFilledBy
     * @param MyMPIStructCodeAndName $_placeOfDeath
     * @param MyMPIStructCodeAndName $_causedBy
     * @param time $_timeOfDeath
     * @param string $_firstPathologicDuration
     * @param string $_secondPathologicDuration
     * @param string $_thirdPathologicDuration
     * @param string $_fourthPathologicDuration
     * @param MyMPIStructCodeAndName $_deceaseFacility
     * @param MyMPIStructCodeAndName $_mainDiagnosis
     * @param MyMPIStructAddress $_deceaseAddress
     * @param date $_deceaseDate
     * @return MyMPIStructDecease
     */
    public function __construct($_extId = NULL,$_encounterCode = NULL,$_enteredBy = NULL,$_enteredOn = NULL,$_certificateSeries = NULL,$_certificateNumber = NULL,$_certificateDateOfIssue = NULL,$_certificateFacility = NULL,$_certificateType = NULL,$_certificateFilledBy = NULL,$_placeOfDeath = NULL,$_causedBy = NULL,$_timeOfDeath = NULL,$_firstPathologicDuration = NULL,$_secondPathologicDuration = NULL,$_thirdPathologicDuration = NULL,$_fourthPathologicDuration = NULL,$_deceaseFacility = NULL,$_mainDiagnosis = NULL,$_deceaseAddress = NULL,$_deceaseDate = NULL)
    {
        parent::__construct(array('extId'=>$_extId,'encounterCode'=>$_encounterCode,'enteredBy'=>$_enteredBy,'enteredOn'=>$_enteredOn,'certificateSeries'=>$_certificateSeries,'certificateNumber'=>$_certificateNumber,'certificateDateOfIssue'=>$_certificateDateOfIssue,'certificateFacility'=>$_certificateFacility,'certificateType'=>$_certificateType,'certificateFilledBy'=>$_certificateFilledBy,'placeOfDeath'=>$_placeOfDeath,'causedBy'=>$_causedBy,'timeOfDeath'=>$_timeOfDeath,'firstPathologicDuration'=>$_firstPathologicDuration,'secondPathologicDuration'=>$_secondPathologicDuration,'thirdPathologicDuration'=>$_thirdPathologicDuration,'fourthPathologicDuration'=>$_fourthPathologicDuration,'deceaseFacility'=>$_deceaseFacility,'mainDiagnosis'=>$_mainDiagnosis,'deceaseAddress'=>$_deceaseAddress,'deceaseDate'=>$_deceaseDate),false);
    }
    /**
     * Get extId value
     * @return string|null
     */
    public function getExtId()
    {
        return $this->extId;
    }
    /**
     * Set extId value
     * @param string $_extId the extId
     * @return string
     */
    public function setExtId($_extId)
    {
        return ($this->extId = $_extId);
    }
    /**
     * Get encounterCode value
     * @return string|null
     */
    public function getEncounterCode()
    {
        return $this->encounterCode;
    }
    /**
     * Set encounterCode value
     * @param string $_encounterCode the encounterCode
     * @return string
     */
    public function setEncounterCode($_encounterCode)
    {
        return ($this->encounterCode = $_encounterCode);
    }
    /**
     * Get enteredBy value
     * @return MyMPIStructEmployee|null
     */
    public function getEnteredBy()
    {
        return $this->enteredBy;
    }
    /**
     * Set enteredBy value
     * @param MyMPIStructEmployee $_enteredBy the enteredBy
     * @return MyMPIStructEmployee
     */
    public function setEnteredBy($_enteredBy)
    {
        return ($this->enteredBy = $_enteredBy);
    }
    /**
     * Get enteredOn value
     * @return dateTime|null
     */
    public function getEnteredOn()
    {
        return $this->enteredOn;
    }
    /**
     * Set enteredOn value
     * @param dateTime $_enteredOn the enteredOn
     * @return dateTime
     */
    public function setEnteredOn($_enteredOn)
    {
        return ($this->enteredOn = $_enteredOn);
    }
    /**
     * Get certificateSeries value
     * @return string|null
     */
    public function getCertificateSeries()
    {
        return $this->certificateSeries;
    }
    /**
     * Set certificateSeries value
     * @param string $_certificateSeries the certificateSeries
     * @return string
     */
    public function setCertificateSeries($_certificateSeries)
    {
        return ($this->certificateSeries = $_certificateSeries);
    }
    /**
     * Get certificateNumber value
     * @return string|null
     */
    public function getCertificateNumber()
    {
        return $this->certificateNumber;
    }
    /**
     * Set certificateNumber value
     * @param string $_certificateNumber the certificateNumber
     * @return string
     */
    public function setCertificateNumber($_certificateNumber)
    {
        return ($this->certificateNumber = $_certificateNumber);
    }
    /**
     * Get certificateDateOfIssue value
     * @return date|null
     */
    public function getCertificateDateOfIssue()
    {
        return $this->certificateDateOfIssue;
    }
    /**
     * Set certificateDateOfIssue value
     * @param date $_certificateDateOfIssue the certificateDateOfIssue
     * @return date
     */
    public function setCertificateDateOfIssue($_certificateDateOfIssue)
    {
        return ($this->certificateDateOfIssue = $_certificateDateOfIssue);
    }
    /**
     * Get certificateFacility value
     * @return MyMPIStructCodeAndName|null
     */
    public function getCertificateFacility()
    {
        return $this->certificateFacility;
    }
    /**
     * Set certificateFacility value
     * @param MyMPIStructCodeAndName $_certificateFacility the certificateFacility
     * @return MyMPIStructCodeAndName
     */
    public function setCertificateFacility($_certificateFacility)
    {
        return ($this->certificateFacility = $_certificateFacility);
    }
    /**
     * Get certificateType value
     * @return MyMPIStructCodeAndName|null
     */
    public function getCertificateType()
    {
        return $this->certificateType;
    }
    /**
     * Set certificateType value
     * @param MyMPIStructCodeAndName $_certificateType the certificateType
     * @return MyMPIStructCodeAndName
     */
    public function setCertificateType($_certificateType)
    {
        return ($this->certificateType = $_certificateType);
    }
    /**
     * Get certificateFilledBy value
     * @return MyMPIStructEmployee|null
     */
    public function getCertificateFilledBy()
    {
        return $this->certificateFilledBy;
    }
    /**
     * Set certificateFilledBy value
     * @param MyMPIStructEmployee $_certificateFilledBy the certificateFilledBy
     * @return MyMPIStructEmployee
     */
    public function setCertificateFilledBy($_certificateFilledBy)
    {
        return ($this->certificateFilledBy = $_certificateFilledBy);
    }
    /**
     * Get placeOfDeath value
     * @return MyMPIStructCodeAndName|null
     */
    public function getPlaceOfDeath()
    {
        return $this->placeOfDeath;
    }
    /**
     * Set placeOfDeath value
     * @param MyMPIStructCodeAndName $_placeOfDeath the placeOfDeath
     * @return MyMPIStructCodeAndName
     */
    public function setPlaceOfDeath($_placeOfDeath)
    {
        return ($this->placeOfDeath = $_placeOfDeath);
    }
    /**
     * Get causedBy value
     * @return MyMPIStructCodeAndName|null
     */
    public function getCausedBy()
    {
        return $this->causedBy;
    }
    /**
     * Set causedBy value
     * @param MyMPIStructCodeAndName $_causedBy the causedBy
     * @return MyMPIStructCodeAndName
     */
    public function setCausedBy($_causedBy)
    {
        return ($this->causedBy = $_causedBy);
    }
    /**
     * Get timeOfDeath value
     * @return time|null
     */
    public function getTimeOfDeath()
    {
        return $this->timeOfDeath;
    }
    /**
     * Set timeOfDeath value
     * @param time $_timeOfDeath the timeOfDeath
     * @return time
     */
    public function setTimeOfDeath($_timeOfDeath)
    {
        return ($this->timeOfDeath = $_timeOfDeath);
    }
    /**
     * Get firstPathologicDuration value
     * @return string|null
     */
    public function getFirstPathologicDuration()
    {
        return $this->firstPathologicDuration;
    }
    /**
     * Set firstPathologicDuration value
     * @param string $_firstPathologicDuration the firstPathologicDuration
     * @return string
     */
    public function setFirstPathologicDuration($_firstPathologicDuration)
    {
        return ($this->firstPathologicDuration = $_firstPathologicDuration);
    }
    /**
     * Get secondPathologicDuration value
     * @return string|null
     */
    public function getSecondPathologicDuration()
    {
        return $this->secondPathologicDuration;
    }
    /**
     * Set secondPathologicDuration value
     * @param string $_secondPathologicDuration the secondPathologicDuration
     * @return string
     */
    public function setSecondPathologicDuration($_secondPathologicDuration)
    {
        return ($this->secondPathologicDuration = $_secondPathologicDuration);
    }
    /**
     * Get thirdPathologicDuration value
     * @return string|null
     */
    public function getThirdPathologicDuration()
    {
        return $this->thirdPathologicDuration;
    }
    /**
     * Set thirdPathologicDuration value
     * @param string $_thirdPathologicDuration the thirdPathologicDuration
     * @return string
     */
    public function setThirdPathologicDuration($_thirdPathologicDuration)
    {
        return ($this->thirdPathologicDuration = $_thirdPathologicDuration);
    }
    /**
     * Get fourthPathologicDuration value
     * @return string|null
     */
    public function getFourthPathologicDuration()
    {
        return $this->fourthPathologicDuration;
    }
    /**
     * Set fourthPathologicDuration value
     * @param string $_fourthPathologicDuration the fourthPathologicDuration
     * @return string
     */
    public function setFourthPathologicDuration($_fourthPathologicDuration)
    {
        return ($this->fourthPathologicDuration = $_fourthPathologicDuration);
    }
    /**
     * Get deceaseFacility value
     * @return MyMPIStructCodeAndName|null
     */
    public function getDeceaseFacility()
    {
        return $this->deceaseFacility;
    }
    /**
     * Set deceaseFacility value
     * @param MyMPIStructCodeAndName $_deceaseFacility the deceaseFacility
     * @return MyMPIStructCodeAndName
     */
    public function setDeceaseFacility($_deceaseFacility)
    {
        return ($this->deceaseFacility = $_deceaseFacility);
    }
    /**
     * Get mainDiagnosis value
     * @return MyMPIStructCodeAndName|null
     */
    public function getMainDiagnosis()
    {
        return $this->mainDiagnosis;
    }
    /**
     * Set mainDiagnosis value
     * @param MyMPIStructCodeAndName $_mainDiagnosis the mainDiagnosis
     * @return MyMPIStructCodeAndName
     */
    public function setMainDiagnosis($_mainDiagnosis)
    {
        return ($this->mainDiagnosis = $_mainDiagnosis);
    }
    /**
     * Get deceaseAddress value
     * @return MyMPIStructAddress|null
     */
    public function getDeceaseAddress()
    {
        return $this->deceaseAddress;
    }
    /**
     * Set deceaseAddress value
     * @param MyMPIStructAddress $_deceaseAddress the deceaseAddress
     * @return MyMPIStructAddress
     */
    public function setDeceaseAddress($_deceaseAddress)
    {
        return ($this->deceaseAddress = $_deceaseAddress);
    }
    /**
     * Get deceaseDate value
     * @return date|null
     */
    public function getDeceaseDate()
    {
        return $this->deceaseDate;
    }
    /**
     * Set deceaseDate value
     * @param date $_deceaseDate the deceaseDate
     * @return date
     */
    public function setDeceaseDate($_deceaseDate)
    {
        return ($this->deceaseDate = $_deceaseDate);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructDecease
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
