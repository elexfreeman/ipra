<?php
/**
 * File for class MyMPIEnumBloodGroup
 * @package MyMPI
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIEnumBloodGroup originally named bloodGroup
 * Documentation : Группа крови
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIEnumBloodGroup extends MyMPIWsdlClass
{
    /**
     * Constant for value 1
     * @return integer 1
     */
    const VALUE_1 = 1;
    /**
     * Constant for value 2
     * @return integer 2
     */
    const VALUE_2 = 2;
    /**
     * Constant for value 3
     * @return integer 3
     */
    const VALUE_3 = 3;
    /**
     * Constant for value 4
     * @return integer 4
     */
    const VALUE_4 = 4;
    /**
     * Return true if value is allowed
     * @uses MyMPIEnumBloodGroup::VALUE_1
     * @uses MyMPIEnumBloodGroup::VALUE_2
     * @uses MyMPIEnumBloodGroup::VALUE_3
     * @uses MyMPIEnumBloodGroup::VALUE_4
     * @param mixed $_value value
     * @return bool true|false
     */
    public static function valueIsValid($_value)
    {
        return in_array($_value,array(MyMPIEnumBloodGroup::VALUE_1,MyMPIEnumBloodGroup::VALUE_2,MyMPIEnumBloodGroup::VALUE_3,MyMPIEnumBloodGroup::VALUE_4));
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
