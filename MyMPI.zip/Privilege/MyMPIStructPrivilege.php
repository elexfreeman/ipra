<?php
/**
 * File for class MyMPIStructPrivilege
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructPrivilege originally named Privilege
 * Documentation : Льготы пациента
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructPrivilege extends MyMPIStructBaseSerial
{
    /**
     * The category
     * Meta informations extracted from the WSDL
     * - documentation : Код категории льготы ф 025/у-04, 025-12/у ЕГИСЗ Код: SMP369, OID: 1.2.643.5.1.13.2.1.1.358 СЭМД recordTarget/patientRole/patient/ext:patient/ext:code[@codeSystem='1.2.643.5.1.13.2.1.1.358']
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $category;
    /**
     * The document
     * Meta informations extracted from the WSDL
     * - documentation : Документ, удостоверяющий право на льготу ф 025/у-04
     * - minOccurs : 0
     * @var MyMPIStructPrivilegeDocument
     */
    public $document;
    /**
     * The startDate
     * Meta informations extracted from the WSDL
     * - documentation : Дата начала действия льготы
     * - minOccurs : 0
     * @var date
     */
    public $startDate;
    /**
     * The expirationDate
     * Meta informations extracted from the WSDL
     * - documentation : Дата истечения действия льготы
     * - minOccurs : 0
     * @var date
     */
    public $expirationDate;
    /**
     * The isMain
     * Meta informations extracted from the WSDL
     * - documentation : Признак основной льготы
     * - minOccurs : 0
     * @var boolean
     */
    public $isMain;
    /**
     * The diagnosis
     * Meta informations extracted from the WSDL
     * - documentation : Диагноз (код МКБ-10 и расшифровка) ЕГИСЗ - 1.2.643.5.1.13.2.1.1.641 (MKB308) - Международная классификация болезней и состояний, связанных со здоровьем, Десятого пересмотра. Версия 2
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $diagnosis;
    /**
     * The enteredBy
     * Meta informations extracted from the WSDL
     * - documentation : Автор записи (Врач, установивший льготу) ТФОМС: IDDOKT (региональный справочник), PRVS (V004) - специальность
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $enteredBy;
    /**
     * The privelegeCause
     * Meta informations extracted from the WSDL
     * - documentation : Причина установки
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $privelegeCause;
    /**
     * The cancelReason
     * Meta informations extracted from the WSDL
     * - documentation : Причина снятия
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $cancelReason;
    /**
     * The financeLevel
     * Meta informations extracted from the WSDL
     * - documentation : Уровень финансирования OID: 1.2.643.5.1.13.2.1.1.76
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $financeLevel;
    /**
     * Constructor method for Privilege
     * @see parent::__construct()
     * @param MyMPIStructCodeAndName $_category
     * @param MyMPIStructPrivilegeDocument $_document
     * @param date $_startDate
     * @param date $_expirationDate
     * @param boolean $_isMain
     * @param MyMPIStructCodeAndName $_diagnosis
     * @param MyMPIStructEmployee $_enteredBy
     * @param string $_privelegeCause
     * @param string $_cancelReason
     * @param MyMPIStructCodeAndName $_financeLevel
     * @return MyMPIStructPrivilege
     */
    public function __construct($_category = NULL,$_document = NULL,$_startDate = NULL,$_expirationDate = NULL,$_isMain = NULL,$_diagnosis = NULL,$_enteredBy = NULL,$_privelegeCause = NULL,$_cancelReason = NULL,$_financeLevel = NULL)
    {
        MyMPIWsdlClass::__construct(array('category'=>$_category,'document'=>$_document,'startDate'=>$_startDate,'expirationDate'=>$_expirationDate,'isMain'=>$_isMain,'diagnosis'=>$_diagnosis,'enteredBy'=>$_enteredBy,'privelegeCause'=>$_privelegeCause,'cancelReason'=>$_cancelReason,'financeLevel'=>$_financeLevel),false);
    }
    /**
     * Get category value
     * @return MyMPIStructCodeAndName|null
     */
    public function getCategory()
    {
        return $this->category;
    }
    /**
     * Set category value
     * @param MyMPIStructCodeAndName $_category the category
     * @return MyMPIStructCodeAndName
     */
    public function setCategory($_category)
    {
        return ($this->category = $_category);
    }
    /**
     * Get document value
     * @return MyMPIStructPrivilegeDocument|null
     */
    public function getDocument()
    {
        return $this->document;
    }
    /**
     * Set document value
     * @param MyMPIStructPrivilegeDocument $_document the document
     * @return MyMPIStructPrivilegeDocument
     */
    public function setDocument($_document)
    {
        return ($this->document = $_document);
    }
    /**
     * Get startDate value
     * @return date|null
     */
    public function getStartDate()
    {
        return $this->startDate;
    }
    /**
     * Set startDate value
     * @param date $_startDate the startDate
     * @return date
     */
    public function setStartDate($_startDate)
    {
        return ($this->startDate = $_startDate);
    }
    /**
     * Get expirationDate value
     * @return date|null
     */
    public function getExpirationDate()
    {
        return $this->expirationDate;
    }
    /**
     * Set expirationDate value
     * @param date $_expirationDate the expirationDate
     * @return date
     */
    public function setExpirationDate($_expirationDate)
    {
        return ($this->expirationDate = $_expirationDate);
    }
    /**
     * Get isMain value
     * @return boolean|null
     */
    public function getIsMain()
    {
        return $this->isMain;
    }
    /**
     * Set isMain value
     * @param boolean $_isMain the isMain
     * @return boolean
     */
    public function setIsMain($_isMain)
    {
        return ($this->isMain = $_isMain);
    }
    /**
     * Get diagnosis value
     * @return MyMPIStructCodeAndName|null
     */
    public function getDiagnosis()
    {
        return $this->diagnosis;
    }
    /**
     * Set diagnosis value
     * @param MyMPIStructCodeAndName $_diagnosis the diagnosis
     * @return MyMPIStructCodeAndName
     */
    public function setDiagnosis($_diagnosis)
    {
        return ($this->diagnosis = $_diagnosis);
    }
    /**
     * Get enteredBy value
     * @return MyMPIStructEmployee|null
     */
    public function getEnteredBy()
    {
        return $this->enteredBy;
    }
    /**
     * Set enteredBy value
     * @param MyMPIStructEmployee $_enteredBy the enteredBy
     * @return MyMPIStructEmployee
     */
    public function setEnteredBy($_enteredBy)
    {
        return ($this->enteredBy = $_enteredBy);
    }
    /**
     * Get privelegeCause value
     * @return string|null
     */
    public function getPrivelegeCause()
    {
        return $this->privelegeCause;
    }
    /**
     * Set privelegeCause value
     * @param string $_privelegeCause the privelegeCause
     * @return string
     */
    public function setPrivelegeCause($_privelegeCause)
    {
        return ($this->privelegeCause = $_privelegeCause);
    }
    /**
     * Get cancelReason value
     * @return string|null
     */
    public function getCancelReason()
    {
        return $this->cancelReason;
    }
    /**
     * Set cancelReason value
     * @param string $_cancelReason the cancelReason
     * @return string
     */
    public function setCancelReason($_cancelReason)
    {
        return ($this->cancelReason = $_cancelReason);
    }
    /**
     * Get financeLevel value
     * @return MyMPIStructCodeAndName|null
     */
    public function getFinanceLevel()
    {
        return $this->financeLevel;
    }
    /**
     * Set financeLevel value
     * @param MyMPIStructCodeAndName $_financeLevel the financeLevel
     * @return MyMPIStructCodeAndName
     */
    public function setFinanceLevel($_financeLevel)
    {
        return ($this->financeLevel = $_financeLevel);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructPrivilege
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
