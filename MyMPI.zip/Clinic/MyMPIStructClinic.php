<?php
/**
 * File for class MyMPIStructClinic
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructClinic originally named Clinic
 * Documentation : Справочник ЛПУ
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructClinic extends MyMPIWsdlClass
{
    /**
     * The id
     * Meta informations extracted from the WSDL
     * - documentation : Код ЛПУ
     * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
     * - minInclusive : 1
     * @var long
     */
    public $id;
    /**
     * The name
     * Meta informations extracted from the WSDL
     * - documentation : Название ЛПУ
     * - minLength : 1
     * @var string
     */
    public $name;
    /**
     * The region
     * Meta informations extracted from the WSDL
     * - documentation : Территория
     * @var string
     */
    public $region;
    /**
     * The addressLine
     * Meta informations extracted from the WSDL
     * - documentation : Адрес ЛПУ одной строкой
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $addressLine;
    /**
     * The oid
     * Meta informations extracted from the WSDL
     * - documentation : OID по справочнику 1.2.643.5.1.13.2.1.1.178 (MDR308)
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $oid;
    /**
     * The shortName
     * Meta informations extracted from the WSDL
     * - documentation : Краткое название ЛПУ
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $shortName;
    /**
     * The ogrn
     * Meta informations extracted from the WSDL
     * - documentation : ОГРН
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $ogrn;
    /**
     * The endpointCode
     * Meta informations extracted from the WSDL
     * - documentation : Код, используемый для маршрутизации сообщений в рамках продукции Ensemble
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $endpointCode;
    /**
     * The clientEntityId
     * Meta informations extracted from the WSDL
     * - documentation : Идентификатор МИС в федеральной ИЭМК
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $clientEntityId;
    /**
     * Constructor method for Clinic
     * @see parent::__construct()
     * @param long $_id
     * @param string $_name
     * @param string $_region
     * @param string $_addressLine
     * @param string $_oid
     * @param string $_shortName
     * @param string $_ogrn
     * @param string $_endpointCode
     * @param string $_clientEntityId
     * @return MyMPIStructClinic
     */
    public function __construct($_id = NULL,$_name = NULL,$_region = NULL,$_addressLine = NULL,$_oid = NULL,$_shortName = NULL,$_ogrn = NULL,$_endpointCode = NULL,$_clientEntityId = NULL)
    {
        parent::__construct(array('id'=>$_id,'name'=>$_name,'region'=>$_region,'addressLine'=>$_addressLine,'oid'=>$_oid,'shortName'=>$_shortName,'ogrn'=>$_ogrn,'endpointCode'=>$_endpointCode,'clientEntityId'=>$_clientEntityId),false);
    }
    /**
     * Get id value
     * @return long|null
     */
    public function getId()
    {
        return $this->id;
    }
    /**
     * Set id value
     * @param long $_id the id
     * @return long
     */
    public function setId($_id)
    {
        return ($this->id = $_id);
    }
    /**
     * Get name value
     * @return string|null
     */
    public function getName()
    {
        return $this->name;
    }
    /**
     * Set name value
     * @param string $_name the name
     * @return string
     */
    public function setName($_name)
    {
        return ($this->name = $_name);
    }
    /**
     * Get region value
     * @return string|null
     */
    public function getRegion()
    {
        return $this->region;
    }
    /**
     * Set region value
     * @param string $_region the region
     * @return string
     */
    public function setRegion($_region)
    {
        return ($this->region = $_region);
    }
    /**
     * Get addressLine value
     * @return string|null
     */
    public function getAddressLine()
    {
        return $this->addressLine;
    }
    /**
     * Set addressLine value
     * @param string $_addressLine the addressLine
     * @return string
     */
    public function setAddressLine($_addressLine)
    {
        return ($this->addressLine = $_addressLine);
    }
    /**
     * Get oid value
     * @return string|null
     */
    public function getOid()
    {
        return $this->oid;
    }
    /**
     * Set oid value
     * @param string $_oid the oid
     * @return string
     */
    public function setOid($_oid)
    {
        return ($this->oid = $_oid);
    }
    /**
     * Get shortName value
     * @return string|null
     */
    public function getShortName()
    {
        return $this->shortName;
    }
    /**
     * Set shortName value
     * @param string $_shortName the shortName
     * @return string
     */
    public function setShortName($_shortName)
    {
        return ($this->shortName = $_shortName);
    }
    /**
     * Get ogrn value
     * @return string|null
     */
    public function getOgrn()
    {
        return $this->ogrn;
    }
    /**
     * Set ogrn value
     * @param string $_ogrn the ogrn
     * @return string
     */
    public function setOgrn($_ogrn)
    {
        return ($this->ogrn = $_ogrn);
    }
    /**
     * Get endpointCode value
     * @return string|null
     */
    public function getEndpointCode()
    {
        return $this->endpointCode;
    }
    /**
     * Set endpointCode value
     * @param string $_endpointCode the endpointCode
     * @return string
     */
    public function setEndpointCode($_endpointCode)
    {
        return ($this->endpointCode = $_endpointCode);
    }
    /**
     * Get clientEntityId value
     * @return string|null
     */
    public function getClientEntityId()
    {
        return $this->clientEntityId;
    }
    /**
     * Set clientEntityId value
     * @param string $_clientEntityId the clientEntityId
     * @return string
     */
    public function setClientEntityId($_clientEntityId)
    {
        return ($this->clientEntityId = $_clientEntityId);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructClinic
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
