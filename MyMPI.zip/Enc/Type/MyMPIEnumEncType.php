<?php
/**
 * File for class MyMPIEnumEncType
 * @package MyMPI
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIEnumEncType originally named encType
 * Documentation : Тип эпизода (амбулаторный=O/стационар=I) СЭМД componentOf/encompassingEncounter/code/@code, амбулаторный=AMB/стационар=STAT, codeSystem="1.2.643.5.1.13.2.7.1.1"
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Enumerations
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIEnumEncType extends MyMPIWsdlClass
{
    /**
     * Constant for value 'I'
     * @return string 'I'
     */
    const VALUE_I = 'I';
    /**
     * Constant for value 'O'
     * @return string 'O'
     */
    const VALUE_O = 'O';
    /**
     * Constant for value 'E'
     * @return string 'E'
     */
    const VALUE_E = 'E';
    /**
     * Return true if value is allowed
     * @uses MyMPIEnumEncType::VALUE_I
     * @uses MyMPIEnumEncType::VALUE_O
     * @uses MyMPIEnumEncType::VALUE_E
     * @param mixed $_value value
     * @return bool true|false
     */
    public static function valueIsValid($_value)
    {
        return in_array($_value,array(MyMPIEnumEncType::VALUE_I,MyMPIEnumEncType::VALUE_O,MyMPIEnumEncType::VALUE_E));
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
