<?php
/**
 * Test with MyMPI for 'var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml'
 * @package MyMPI
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
ini_set('memory_limit','512M');
ini_set('display_errors',true);
error_reporting(-1);
/**
 * Load autoload
 */
require_once dirname(__FILE__) . '/MyMPIAutoload.php';
/**
 * Wsdl instanciation infos. By default, nothing has to be set.
 * If you wish to override the SoapClient's options, please refer to the sample below.
 * 
 * This is an associative array as:
 * - the key must be a MyMPIWsdlClass constant beginning with WSDL_
 * - the value must be the corresponding key value
 * Each option matches the {@link http://www.php.net/manual/en/soapclient.soapclient.php} options
 * 
 * Here is below an example of how you can set the array:
 * $wsdl = array();
 * $wsdl[MyMPIWsdlClass::WSDL_URL] = 'var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml';
 * $wsdl[MyMPIWsdlClass::WSDL_CACHE_WSDL] = WSDL_CACHE_NONE;
 * $wsdl[MyMPIWsdlClass::WSDL_TRACE] = true;
 * $wsdl[MyMPIWsdlClass::WSDL_LOGIN] = 'myLogin';
 * $wsdl[MyMPIWsdlClass::WSDL_PASSWD] = '**********';
 * etc....
 * Then instantiate the Service class as: 
 * - $wsdlObject = new MyMPIWsdlClass($wsdl);
 */
/**
 * Examples
 */


/***********************************
 * Example for MyMPIServiceContainer
 */
$myMPIServiceContainer = new MyMPIServiceContainer();
// sample call for MyMPIServiceContainer::container()
if($myMPIServiceContainer->container(new MyMPIStructContainer(/*** update parameters list ***/)))
    print_r($myMPIServiceContainer->getResult());
else
    print_r($myMPIServiceContainer->getLastError());
