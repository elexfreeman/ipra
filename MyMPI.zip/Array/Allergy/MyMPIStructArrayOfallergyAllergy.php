<?php
/**
 * File for class MyMPIStructArrayOfallergyAllergy
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructArrayOfallergyAllergy originally named ArrayOfallergyAllergy
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructArrayOfallergyAllergy extends MyMPIWsdlClass
{
    /**
     * The allergy
     * Meta informations extracted from the WSDL
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * - nillable : true
     * @var MyMPIStructAllergy
     */
    public $allergy;
    /**
     * Constructor method for ArrayOfallergyAllergy
     * @see parent::__construct()
     * @param MyMPIStructAllergy $_allergy
     * @return MyMPIStructArrayOfallergyAllergy
     */
    public function __construct($_allergy = NULL)
    {
        parent::__construct(array('allergy'=>$_allergy),false);
    }
    /**
     * Get allergy value
     * @return MyMPIStructAllergy|null
     */
    public function getAllergy()
    {
        return $this->allergy;
    }
    /**
     * Set allergy value
     * @param MyMPIStructAllergy $_allergy the allergy
     * @return MyMPIStructAllergy
     */
    public function setAllergy($_allergy)
    {
        return ($this->allergy = $_allergy);
    }
    /**
     * Returns the current element
     * @see MyMPIWsdlClass::current()
     * @return MyMPIStructAllergy
     */
    public function current()
    {
        return parent::current();
    }
    /**
     * Returns the indexed element
     * @see MyMPIWsdlClass::item()
     * @param int $_index
     * @return MyMPIStructAllergy
     */
    public function item($_index)
    {
        return parent::item($_index);
    }
    /**
     * Returns the first element
     * @see MyMPIWsdlClass::first()
     * @return MyMPIStructAllergy
     */
    public function first()
    {
        return parent::first();
    }
    /**
     * Returns the last element
     * @see MyMPIWsdlClass::last()
     * @return MyMPIStructAllergy
     */
    public function last()
    {
        return parent::last();
    }
    /**
     * Returns the element at the offset
     * @see MyMPIWsdlClass::last()
     * @param int $_offset
     * @return MyMPIStructAllergy
     */
    public function offsetGet($_offset)
    {
        return parent::offsetGet($_offset);
    }
    /**
     * Returns the attribute name
     * @see MyMPIWsdlClass::getAttributeName()
     * @return string allergy
     */
    public function getAttributeName()
    {
        return 'allergy';
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructArrayOfallergyAllergy
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
