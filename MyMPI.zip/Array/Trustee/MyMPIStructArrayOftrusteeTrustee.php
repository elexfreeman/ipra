<?php
/**
 * File for class MyMPIStructArrayOftrusteeTrustee
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructArrayOftrusteeTrustee originally named ArrayOftrusteeTrustee
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructArrayOftrusteeTrustee extends MyMPIWsdlClass
{
    /**
     * The trustee
     * Meta informations extracted from the WSDL
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * - nillable : true
     * @var MyMPIStructTrustee
     */
    public $trustee;
    /**
     * Constructor method for ArrayOftrusteeTrustee
     * @see parent::__construct()
     * @param MyMPIStructTrustee $_trustee
     * @return MyMPIStructArrayOftrusteeTrustee
     */
    public function __construct($_trustee = NULL)
    {
        parent::__construct(array('trustee'=>$_trustee),false);
    }
    /**
     * Get trustee value
     * @return MyMPIStructTrustee|null
     */
    public function getTrustee()
    {
        return $this->trustee;
    }
    /**
     * Set trustee value
     * @param MyMPIStructTrustee $_trustee the trustee
     * @return MyMPIStructTrustee
     */
    public function setTrustee($_trustee)
    {
        return ($this->trustee = $_trustee);
    }
    /**
     * Returns the current element
     * @see MyMPIWsdlClass::current()
     * @return MyMPIStructTrustee
     */
    public function current()
    {
        return parent::current();
    }
    /**
     * Returns the indexed element
     * @see MyMPIWsdlClass::item()
     * @param int $_index
     * @return MyMPIStructTrustee
     */
    public function item($_index)
    {
        return parent::item($_index);
    }
    /**
     * Returns the first element
     * @see MyMPIWsdlClass::first()
     * @return MyMPIStructTrustee
     */
    public function first()
    {
        return parent::first();
    }
    /**
     * Returns the last element
     * @see MyMPIWsdlClass::last()
     * @return MyMPIStructTrustee
     */
    public function last()
    {
        return parent::last();
    }
    /**
     * Returns the element at the offset
     * @see MyMPIWsdlClass::last()
     * @param int $_offset
     * @return MyMPIStructTrustee
     */
    public function offsetGet($_offset)
    {
        return parent::offsetGet($_offset);
    }
    /**
     * Returns the attribute name
     * @see MyMPIWsdlClass::getAttributeName()
     * @return string trustee
     */
    public function getAttributeName()
    {
        return 'trustee';
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructArrayOftrusteeTrustee
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
