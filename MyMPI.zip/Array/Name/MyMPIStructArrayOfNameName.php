<?php
/**
 * File for class MyMPIStructArrayOfNameName
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructArrayOfNameName originally named ArrayOfNameName
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructArrayOfNameName extends MyMPIWsdlClass
{
    /**
     * The Name
     * Meta informations extracted from the WSDL
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * - nillable : true
     * @var MyMPIStructName
     */
    public $Name;
    /**
     * Constructor method for ArrayOfNameName
     * @see parent::__construct()
     * @param MyMPIStructName $_name
     * @return MyMPIStructArrayOfNameName
     */
    public function __construct($_name = NULL)
    {
        parent::__construct(array('Name'=>$_name),false);
    }
    /**
     * Get Name value
     * @return MyMPIStructName|null
     */
    public function getName()
    {
        return $this->Name;
    }
    /**
     * Set Name value
     * @param MyMPIStructName $_name the Name
     * @return MyMPIStructName
     */
    public function setName($_name)
    {
        return ($this->Name = $_name);
    }
    /**
     * Returns the current element
     * @see MyMPIWsdlClass::current()
     * @return MyMPIStructName
     */
    public function current()
    {
        return parent::current();
    }
    /**
     * Returns the indexed element
     * @see MyMPIWsdlClass::item()
     * @param int $_index
     * @return MyMPIStructName
     */
    public function item($_index)
    {
        return parent::item($_index);
    }
    /**
     * Returns the first element
     * @see MyMPIWsdlClass::first()
     * @return MyMPIStructName
     */
    public function first()
    {
        return parent::first();
    }
    /**
     * Returns the last element
     * @see MyMPIWsdlClass::last()
     * @return MyMPIStructName
     */
    public function last()
    {
        return parent::last();
    }
    /**
     * Returns the element at the offset
     * @see MyMPIWsdlClass::last()
     * @param int $_offset
     * @return MyMPIStructName
     */
    public function offsetGet($_offset)
    {
        return parent::offsetGet($_offset);
    }
    /**
     * Returns the attribute name
     * @see MyMPIWsdlClass::getAttributeName()
     * @return string Name
     */
    public function getAttributeName()
    {
        return 'Name';
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructArrayOfNameName
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
