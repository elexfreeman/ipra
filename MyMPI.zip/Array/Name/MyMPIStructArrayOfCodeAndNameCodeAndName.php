<?php
/**
 * File for class MyMPIStructArrayOfCodeAndNameCodeAndName
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructArrayOfCodeAndNameCodeAndName originally named ArrayOfCodeAndNameCodeAndName
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructArrayOfCodeAndNameCodeAndName extends MyMPIWsdlClass
{
    /**
     * The CodeAndName
     * Meta informations extracted from the WSDL
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * - nillable : true
     * @var MyMPIStructCodeAndName
     */
    public $CodeAndName;
    /**
     * Constructor method for ArrayOfCodeAndNameCodeAndName
     * @see parent::__construct()
     * @param MyMPIStructCodeAndName $_codeAndName
     * @return MyMPIStructArrayOfCodeAndNameCodeAndName
     */
    public function __construct($_codeAndName = NULL)
    {
        parent::__construct(array('CodeAndName'=>$_codeAndName),false);
    }
    /**
     * Get CodeAndName value
     * @return MyMPIStructCodeAndName|null
     */
    public function getCodeAndName()
    {
        return $this->CodeAndName;
    }
    /**
     * Set CodeAndName value
     * @param MyMPIStructCodeAndName $_codeAndName the CodeAndName
     * @return MyMPIStructCodeAndName
     */
    public function setCodeAndName($_codeAndName)
    {
        return ($this->CodeAndName = $_codeAndName);
    }
    /**
     * Returns the current element
     * @see MyMPIWsdlClass::current()
     * @return MyMPIStructCodeAndName
     */
    public function current()
    {
        return parent::current();
    }
    /**
     * Returns the indexed element
     * @see MyMPIWsdlClass::item()
     * @param int $_index
     * @return MyMPIStructCodeAndName
     */
    public function item($_index)
    {
        return parent::item($_index);
    }
    /**
     * Returns the first element
     * @see MyMPIWsdlClass::first()
     * @return MyMPIStructCodeAndName
     */
    public function first()
    {
        return parent::first();
    }
    /**
     * Returns the last element
     * @see MyMPIWsdlClass::last()
     * @return MyMPIStructCodeAndName
     */
    public function last()
    {
        return parent::last();
    }
    /**
     * Returns the element at the offset
     * @see MyMPIWsdlClass::last()
     * @param int $_offset
     * @return MyMPIStructCodeAndName
     */
    public function offsetGet($_offset)
    {
        return parent::offsetGet($_offset);
    }
    /**
     * Returns the attribute name
     * @see MyMPIWsdlClass::getAttributeName()
     * @return string CodeAndName
     */
    public function getAttributeName()
    {
        return 'CodeAndName';
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructArrayOfCodeAndNameCodeAndName
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
