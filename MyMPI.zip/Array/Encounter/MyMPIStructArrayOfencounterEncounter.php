<?php
/**
 * File for class MyMPIStructArrayOfencounterEncounter
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructArrayOfencounterEncounter originally named ArrayOfencounterEncounter
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructArrayOfencounterEncounter extends MyMPIWsdlClass
{
    /**
     * The encounter
     * Meta informations extracted from the WSDL
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * - nillable : true
     * @var MyMPIStructEncounter
     */
    public $encounter;
    /**
     * Constructor method for ArrayOfencounterEncounter
     * @see parent::__construct()
     * @param MyMPIStructEncounter $_encounter
     * @return MyMPIStructArrayOfencounterEncounter
     */
    public function __construct($_encounter = NULL)
    {
        parent::__construct(array('encounter'=>$_encounter),false);
    }
    /**
     * Get encounter value
     * @return MyMPIStructEncounter|null
     */
    public function getEncounter()
    {
        return $this->encounter;
    }
    /**
     * Set encounter value
     * @param MyMPIStructEncounter $_encounter the encounter
     * @return MyMPIStructEncounter
     */
    public function setEncounter($_encounter)
    {
        return ($this->encounter = $_encounter);
    }
    /**
     * Returns the current element
     * @see MyMPIWsdlClass::current()
     * @return MyMPIStructEncounter
     */
    public function current()
    {
        return parent::current();
    }
    /**
     * Returns the indexed element
     * @see MyMPIWsdlClass::item()
     * @param int $_index
     * @return MyMPIStructEncounter
     */
    public function item($_index)
    {
        return parent::item($_index);
    }
    /**
     * Returns the first element
     * @see MyMPIWsdlClass::first()
     * @return MyMPIStructEncounter
     */
    public function first()
    {
        return parent::first();
    }
    /**
     * Returns the last element
     * @see MyMPIWsdlClass::last()
     * @return MyMPIStructEncounter
     */
    public function last()
    {
        return parent::last();
    }
    /**
     * Returns the element at the offset
     * @see MyMPIWsdlClass::last()
     * @param int $_offset
     * @return MyMPIStructEncounter
     */
    public function offsetGet($_offset)
    {
        return parent::offsetGet($_offset);
    }
    /**
     * Returns the attribute name
     * @see MyMPIWsdlClass::getAttributeName()
     * @return string encounter
     */
    public function getAttributeName()
    {
        return 'encounter';
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructArrayOfencounterEncounter
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
