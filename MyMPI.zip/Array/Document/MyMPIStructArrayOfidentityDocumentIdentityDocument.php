<?php
/**
 * File for class MyMPIStructArrayOfidentityDocumentIdentityDocument
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructArrayOfidentityDocumentIdentityDocument originally named ArrayOfidentityDocumentIdentityDocument
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructArrayOfidentityDocumentIdentityDocument extends MyMPIWsdlClass
{
    /**
     * The identityDocument
     * Meta informations extracted from the WSDL
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * - nillable : true
     * @var MyMPIStructIdentityDocument
     */
    public $identityDocument;
    /**
     * Constructor method for ArrayOfidentityDocumentIdentityDocument
     * @see parent::__construct()
     * @param MyMPIStructIdentityDocument $_identityDocument
     * @return MyMPIStructArrayOfidentityDocumentIdentityDocument
     */
    public function __construct($_identityDocument = NULL)
    {
        parent::__construct(array('identityDocument'=>$_identityDocument),false);
    }
    /**
     * Get identityDocument value
     * @return MyMPIStructIdentityDocument|null
     */
    public function getIdentityDocument()
    {
        return $this->identityDocument;
    }
    /**
     * Set identityDocument value
     * @param MyMPIStructIdentityDocument $_identityDocument the identityDocument
     * @return MyMPIStructIdentityDocument
     */
    public function setIdentityDocument($_identityDocument)
    {
        return ($this->identityDocument = $_identityDocument);
    }
    /**
     * Returns the current element
     * @see MyMPIWsdlClass::current()
     * @return MyMPIStructIdentityDocument
     */
    public function current()
    {
        return parent::current();
    }
    /**
     * Returns the indexed element
     * @see MyMPIWsdlClass::item()
     * @param int $_index
     * @return MyMPIStructIdentityDocument
     */
    public function item($_index)
    {
        return parent::item($_index);
    }
    /**
     * Returns the first element
     * @see MyMPIWsdlClass::first()
     * @return MyMPIStructIdentityDocument
     */
    public function first()
    {
        return parent::first();
    }
    /**
     * Returns the last element
     * @see MyMPIWsdlClass::last()
     * @return MyMPIStructIdentityDocument
     */
    public function last()
    {
        return parent::last();
    }
    /**
     * Returns the element at the offset
     * @see MyMPIWsdlClass::last()
     * @param int $_offset
     * @return MyMPIStructIdentityDocument
     */
    public function offsetGet($_offset)
    {
        return parent::offsetGet($_offset);
    }
    /**
     * Returns the attribute name
     * @see MyMPIWsdlClass::getAttributeName()
     * @return string identityDocument
     */
    public function getAttributeName()
    {
        return 'identityDocument';
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructArrayOfidentityDocumentIdentityDocument
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
