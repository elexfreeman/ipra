<?php
/**
 * File for class MyMPIStructArrayOfsickLeaveDocumentSickLeaveDocument
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructArrayOfsickLeaveDocumentSickLeaveDocument originally named ArrayOfsickLeaveDocumentSickLeaveDocument
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructArrayOfsickLeaveDocumentSickLeaveDocument extends MyMPIWsdlClass
{
    /**
     * The sickLeaveDocument
     * Meta informations extracted from the WSDL
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * - nillable : true
     * @var MyMPIStructSickLeaveDocument
     */
    public $sickLeaveDocument;
    /**
     * Constructor method for ArrayOfsickLeaveDocumentSickLeaveDocument
     * @see parent::__construct()
     * @param MyMPIStructSickLeaveDocument $_sickLeaveDocument
     * @return MyMPIStructArrayOfsickLeaveDocumentSickLeaveDocument
     */
    public function __construct($_sickLeaveDocument = NULL)
    {
        parent::__construct(array('sickLeaveDocument'=>$_sickLeaveDocument),false);
    }
    /**
     * Get sickLeaveDocument value
     * @return MyMPIStructSickLeaveDocument|null
     */
    public function getSickLeaveDocument()
    {
        return $this->sickLeaveDocument;
    }
    /**
     * Set sickLeaveDocument value
     * @param MyMPIStructSickLeaveDocument $_sickLeaveDocument the sickLeaveDocument
     * @return MyMPIStructSickLeaveDocument
     */
    public function setSickLeaveDocument($_sickLeaveDocument)
    {
        return ($this->sickLeaveDocument = $_sickLeaveDocument);
    }
    /**
     * Returns the current element
     * @see MyMPIWsdlClass::current()
     * @return MyMPIStructSickLeaveDocument
     */
    public function current()
    {
        return parent::current();
    }
    /**
     * Returns the indexed element
     * @see MyMPIWsdlClass::item()
     * @param int $_index
     * @return MyMPIStructSickLeaveDocument
     */
    public function item($_index)
    {
        return parent::item($_index);
    }
    /**
     * Returns the first element
     * @see MyMPIWsdlClass::first()
     * @return MyMPIStructSickLeaveDocument
     */
    public function first()
    {
        return parent::first();
    }
    /**
     * Returns the last element
     * @see MyMPIWsdlClass::last()
     * @return MyMPIStructSickLeaveDocument
     */
    public function last()
    {
        return parent::last();
    }
    /**
     * Returns the element at the offset
     * @see MyMPIWsdlClass::last()
     * @param int $_offset
     * @return MyMPIStructSickLeaveDocument
     */
    public function offsetGet($_offset)
    {
        return parent::offsetGet($_offset);
    }
    /**
     * Returns the attribute name
     * @see MyMPIWsdlClass::getAttributeName()
     * @return string sickLeaveDocument
     */
    public function getAttributeName()
    {
        return 'sickLeaveDocument';
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructArrayOfsickLeaveDocumentSickLeaveDocument
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
