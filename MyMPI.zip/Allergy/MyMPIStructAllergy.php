<?php
/**
 * File for class MyMPIStructAllergy
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructAllergy originally named Allergy
 * Documentation : Аллергия и лекарственная непереносимость
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructAllergy extends MyMPIWsdlClass
{
    /**
     * The extId
     * Meta informations extracted from the WSDL
     * - documentation : Идентификатор в МИС
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $extId;
    /**
     * The encounterCode
     * Meta informations extracted from the WSDL
     * - documentation : Код эпизода
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $encounterCode;
    /**
     * The enteredBy
     * Meta informations extracted from the WSDL
     * - documentation : Автор записи (врач) ТФОМС: IDDOKT (региональный справочник), PRVS (V004) - специальность
     * - minOccurs : 0
     * @var MyMPIStructEmployee
     */
    public $enteredBy;
    /**
     * The enteredOn
     * Meta informations extracted from the WSDL
     * - documentation : Дата/время ввода записи в МИС
     * - minOccurs : 0
     * @var dateTime
     */
    public $enteredOn;
    /**
     * The allergy
     * Meta informations extracted from the WSDL
     * - documentation : Аллергия/непереносимость (название препарата, шерсть животных, продукт питания, пыль, ...)
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $allergy;
    /**
     * The reaction
     * Meta informations extracted from the WSDL
     * - documentation : Тип реакции (характер побочного действия) ф 003/у
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $reaction;
    /**
     * The comments
     * Meta informations extracted from the WSDL
     * - documentation : Дополнительная информация
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $comments;
    /**
     * The onsetTime
     * Meta informations extracted from the WSDL
     * - documentation : Дата/время начала заболевания
     * - minOccurs : 0
     * @var dateTime
     */
    public $onsetTime;
    /**
     * Constructor method for Allergy
     * @see parent::__construct()
     * @param string $_extId
     * @param string $_encounterCode
     * @param MyMPIStructEmployee $_enteredBy
     * @param dateTime $_enteredOn
     * @param MyMPIStructCodeAndName $_allergy
     * @param MyMPIStructCodeAndName $_reaction
     * @param string $_comments
     * @param dateTime $_onsetTime
     * @return MyMPIStructAllergy
     */
    public function __construct($_extId = NULL,$_encounterCode = NULL,$_enteredBy = NULL,$_enteredOn = NULL,$_allergy = NULL,$_reaction = NULL,$_comments = NULL,$_onsetTime = NULL)
    {
        parent::__construct(array('extId'=>$_extId,'encounterCode'=>$_encounterCode,'enteredBy'=>$_enteredBy,'enteredOn'=>$_enteredOn,'allergy'=>$_allergy,'reaction'=>$_reaction,'comments'=>$_comments,'onsetTime'=>$_onsetTime),false);
    }
    /**
     * Get extId value
     * @return string|null
     */
    public function getExtId()
    {
        return $this->extId;
    }
    /**
     * Set extId value
     * @param string $_extId the extId
     * @return string
     */
    public function setExtId($_extId)
    {
        return ($this->extId = $_extId);
    }
    /**
     * Get encounterCode value
     * @return string|null
     */
    public function getEncounterCode()
    {
        return $this->encounterCode;
    }
    /**
     * Set encounterCode value
     * @param string $_encounterCode the encounterCode
     * @return string
     */
    public function setEncounterCode($_encounterCode)
    {
        return ($this->encounterCode = $_encounterCode);
    }
    /**
     * Get enteredBy value
     * @return MyMPIStructEmployee|null
     */
    public function getEnteredBy()
    {
        return $this->enteredBy;
    }
    /**
     * Set enteredBy value
     * @param MyMPIStructEmployee $_enteredBy the enteredBy
     * @return MyMPIStructEmployee
     */
    public function setEnteredBy($_enteredBy)
    {
        return ($this->enteredBy = $_enteredBy);
    }
    /**
     * Get enteredOn value
     * @return dateTime|null
     */
    public function getEnteredOn()
    {
        return $this->enteredOn;
    }
    /**
     * Set enteredOn value
     * @param dateTime $_enteredOn the enteredOn
     * @return dateTime
     */
    public function setEnteredOn($_enteredOn)
    {
        return ($this->enteredOn = $_enteredOn);
    }
    /**
     * Get allergy value
     * @return MyMPIStructCodeAndName|null
     */
    public function getAllergy()
    {
        return $this->allergy;
    }
    /**
     * Set allergy value
     * @param MyMPIStructCodeAndName $_allergy the allergy
     * @return MyMPIStructCodeAndName
     */
    public function setAllergy($_allergy)
    {
        return ($this->allergy = $_allergy);
    }
    /**
     * Get reaction value
     * @return MyMPIStructCodeAndName|null
     */
    public function getReaction()
    {
        return $this->reaction;
    }
    /**
     * Set reaction value
     * @param MyMPIStructCodeAndName $_reaction the reaction
     * @return MyMPIStructCodeAndName
     */
    public function setReaction($_reaction)
    {
        return ($this->reaction = $_reaction);
    }
    /**
     * Get comments value
     * @return string|null
     */
    public function getComments()
    {
        return $this->comments;
    }
    /**
     * Set comments value
     * @param string $_comments the comments
     * @return string
     */
    public function setComments($_comments)
    {
        return ($this->comments = $_comments);
    }
    /**
     * Get onsetTime value
     * @return dateTime|null
     */
    public function getOnsetTime()
    {
        return $this->onsetTime;
    }
    /**
     * Set onsetTime value
     * @param dateTime $_onsetTime the onsetTime
     * @return dateTime
     */
    public function setOnsetTime($_onsetTime)
    {
        return ($this->onsetTime = $_onsetTime);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructAllergy
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
