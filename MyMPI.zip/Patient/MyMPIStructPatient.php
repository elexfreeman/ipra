<?php
/**
 * File for class MyMPIStructPatient
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
/**
 * This class stands for MyMPIStructPatient originally named Patient
 * Documentation : Пациент
 * Meta informations extracted from the WSDL
 * - from schema : var/wsdltophp.com/storage/wsdls/d42ef0290b966daf6e8b1c93923ddd70/wsdl.xml
 * @package MyMPI
 * @subpackage Structs
 * @author WsdlToPhp Team <contact@wsdltophp.com>
 * @version 20150429-01
 * @date 2016-04-19
 */
class MyMPIStructPatient extends MyMPIWsdlClass
{
    /**
     * The baseClinic
     * Meta informations extracted from the WSDL
     * - documentation : Поликлиника прикрепления ТФОМС: LPUBASE - из регионального справочника
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $baseClinic;
    /**
     * The snils
     * Meta informations extracted from the WSDL
     * - documentation : СНИЛС ТФОМС: SNILS ЕГИСЗ "Пациент" поле №3 СЭМД ext:asOtherIDs[classCode='IDENT']/ext:documentNumber/@number (ext:documentType code="3" codeSystem="1.2.643.5.1.13.2.7.1.62")
     * - minOccurs : 0
     * - maxLength : 14
     * - minLength : 14
     * - pattern : (\d){3}-(\d){3}-(\d){3} (\d){2}
     * @var string
     */
    public $snils;
    /**
     * The enp
     * Meta informations extracted from the WSDL
     * - documentation : ЕНП ТФОМС: ENP
     * - minOccurs : 0
     * - maxLength : 16
     * - minLength : 16
     * - pattern : (\d){16}
     * @var string
     */
    public $enp;
    /**
     * The familyName
     * Meta informations extracted from the WSDL
     * - documentation : Фамилия ТФОМС: FAM ЕГИСЗ "Пациент" поле №5
     * - minLength : 1
     * @var string
     */
    public $familyName;
    /**
     * The givenName
     * Meta informations extracted from the WSDL
     * - documentation : Имя ТФОМС: IM ЕГИСЗ "Пациент" поле №6
     * - minLength : 1
     * @var string
     */
    public $givenName;
    /**
     * The middleName
     * Meta informations extracted from the WSDL
     * - documentation : Отчество ТФОМС: OT ЕГИСЗ "Пациент" поле №7
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $middleName;
    /**
     * The prevNames
     * Meta informations extracted from the WSDL
     * - documentation : ФИО в прошлом
     * - minOccurs : 0
     * @var MyMPIStructArrayOfNameName
     */
    public $prevNames;
    /**
     * The dob
     * Meta informations extracted from the WSDL
     * - documentation : Дата рождения ТФОМС: DR ЕГИСЗ "Пациент" поле №8
     * @var date
     */
    public $dob;
    /**
     * The birthAddress
     * Meta informations extracted from the WSDL
     * - documentation : Место рождения ТФОМС: MR (записывается в city) ЕГИСЗ "Пациент" поле №9
     * - minOccurs : 0
     * @var MyMPIStructAddress
     */
    public $birthAddress;
    /**
     * The gender
     * @var MyMPIEnumGender
     */
    public $gender;
    /**
     * The legalAddress
     * Meta informations extracted from the WSDL
     * - documentation : Адрес прописки (постоянного места жительства) ТФОМС: OKATOG ЕГИСЗ "Пациент" таблица данных адреса и контактов, поля №2-11 (тип адреса = 1)
     * - minOccurs : 0
     * @var MyMPIStructAddress
     */
    public $legalAddress;
    /**
     * The actualAddress
     * Meta informations extracted from the WSDL
     * - documentation : Адрес пребывания ТФОМС: OKATOP ЕГИСЗ "Пациент" таблица данных адреса и контактов, поля №2-11 (тип адреса = 2)
     * - minOccurs : 0
     * @var MyMPIStructAddress
     */
    public $actualAddress;
    /**
     * The postalAddress
     * Meta informations extracted from the WSDL
     * - documentation : Адрес почтовый ЕГИСЗ "Пациент" таблица данных адреса и контактов, поля №2-11 (тип адреса = 3)
     * - minOccurs : 0
     * @var MyMPIStructAddress
     */
    public $postalAddress;
    /**
     * The prevAddresses
     * Meta informations extracted from the WSDL
     * - documentation : Предыдущие адреса ф 025/у-04
     * - minOccurs : 0
     * @var MyMPIStructArrayOfaddressAddress
     */
    public $prevAddresses;
    /**
     * The dwellingType
     * @var MyMPIEnumDwellingType
     */
    public $dwellingType;
    /**
     * The privilege
     * Meta informations extracted from the WSDL
     * - documentation : Данные о льготах ф 025/у-04, 025-12/у СЭМД recordTarget/patientRole/patient/ext:patient/ext:code[@codeSystem='1.2.643.5.1.13.2.1.1.358']/@code
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * - nillable : true
     * @var MyMPIStructPrivilege
     */
    public $privilege;
    /**
     * The socialStatus
     * Meta informations extracted from the WSDL
     * - documentation : Социальный статус ф 025-12/у ЕГИСЗ Код: SMP468, OID: 1.2.643.5.1.13.2.1.1.366 СЭМД recordTarget/patientRole/patient/ext:patient/ext:code[@codeSystem='1.2.643.5.1.13.2.1.1.366']/@code
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * - nillable : true
     * @var MyMPIStructCodeAndName
     */
    public $socialStatus;
    /**
     * The isHomeless
     * Meta informations extracted from the WSDL
     * - documentation : Признак лица без определенного места жительства ф 025-12/у
     * - minOccurs : 0
     * @var boolean
     */
    public $isHomeless;
    /**
     * The isServicemanFamily
     * Meta informations extracted from the WSDL
     * - documentation : Признак "член семьи военнослужащего" ф 025-12/у
     * - minOccurs : 0
     * @var boolean
     */
    public $isServicemanFamily;
    /**
     * The occupation
     * Meta informations extracted from the WSDL
     * - documentation : Место работы/учебы, профессия, должность ф 027у, 025/у-04, 003/у ЕГИСЗ "Пациент" поля №№20-24
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * - nillable : true
     * @var MyMPIStructOccupation
     */
    public $occupation;
    /**
     * The prevOccupations
     * Meta informations extracted from the WSDL
     * - documentation : Предыдущие места работы/учебы/службы ф 025/у-04
     * - minOccurs : 0
     * @var MyMPIStructArrayOfoccupationHistoryEntry
     */
    public $prevOccupations;
    /**
     * The citizenship
     * Meta informations extracted from the WSDL
     * - documentation : Гражданство
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $citizenship;
    /**
     * The identityDocument
     * Meta informations extracted from the WSDL
     * - documentation : Документ, удостоверяющий личность ТФОМС: DOCTYPE (F011), DOCSER, DOCNUM ЕГИСЗ "Пациент" поля №№12-15 СЭМД ext:asOtherIDs classCode="IDENT" (ext:documentType code="5" codeSystem="1.2.643.5.1.13.2.7.1.62")
     * - minOccurs : 0
     * @var MyMPIStructIdentityDocument
     */
    public $identityDocument;
    /**
     * The prevIdentityDocuments
     * Meta informations extracted from the WSDL
     * - documentation : Устаревшие документы, удостоверяющие личность
     * - minOccurs : 0
     * @var MyMPIStructArrayOfidentityDocumentIdentityDocument
     */
    public $prevIdentityDocuments;
    /**
     * The birthCertificate
     * Meta informations extracted from the WSDL
     * - documentation : Свидетельство о рождении В F011 тип документа = 3
     * - minOccurs : 0
     * @var MyMPIStructIdentityDocument
     */
    public $birthCertificate;
    /**
     * The omsInsurance
     * Meta informations extracted from the WSDL
     * - documentation : Данные полиса ОМС ТФОМС: VPOLIS (F008), SPOLIS, NPOLIS ЕГИСЗ "Пациент" поля №№26-30 СЭМД ext:asOtherIDs classCode="HLD" (ext:documentType code="1" codeSystem="1.2.643.5.1.13.2.7.1.62")
     * - minOccurs : 0
     * @var MyMPIStructInsurance
     */
    public $omsInsurance;
    /**
     * The prevOMSInsurance
     * Meta informations extracted from the WSDL
     * - documentation : Прежние полисы ОМС
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * - nillable : true
     * @var MyMPIStructInsurance
     */
    public $prevOMSInsurance;
    /**
     * The dmsInsurance
     * Meta informations extracted from the WSDL
     * - documentation : Данные полиса ДМС ЕГИСЗ "Пациент" таблица сведений о ДМС СЭМД ext:asOtherIDs classCode="HLD" (ext:documentType code="2" codeSystem="1.2.643.5.1.13.2.7.1.62")
     * - maxOccurs : unbounded
     * - minOccurs : 0
     * - nillable : true
     * @var MyMPIStructInsurance
     */
    public $dmsInsurance;
    /**
     * The bloodGroup
     * @var MyMPIEnumBloodGroup
     */
    public $bloodGroup;
    /**
     * The rhesusFactor
     * Meta informations extracted from the WSDL
     * - documentation : Резус-фактор
     * - minOccurs : 0
     * @var boolean
     */
    public $rhesusFactor;
    /**
     * The contactInfo
     * Meta informations extracted from the WSDL
     * - documentation : Контактная информация ЕГИСЗ "Пациент" таблица данных адреса и контактов, поля №№12-13
     * - minOccurs : 0
     * @var MyMPIStructContactInfo
     */
    public $contactInfo;
    /**
     * The isTrustee
     * Meta informations extracted from the WSDL
     * - documentation : Признак того, что данные не пациента, а его представителя (данные пациента пустые) ТФОМС: PDT (1=false/2=true) НЕ ИСПОЛЬЗУЕТСЯ
     * - minOccurs : 0
     * @var boolean
     */
    public $isTrustee;
    /**
     * The trusteeList
     * Meta informations extracted from the WSDL
     * - documentation : Представители/опекуны/родители/контактные лица пациента ЕГИСЗ "Представитель пациента" СЭМД participant - Контактные лица пациента СЭМД recordTarget/patientRole/patient/guardian - Опекун/родитель
     * - minOccurs : 0
     * @var MyMPIStructArrayOftrusteeTrustee
     */
    public $trusteeList;
    /**
     * The newBornData
     * Meta informations extracted from the WSDL
     * - documentation : Данные новорожденного ТФОМС: NOVOR: ПДДММГГН, где П – пол ребёнка в соответствии с классификатором V005; ДД – день рождения; ММ – месяц рождения; ГГ – последние две цифры года рождения;Н – порядковый номер ребёнка
     * - minOccurs : 0
     * - minLength : 1
     * @var string
     */
    public $newBornData;
    /**
     * The isUnidentified
     * Meta informations extracted from the WSDL
     * - documentation : Признак неидентифицированного ЕГИСЗ "Пациент" поле №2 СЭМД ext:asUnidentified
     * - minOccurs : 0
     * @var boolean
     */
    public $isUnidentified;
    /**
     * The isForeigner
     * Meta informations extracted from the WSDL
     * - documentation : Признак: иностранный гражданин без регистрации на территории РФ ЕГИСЗ "Пациент" таблица данных адреса и контактов, поле №14
     * - minOccurs : 0
     * @var boolean
     */
    public $isForeigner;
    /**
     * The inn
     * Meta informations extracted from the WSDL
     * - documentation : ИНН ЕГИСЗ "Пациент" поле №4 СЭМД ext:asOtherIDs[classCode='IDENT']/ext:documentNumber/@number (ext:documentType code="4" codeSystem="1.2.643.5.1.13.2.7.1.62")
     * - minOccurs : 0
     * - maxLength : 12
     * - minLength : 12
     * - pattern : (\d){12}
     * @var string
     */
    public $inn;
    /**
     * The race
     * Meta informations extracted from the WSDL
     * - documentation : Рассовая принадлежность ЕГИСЗ "Пациент" поле №16
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $race;
    /**
     * The maritalStatus
     * Meta informations extracted from the WSDL
     * - documentation : Семейное положение ЕГИСЗ "Пациент" поле №17
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $maritalStatus;
    /**
     * The children
     * Meta informations extracted from the WSDL
     * - documentation : Количество детей ЕГИСЗ "Пациент" поле №18
     * - minOccurs : 0
     * @var long
     */
    public $children;
    /**
     * The levelOfEducation
     * Meta informations extracted from the WSDL
     * - documentation : Уровень образования ЕГИСЗ "Пациент" поле №19
     * - minOccurs : 0
     * @var MyMPIStructCodeAndName
     */
    public $levelOfEducation;
    /**
     * The identifiers
     * Meta informations extracted from the WSDL
     * - documentation : Дополнительные идентификаторы пациента
     * - minOccurs : 0
     * @var MyMPIStructArrayOfidentifierIdentifier
     */
    public $identifiers;
    /**
     * The deceaseAddress
     * Meta informations extracted from the WSDL
     * - documentation : Адрес места смерти
     * - minOccurs : 0
     * @var MyMPIStructAddress
     */
    public $deceaseAddress;
    /**
     * The deceaseDate
     * Meta informations extracted from the WSDL
     * - documentation : Дата смерти
     * - minOccurs : 0
     * @var date
     */
    public $deceaseDate;
    /**
     * Constructor method for Patient
     * @see parent::__construct()
     * @param MyMPIStructCodeAndName $_baseClinic
     * @param string $_snils
     * @param string $_enp
     * @param string $_familyName
     * @param string $_givenName
     * @param string $_middleName
     * @param MyMPIStructArrayOfNameName $_prevNames
     * @param date $_dob
     * @param MyMPIStructAddress $_birthAddress
     * @param MyMPIEnumGender $_gender
     * @param MyMPIStructAddress $_legalAddress
     * @param MyMPIStructAddress $_actualAddress
     * @param MyMPIStructAddress $_postalAddress
     * @param MyMPIStructArrayOfaddressAddress $_prevAddresses
     * @param MyMPIEnumDwellingType $_dwellingType
     * @param MyMPIStructPrivilege $_privilege
     * @param MyMPIStructCodeAndName $_socialStatus
     * @param boolean $_isHomeless
     * @param boolean $_isServicemanFamily
     * @param MyMPIStructOccupation $_occupation
     * @param MyMPIStructArrayOfoccupationHistoryEntry $_prevOccupations
     * @param MyMPIStructCodeAndName $_citizenship
     * @param MyMPIStructIdentityDocument $_identityDocument
     * @param MyMPIStructArrayOfidentityDocumentIdentityDocument $_prevIdentityDocuments
     * @param MyMPIStructIdentityDocument $_birthCertificate
     * @param MyMPIStructInsurance $_omsInsurance
     * @param MyMPIStructInsurance $_prevOMSInsurance
     * @param MyMPIStructInsurance $_dmsInsurance
     * @param MyMPIEnumBloodGroup $_bloodGroup
     * @param boolean $_rhesusFactor
     * @param MyMPIStructContactInfo $_contactInfo
     * @param boolean $_isTrustee
     * @param MyMPIStructArrayOftrusteeTrustee $_trusteeList
     * @param string $_newBornData
     * @param boolean $_isUnidentified
     * @param boolean $_isForeigner
     * @param string $_inn
     * @param MyMPIStructCodeAndName $_race
     * @param MyMPIStructCodeAndName $_maritalStatus
     * @param long $_children
     * @param MyMPIStructCodeAndName $_levelOfEducation
     * @param MyMPIStructArrayOfidentifierIdentifier $_identifiers
     * @param MyMPIStructAddress $_deceaseAddress
     * @param date $_deceaseDate
     * @return MyMPIStructPatient
     */
    public function __construct($_baseClinic = NULL,$_snils = NULL,$_enp = NULL,$_familyName = NULL,$_givenName = NULL,$_middleName = NULL,$_prevNames = NULL,$_dob = NULL,$_birthAddress = NULL,$_gender = NULL,$_legalAddress = NULL,$_actualAddress = NULL,$_postalAddress = NULL,$_prevAddresses = NULL,$_dwellingType = NULL,$_privilege = NULL,$_socialStatus = NULL,$_isHomeless = NULL,$_isServicemanFamily = NULL,$_occupation = NULL,$_prevOccupations = NULL,$_citizenship = NULL,$_identityDocument = NULL,$_prevIdentityDocuments = NULL,$_birthCertificate = NULL,$_omsInsurance = NULL,$_prevOMSInsurance = NULL,$_dmsInsurance = NULL,$_bloodGroup = NULL,$_rhesusFactor = NULL,$_contactInfo = NULL,$_isTrustee = NULL,$_trusteeList = NULL,$_newBornData = NULL,$_isUnidentified = NULL,$_isForeigner = NULL,$_inn = NULL,$_race = NULL,$_maritalStatus = NULL,$_children = NULL,$_levelOfEducation = NULL,$_identifiers = NULL,$_deceaseAddress = NULL,$_deceaseDate = NULL)
    {
        parent::__construct(array('baseClinic'=>$_baseClinic,'snils'=>$_snils,'enp'=>$_enp,'familyName'=>$_familyName,'givenName'=>$_givenName,'middleName'=>$_middleName,'prevNames'=>($_prevNames instanceof MyMPIStructArrayOfNameName)?$_prevNames:new MyMPIStructArrayOfNameName($_prevNames),'dob'=>$_dob,'birthAddress'=>$_birthAddress,'gender'=>$_gender,'legalAddress'=>$_legalAddress,'actualAddress'=>$_actualAddress,'postalAddress'=>$_postalAddress,'prevAddresses'=>($_prevAddresses instanceof MyMPIStructArrayOfaddressAddress)?$_prevAddresses:new MyMPIStructArrayOfaddressAddress($_prevAddresses),'dwellingType'=>$_dwellingType,'privilege'=>$_privilege,'socialStatus'=>$_socialStatus,'isHomeless'=>$_isHomeless,'isServicemanFamily'=>$_isServicemanFamily,'occupation'=>$_occupation,'prevOccupations'=>($_prevOccupations instanceof MyMPIStructArrayOfoccupationHistoryEntry)?$_prevOccupations:new MyMPIStructArrayOfoccupationHistoryEntry($_prevOccupations),'citizenship'=>$_citizenship,'identityDocument'=>$_identityDocument,'prevIdentityDocuments'=>($_prevIdentityDocuments instanceof MyMPIStructArrayOfidentityDocumentIdentityDocument)?$_prevIdentityDocuments:new MyMPIStructArrayOfidentityDocumentIdentityDocument($_prevIdentityDocuments),'birthCertificate'=>$_birthCertificate,'omsInsurance'=>$_omsInsurance,'prevOMSInsurance'=>$_prevOMSInsurance,'dmsInsurance'=>$_dmsInsurance,'bloodGroup'=>$_bloodGroup,'rhesusFactor'=>$_rhesusFactor,'contactInfo'=>$_contactInfo,'isTrustee'=>$_isTrustee,'trusteeList'=>($_trusteeList instanceof MyMPIStructArrayOftrusteeTrustee)?$_trusteeList:new MyMPIStructArrayOftrusteeTrustee($_trusteeList),'newBornData'=>$_newBornData,'isUnidentified'=>$_isUnidentified,'isForeigner'=>$_isForeigner,'inn'=>$_inn,'race'=>$_race,'maritalStatus'=>$_maritalStatus,'children'=>$_children,'levelOfEducation'=>$_levelOfEducation,'identifiers'=>($_identifiers instanceof MyMPIStructArrayOfidentifierIdentifier)?$_identifiers:new MyMPIStructArrayOfidentifierIdentifier($_identifiers),'deceaseAddress'=>$_deceaseAddress,'deceaseDate'=>$_deceaseDate),false);
    }
    /**
     * Get baseClinic value
     * @return MyMPIStructCodeAndName|null
     */
    public function getBaseClinic()
    {
        return $this->baseClinic;
    }
    /**
     * Set baseClinic value
     * @param MyMPIStructCodeAndName $_baseClinic the baseClinic
     * @return MyMPIStructCodeAndName
     */
    public function setBaseClinic($_baseClinic)
    {
        return ($this->baseClinic = $_baseClinic);
    }
    /**
     * Get snils value
     * @return string|null
     */
    public function getSnils()
    {
        return $this->snils;
    }
    /**
     * Set snils value
     * @param string $_snils the snils
     * @return string
     */
    public function setSnils($_snils)
    {
        return ($this->snils = $_snils);
    }
    /**
     * Get enp value
     * @return string|null
     */
    public function getEnp()
    {
        return $this->enp;
    }
    /**
     * Set enp value
     * @param string $_enp the enp
     * @return string
     */
    public function setEnp($_enp)
    {
        return ($this->enp = $_enp);
    }
    /**
     * Get familyName value
     * @return string|null
     */
    public function getFamilyName()
    {
        return $this->familyName;
    }
    /**
     * Set familyName value
     * @param string $_familyName the familyName
     * @return string
     */
    public function setFamilyName($_familyName)
    {
        return ($this->familyName = $_familyName);
    }
    /**
     * Get givenName value
     * @return string|null
     */
    public function getGivenName()
    {
        return $this->givenName;
    }
    /**
     * Set givenName value
     * @param string $_givenName the givenName
     * @return string
     */
    public function setGivenName($_givenName)
    {
        return ($this->givenName = $_givenName);
    }
    /**
     * Get middleName value
     * @return string|null
     */
    public function getMiddleName()
    {
        return $this->middleName;
    }
    /**
     * Set middleName value
     * @param string $_middleName the middleName
     * @return string
     */
    public function setMiddleName($_middleName)
    {
        return ($this->middleName = $_middleName);
    }
    /**
     * Get prevNames value
     * @return MyMPIStructArrayOfNameName|null
     */
    public function getPrevNames()
    {
        return $this->prevNames;
    }
    /**
     * Set prevNames value
     * @param MyMPIStructArrayOfNameName $_prevNames the prevNames
     * @return MyMPIStructArrayOfNameName
     */
    public function setPrevNames($_prevNames)
    {
        return ($this->prevNames = $_prevNames);
    }
    /**
     * Get dob value
     * @return date|null
     */
    public function getDob()
    {
        return $this->dob;
    }
    /**
     * Set dob value
     * @param date $_dob the dob
     * @return date
     */
    public function setDob($_dob)
    {
        return ($this->dob = $_dob);
    }
    /**
     * Get birthAddress value
     * @return MyMPIStructAddress|null
     */
    public function getBirthAddress()
    {
        return $this->birthAddress;
    }
    /**
     * Set birthAddress value
     * @param MyMPIStructAddress $_birthAddress the birthAddress
     * @return MyMPIStructAddress
     */
    public function setBirthAddress($_birthAddress)
    {
        return ($this->birthAddress = $_birthAddress);
    }
    /**
     * Get gender value
     * @return MyMPIEnumGender|null
     */
    public function getGender()
    {
        return $this->gender;
    }
    /**
     * Set gender value
     * @uses MyMPIEnumGender::valueIsValid()
     * @param MyMPIEnumGender $_gender the gender
     * @return MyMPIEnumGender
     */
    public function setGender($_gender)
    {
        if(!MyMPIEnumGender::valueIsValid($_gender))
        {
            return false;
        }
        return ($this->gender = $_gender);
    }
    /**
     * Get legalAddress value
     * @return MyMPIStructAddress|null
     */
    public function getLegalAddress()
    {
        return $this->legalAddress;
    }
    /**
     * Set legalAddress value
     * @param MyMPIStructAddress $_legalAddress the legalAddress
     * @return MyMPIStructAddress
     */
    public function setLegalAddress($_legalAddress)
    {
        return ($this->legalAddress = $_legalAddress);
    }
    /**
     * Get actualAddress value
     * @return MyMPIStructAddress|null
     */
    public function getActualAddress()
    {
        return $this->actualAddress;
    }
    /**
     * Set actualAddress value
     * @param MyMPIStructAddress $_actualAddress the actualAddress
     * @return MyMPIStructAddress
     */
    public function setActualAddress($_actualAddress)
    {
        return ($this->actualAddress = $_actualAddress);
    }
    /**
     * Get postalAddress value
     * @return MyMPIStructAddress|null
     */
    public function getPostalAddress()
    {
        return $this->postalAddress;
    }
    /**
     * Set postalAddress value
     * @param MyMPIStructAddress $_postalAddress the postalAddress
     * @return MyMPIStructAddress
     */
    public function setPostalAddress($_postalAddress)
    {
        return ($this->postalAddress = $_postalAddress);
    }
    /**
     * Get prevAddresses value
     * @return MyMPIStructArrayOfaddressAddress|null
     */
    public function getPrevAddresses()
    {
        return $this->prevAddresses;
    }
    /**
     * Set prevAddresses value
     * @param MyMPIStructArrayOfaddressAddress $_prevAddresses the prevAddresses
     * @return MyMPIStructArrayOfaddressAddress
     */
    public function setPrevAddresses($_prevAddresses)
    {
        return ($this->prevAddresses = $_prevAddresses);
    }
    /**
     * Get dwellingType value
     * @return MyMPIEnumDwellingType|null
     */
    public function getDwellingType()
    {
        return $this->dwellingType;
    }
    /**
     * Set dwellingType value
     * @uses MyMPIEnumDwellingType::valueIsValid()
     * @param MyMPIEnumDwellingType $_dwellingType the dwellingType
     * @return MyMPIEnumDwellingType
     */
    public function setDwellingType($_dwellingType)
    {
        if(!MyMPIEnumDwellingType::valueIsValid($_dwellingType))
        {
            return false;
        }
        return ($this->dwellingType = $_dwellingType);
    }
    /**
     * Get privilege value
     * @return MyMPIStructPrivilege|null
     */
    public function getPrivilege()
    {
        return $this->privilege;
    }
    /**
     * Set privilege value
     * @param MyMPIStructPrivilege $_privilege the privilege
     * @return MyMPIStructPrivilege
     */
    public function setPrivilege($_privilege)
    {
        return ($this->privilege = $_privilege);
    }
    /**
     * Get socialStatus value
     * @return MyMPIStructCodeAndName|null
     */
    public function getSocialStatus()
    {
        return $this->socialStatus;
    }
    /**
     * Set socialStatus value
     * @param MyMPIStructCodeAndName $_socialStatus the socialStatus
     * @return MyMPIStructCodeAndName
     */
    public function setSocialStatus($_socialStatus)
    {
        return ($this->socialStatus = $_socialStatus);
    }
    /**
     * Get isHomeless value
     * @return boolean|null
     */
    public function getIsHomeless()
    {
        return $this->isHomeless;
    }
    /**
     * Set isHomeless value
     * @param boolean $_isHomeless the isHomeless
     * @return boolean
     */
    public function setIsHomeless($_isHomeless)
    {
        return ($this->isHomeless = $_isHomeless);
    }
    /**
     * Get isServicemanFamily value
     * @return boolean|null
     */
    public function getIsServicemanFamily()
    {
        return $this->isServicemanFamily;
    }
    /**
     * Set isServicemanFamily value
     * @param boolean $_isServicemanFamily the isServicemanFamily
     * @return boolean
     */
    public function setIsServicemanFamily($_isServicemanFamily)
    {
        return ($this->isServicemanFamily = $_isServicemanFamily);
    }
    /**
     * Get occupation value
     * @return MyMPIStructOccupation|null
     */
    public function getOccupation()
    {
        return $this->occupation;
    }
    /**
     * Set occupation value
     * @param MyMPIStructOccupation $_occupation the occupation
     * @return MyMPIStructOccupation
     */
    public function setOccupation($_occupation)
    {
        return ($this->occupation = $_occupation);
    }
    /**
     * Get prevOccupations value
     * @return MyMPIStructArrayOfoccupationHistoryEntry|null
     */
    public function getPrevOccupations()
    {
        return $this->prevOccupations;
    }
    /**
     * Set prevOccupations value
     * @param MyMPIStructArrayOfoccupationHistoryEntry $_prevOccupations the prevOccupations
     * @return MyMPIStructArrayOfoccupationHistoryEntry
     */
    public function setPrevOccupations($_prevOccupations)
    {
        return ($this->prevOccupations = $_prevOccupations);
    }
    /**
     * Get citizenship value
     * @return MyMPIStructCodeAndName|null
     */
    public function getCitizenship()
    {
        return $this->citizenship;
    }
    /**
     * Set citizenship value
     * @param MyMPIStructCodeAndName $_citizenship the citizenship
     * @return MyMPIStructCodeAndName
     */
    public function setCitizenship($_citizenship)
    {
        return ($this->citizenship = $_citizenship);
    }
    /**
     * Get identityDocument value
     * @return MyMPIStructIdentityDocument|null
     */
    public function getIdentityDocument()
    {
        return $this->identityDocument;
    }
    /**
     * Set identityDocument value
     * @param MyMPIStructIdentityDocument $_identityDocument the identityDocument
     * @return MyMPIStructIdentityDocument
     */
    public function setIdentityDocument($_identityDocument)
    {
        return ($this->identityDocument = $_identityDocument);
    }
    /**
     * Get prevIdentityDocuments value
     * @return MyMPIStructArrayOfidentityDocumentIdentityDocument|null
     */
    public function getPrevIdentityDocuments()
    {
        return $this->prevIdentityDocuments;
    }
    /**
     * Set prevIdentityDocuments value
     * @param MyMPIStructArrayOfidentityDocumentIdentityDocument $_prevIdentityDocuments the prevIdentityDocuments
     * @return MyMPIStructArrayOfidentityDocumentIdentityDocument
     */
    public function setPrevIdentityDocuments($_prevIdentityDocuments)
    {
        return ($this->prevIdentityDocuments = $_prevIdentityDocuments);
    }
    /**
     * Get birthCertificate value
     * @return MyMPIStructIdentityDocument|null
     */
    public function getBirthCertificate()
    {
        return $this->birthCertificate;
    }
    /**
     * Set birthCertificate value
     * @param MyMPIStructIdentityDocument $_birthCertificate the birthCertificate
     * @return MyMPIStructIdentityDocument
     */
    public function setBirthCertificate($_birthCertificate)
    {
        return ($this->birthCertificate = $_birthCertificate);
    }
    /**
     * Get omsInsurance value
     * @return MyMPIStructInsurance|null
     */
    public function getOmsInsurance()
    {
        return $this->omsInsurance;
    }
    /**
     * Set omsInsurance value
     * @param MyMPIStructInsurance $_omsInsurance the omsInsurance
     * @return MyMPIStructInsurance
     */
    public function setOmsInsurance($_omsInsurance)
    {
        return ($this->omsInsurance = $_omsInsurance);
    }
    /**
     * Get prevOMSInsurance value
     * @return MyMPIStructInsurance|null
     */
    public function getPrevOMSInsurance()
    {
        return $this->prevOMSInsurance;
    }
    /**
     * Set prevOMSInsurance value
     * @param MyMPIStructInsurance $_prevOMSInsurance the prevOMSInsurance
     * @return MyMPIStructInsurance
     */
    public function setPrevOMSInsurance($_prevOMSInsurance)
    {
        return ($this->prevOMSInsurance = $_prevOMSInsurance);
    }
    /**
     * Get dmsInsurance value
     * @return MyMPIStructInsurance|null
     */
    public function getDmsInsurance()
    {
        return $this->dmsInsurance;
    }
    /**
     * Set dmsInsurance value
     * @param MyMPIStructInsurance $_dmsInsurance the dmsInsurance
     * @return MyMPIStructInsurance
     */
    public function setDmsInsurance($_dmsInsurance)
    {
        return ($this->dmsInsurance = $_dmsInsurance);
    }
    /**
     * Get bloodGroup value
     * @return MyMPIEnumBloodGroup|null
     */
    public function getBloodGroup()
    {
        return $this->bloodGroup;
    }
    /**
     * Set bloodGroup value
     * @uses MyMPIEnumBloodGroup::valueIsValid()
     * @param MyMPIEnumBloodGroup $_bloodGroup the bloodGroup
     * @return MyMPIEnumBloodGroup
     */
    public function setBloodGroup($_bloodGroup)
    {
        if(!MyMPIEnumBloodGroup::valueIsValid($_bloodGroup))
        {
            return false;
        }
        return ($this->bloodGroup = $_bloodGroup);
    }
    /**
     * Get rhesusFactor value
     * @return boolean|null
     */
    public function getRhesusFactor()
    {
        return $this->rhesusFactor;
    }
    /**
     * Set rhesusFactor value
     * @param boolean $_rhesusFactor the rhesusFactor
     * @return boolean
     */
    public function setRhesusFactor($_rhesusFactor)
    {
        return ($this->rhesusFactor = $_rhesusFactor);
    }
    /**
     * Get contactInfo value
     * @return MyMPIStructContactInfo|null
     */
    public function getContactInfo()
    {
        return $this->contactInfo;
    }
    /**
     * Set contactInfo value
     * @param MyMPIStructContactInfo $_contactInfo the contactInfo
     * @return MyMPIStructContactInfo
     */
    public function setContactInfo($_contactInfo)
    {
        return ($this->contactInfo = $_contactInfo);
    }
    /**
     * Get isTrustee value
     * @return boolean|null
     */
    public function getIsTrustee()
    {
        return $this->isTrustee;
    }
    /**
     * Set isTrustee value
     * @param boolean $_isTrustee the isTrustee
     * @return boolean
     */
    public function setIsTrustee($_isTrustee)
    {
        return ($this->isTrustee = $_isTrustee);
    }
    /**
     * Get trusteeList value
     * @return MyMPIStructArrayOftrusteeTrustee|null
     */
    public function getTrusteeList()
    {
        return $this->trusteeList;
    }
    /**
     * Set trusteeList value
     * @param MyMPIStructArrayOftrusteeTrustee $_trusteeList the trusteeList
     * @return MyMPIStructArrayOftrusteeTrustee
     */
    public function setTrusteeList($_trusteeList)
    {
        return ($this->trusteeList = $_trusteeList);
    }
    /**
     * Get newBornData value
     * @return string|null
     */
    public function getNewBornData()
    {
        return $this->newBornData;
    }
    /**
     * Set newBornData value
     * @param string $_newBornData the newBornData
     * @return string
     */
    public function setNewBornData($_newBornData)
    {
        return ($this->newBornData = $_newBornData);
    }
    /**
     * Get isUnidentified value
     * @return boolean|null
     */
    public function getIsUnidentified()
    {
        return $this->isUnidentified;
    }
    /**
     * Set isUnidentified value
     * @param boolean $_isUnidentified the isUnidentified
     * @return boolean
     */
    public function setIsUnidentified($_isUnidentified)
    {
        return ($this->isUnidentified = $_isUnidentified);
    }
    /**
     * Get isForeigner value
     * @return boolean|null
     */
    public function getIsForeigner()
    {
        return $this->isForeigner;
    }
    /**
     * Set isForeigner value
     * @param boolean $_isForeigner the isForeigner
     * @return boolean
     */
    public function setIsForeigner($_isForeigner)
    {
        return ($this->isForeigner = $_isForeigner);
    }
    /**
     * Get inn value
     * @return string|null
     */
    public function getInn()
    {
        return $this->inn;
    }
    /**
     * Set inn value
     * @param string $_inn the inn
     * @return string
     */
    public function setInn($_inn)
    {
        return ($this->inn = $_inn);
    }
    /**
     * Get race value
     * @return MyMPIStructCodeAndName|null
     */
    public function getRace()
    {
        return $this->race;
    }
    /**
     * Set race value
     * @param MyMPIStructCodeAndName $_race the race
     * @return MyMPIStructCodeAndName
     */
    public function setRace($_race)
    {
        return ($this->race = $_race);
    }
    /**
     * Get maritalStatus value
     * @return MyMPIStructCodeAndName|null
     */
    public function getMaritalStatus()
    {
        return $this->maritalStatus;
    }
    /**
     * Set maritalStatus value
     * @param MyMPIStructCodeAndName $_maritalStatus the maritalStatus
     * @return MyMPIStructCodeAndName
     */
    public function setMaritalStatus($_maritalStatus)
    {
        return ($this->maritalStatus = $_maritalStatus);
    }
    /**
     * Get children value
     * @return long|null
     */
    public function getChildren()
    {
        return $this->children;
    }
    /**
     * Set children value
     * @param long $_children the children
     * @return long
     */
    public function setChildren($_children)
    {
        return ($this->children = $_children);
    }
    /**
     * Get levelOfEducation value
     * @return MyMPIStructCodeAndName|null
     */
    public function getLevelOfEducation()
    {
        return $this->levelOfEducation;
    }
    /**
     * Set levelOfEducation value
     * @param MyMPIStructCodeAndName $_levelOfEducation the levelOfEducation
     * @return MyMPIStructCodeAndName
     */
    public function setLevelOfEducation($_levelOfEducation)
    {
        return ($this->levelOfEducation = $_levelOfEducation);
    }
    /**
     * Get identifiers value
     * @return MyMPIStructArrayOfidentifierIdentifier|null
     */
    public function getIdentifiers()
    {
        return $this->identifiers;
    }
    /**
     * Set identifiers value
     * @param MyMPIStructArrayOfidentifierIdentifier $_identifiers the identifiers
     * @return MyMPIStructArrayOfidentifierIdentifier
     */
    public function setIdentifiers($_identifiers)
    {
        return ($this->identifiers = $_identifiers);
    }
    /**
     * Get deceaseAddress value
     * @return MyMPIStructAddress|null
     */
    public function getDeceaseAddress()
    {
        return $this->deceaseAddress;
    }
    /**
     * Set deceaseAddress value
     * @param MyMPIStructAddress $_deceaseAddress the deceaseAddress
     * @return MyMPIStructAddress
     */
    public function setDeceaseAddress($_deceaseAddress)
    {
        return ($this->deceaseAddress = $_deceaseAddress);
    }
    /**
     * Get deceaseDate value
     * @return date|null
     */
    public function getDeceaseDate()
    {
        return $this->deceaseDate;
    }
    /**
     * Set deceaseDate value
     * @param date $_deceaseDate the deceaseDate
     * @return date
     */
    public function setDeceaseDate($_deceaseDate)
    {
        return ($this->deceaseDate = $_deceaseDate);
    }
    /**
     * Method called when an object has been exported with var_export() functions
     * It allows to return an object instantiated with the values
     * @see MyMPIWsdlClass::__set_state()
     * @uses MyMPIWsdlClass::__set_state()
     * @param array $_array the exported values
     * @return MyMPIStructPatient
     */
    public static function __set_state(array $_array,$_className = __CLASS__)
    {
        return parent::__set_state($_array,$_className);
    }
    /**
     * Method returning the class name
     * @return string __CLASS__
     */
    public function __toString()
    {
        return __CLASS__;
    }
}
